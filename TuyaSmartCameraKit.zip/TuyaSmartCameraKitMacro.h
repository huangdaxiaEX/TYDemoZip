#ifndef TuyaSmartCameraKitMacro_h
#define TuyaSmartCameraKitMacro_h

#ifndef TuyaSmartDeviceModel 
#define TuyaSmartDeviceModel ThingSmartDeviceModel 
#endif 

#ifndef TuyaSmartCameraAbility 
#define TuyaSmartCameraAbility ThingSmartCameraAbility 
#endif 

#ifndef TuyaSmartCameraMessageMediaPlayer 
#define TuyaSmartCameraMessageMediaPlayer ThingSmartCameraMessageMediaPlayer 
#endif 

#ifndef TuyaSmartCameraMessageMediaPlayerDelegate 
#define TuyaSmartCameraMessageMediaPlayerDelegate ThingSmartCameraMessageMediaPlayerDelegate 
#endif 

#ifndef TuyaSmartVideoFrameInfo 
#define TuyaSmartVideoFrameInfo ThingSmartVideoFrameInfo 
#endif 

#ifndef TuyaSmartAudioFrameInfo 
#define TuyaSmartAudioFrameInfo ThingSmartAudioFrameInfo 
#endif 

#ifndef TuyaCameraMessageAttachmentType 
#define TuyaCameraMessageAttachmentType ThingCameraMessageAttachmentType 
#endif 

#ifndef TuyaSmartCloudState 
#define TuyaSmartCloudState ThingSmartCloudState 
#endif 

#ifndef TuyaSmartCloudStateNoService 
#define TuyaSmartCloudStateNoService ThingSmartCloudStateNoService 
#endif 

#ifndef TuyaSmartCloudStateNoData 
#define TuyaSmartCloudStateNoData ThingSmartCloudStateNoData 
#endif 

#ifndef TuyaSmartCloudStateValidData 
#define TuyaSmartCloudStateValidData ThingSmartCloudStateValidData 
#endif 

#ifndef TuyaSmartCloudStateExpiredNoData 
#define TuyaSmartCloudStateExpiredNoData ThingSmartCloudStateExpiredNoData 
#endif 

#ifndef TuyaSmartCloudStateExpiredData 
#define TuyaSmartCloudStateExpiredData ThingSmartCloudStateExpiredData 
#endif 

#ifndef TuyaSmartCloudStateLoadFailed 
#define TuyaSmartCloudStateLoadFailed ThingSmartCloudStateLoadFailed 
#endif 

#ifndef TuyaSmartCloudManager 
#define TuyaSmartCloudManager ThingSmartCloudManager 
#endif 

#ifndef TuyaSmartCloudManagerDelegate 
#define TuyaSmartCloudManagerDelegate ThingSmartCloudManagerDelegate 
#endif 

#ifndef TuyaSmartCameraPlayBackSpeed 
#define TuyaSmartCameraPlayBackSpeed ThingSmartCameraPlayBackSpeed 
#endif 

#ifndef TuyaSmartVideoRotateDirection 
#define TuyaSmartVideoRotateDirection ThingSmartVideoRotateDirection 
#endif 

#ifndef TuyaSmartVideoMirrorDirection 
#define TuyaSmartVideoMirrorDirection ThingSmartVideoMirrorDirection 
#endif 

#ifndef TuyaSmartCloudService 
#define TuyaSmartCloudService ThingSmartCloudService 
#endif 

#ifndef TYSuccessString 
#define TYSuccessString ThingSuccessString 
#endif 

#ifndef TYFailureError 
#define TYFailureError ThingFailureError 
#endif 

#ifndef TYSuccessList 
#define TYSuccessList ThingSuccessList 
#endif 

#ifndef TYSuccessID 
#define TYSuccessID ThingSuccessID 
#endif 

#ifndef TYSuccessHandler 
#define TYSuccessHandler ThingSuccessHandler 
#endif 

#ifndef TuyaSmartCameraDPKey 
#define TuyaSmartCameraDPKey ThingSmartCameraDPKey 
#endif 

#ifndef TuyaSmartCameraNightvision
#define TuyaSmartCameraNightvision ThingSmartCameraNightvision
#endif

#ifndef TuyaSmartCameraNightvisionAuto 
#define TuyaSmartCameraNightvisionAuto ThingSmartCameraNightvisionAuto 
#endif 

#ifndef TuyaSmartCameraNightvisionOff 
#define TuyaSmartCameraNightvisionOff ThingSmartCameraNightvisionOff 
#endif 

#ifndef TuyaSmartCameraNightvisionOn 
#define TuyaSmartCameraNightvisionOn ThingSmartCameraNightvisionOn 
#endif

#ifndef TuyaSmartCameraIPConfig
#define TuyaSmartCameraIPConfig ThingSmartCameraIPConfig
#endif

#ifndef TuyaSmartCameraIPConfigDynamic 
#define TuyaSmartCameraIPConfigDynamic ThingSmartCameraIPConfigDynamic 
#endif 

#ifndef TuyaSmartCameraIPConfigStatic 
#define TuyaSmartCameraIPConfigStatic ThingSmartCameraIPConfigStatic 
#endif

#ifndef TuyaSmartCameraPIR
#define TuyaSmartCameraPIR ThingSmartCameraPIR
#endif

#ifndef TuyaSmartCameraPIRStateOff 
#define TuyaSmartCameraPIRStateOff ThingSmartCameraPIRStateOff 
#endif 

#ifndef TuyaSmartCameraPIRStateLow 
#define TuyaSmartCameraPIRStateLow ThingSmartCameraPIRStateLow 
#endif 

#ifndef TuyaSmartCameraPIRStateMedium 
#define TuyaSmartCameraPIRStateMedium ThingSmartCameraPIRStateMedium 
#endif 

#ifndef TuyaSmartCameraPIRStateHigh 
#define TuyaSmartCameraPIRStateHigh ThingSmartCameraPIRStateHigh 
#endif 

#ifndef TuyaSmartCameraPIRStateOn 
#define TuyaSmartCameraPIRStateOn ThingSmartCameraPIRStateOn 
#endif 


#ifndef TuyaSmartCameraMotion
#define TuyaSmartCameraMotion ThingSmartCameraMotion
#endif

#ifndef TuyaSmartCameraMotionLow
#define TuyaSmartCameraMotionLow ThingSmartCameraMotionLow 
#endif 

#ifndef TuyaSmartCameraMotionMedium 
#define TuyaSmartCameraMotionMedium ThingSmartCameraMotionMedium 
#endif 

#ifndef TuyaSmartCameraMotionHigh 
#define TuyaSmartCameraMotionHigh ThingSmartCameraMotionHigh 
#endif 


#ifndef TuyaSmartCameraDecibel
#define TuyaSmartCameraDecibel ThingSmartCameraDecibel
#endif

#ifndef TuyaSmartCameraDecibelLow 
#define TuyaSmartCameraDecibelLow ThingSmartCameraDecibelLow 
#endif 

#ifndef TuyaSmartCameraDecibelHigh 
#define TuyaSmartCameraDecibelHigh ThingSmartCameraDecibelHigh 
#endif 


#ifndef TuyaSmartCameraRecordMode
#define TuyaSmartCameraRecordMode ThingSmartCameraRecordMode
#endif

#ifndef TuyaSmartCameraRecordModeEvent 
#define TuyaSmartCameraRecordModeEvent ThingSmartCameraRecordModeEvent 
#endif 

#ifndef TuyaSmartCameraRecordModeAlways 
#define TuyaSmartCameraRecordModeAlways ThingSmartCameraRecordModeAlways 
#endif 

#ifndef TuyaSmartCameraRecordModedTime 
#define TuyaSmartCameraRecordModedTime ThingSmartCameraRecordModedTime 
#endif 

#ifndef TuyaSmartCameraPTZDirection
#define TuyaSmartCameraPTZDirection ThingSmartCameraPTZDirection
#endif

#ifndef TuyaSmartCameraPTZDirectionUp 
#define TuyaSmartCameraPTZDirectionUp ThingSmartCameraPTZDirectionUp 
#endif 

#ifndef TuyaSmartCameraPTZDirectionRight 
#define TuyaSmartCameraPTZDirectionRight ThingSmartCameraPTZDirectionRight 
#endif 

#ifndef TuyaSmartCameraPTZDirectionDown 
#define TuyaSmartCameraPTZDirectionDown ThingSmartCameraPTZDirectionDown 
#endif 

#ifndef TuyaSmartCameraPTZDirectionLeft 
#define TuyaSmartCameraPTZDirectionLeft ThingSmartCameraPTZDirectionLeft 
#endif 

#ifndef TuyaSmartCameraPowerMode
#define TuyaSmartCameraPowerMode ThingSmartCameraPowerMode
#endif

#ifndef TuyaSmartCameraPowerModeBattery 
#define TuyaSmartCameraPowerModeBattery ThingSmartCameraPowerModeBattery 
#endif 

#ifndef TuyaSmartCameraPowerModePlug 
#define TuyaSmartCameraPowerModePlug ThingSmartCameraPowerModePlug 
#endif 

#ifndef TuyaSmartCameraOutlineDPName 
#define TuyaSmartCameraOutlineDPName ThingSmartCameraOutlineDPName 
#endif 

#ifndef TuyaSmartCameraSDCardStatus 
#define TuyaSmartCameraSDCardStatus ThingSmartCameraSDCardStatus 
#endif 

#ifndef TuyaSmartCameraSDCardStatusNormal 
#define TuyaSmartCameraSDCardStatusNormal ThingSmartCameraSDCardStatusNormal 
#endif 

#ifndef TuyaSmartCameraSDCardStatusException 
#define TuyaSmartCameraSDCardStatusException ThingSmartCameraSDCardStatusException 
#endif 

#ifndef TuyaSmartCameraSDCardStatusMemoryLow 
#define TuyaSmartCameraSDCardStatusMemoryLow ThingSmartCameraSDCardStatusMemoryLow 
#endif 

#ifndef TuyaSmartCameraSDCardStatusFormatting 
#define TuyaSmartCameraSDCardStatusFormatting ThingSmartCameraSDCardStatusFormatting 
#endif 

#ifndef TuyaSmartCameraSDCardStatusNone 
#define TuyaSmartCameraSDCardStatusNone ThingSmartCameraSDCardStatusNone 
#endif 

#ifndef TuyaSmartCameraDPManager 
#define TuyaSmartCameraDPManager ThingSmartCameraDPManager 
#endif 

#ifndef TuyaSmartCameraDPObserver 
#define TuyaSmartCameraDPObserver ThingSmartCameraDPObserver 
#endif 

#ifndef TuyaSmartCameraLogManager 
#define TuyaSmartCameraLogManager ThingSmartCameraLogManager 
#endif 

#ifndef TuyaSmartCloudDayModel 
#define TuyaSmartCloudDayModel ThingSmartCloudDayModel 
#endif 

#ifndef TuyaSmartCloudTimeEventModel 
#define TuyaSmartCloudTimeEventModel ThingSmartCloudTimeEventModel 
#endif 

#ifndef TuyaSmartCloudTimePieceModel 
#define TuyaSmartCloudTimePieceModel ThingSmartCloudTimePieceModel 
#endif 

#ifndef TuyaSmartDoorBell 
#define TuyaSmartDoorBell ThingSmartDoorBell 
#endif 

#ifndef TuyaSmartACDoorBell 
#define TuyaSmartACDoorBell ThingSmartACDoorBell 
#endif 

#ifndef TuyaSmartDoorLock 
#define TuyaSmartDoorLock ThingSmartDoorLock 
#endif 

#ifndef TuyaSmartDevice 
#define TuyaSmartDevice ThingSmartDevice 
#endif 

#ifndef TuyaSmartDoorBellType 
#define TuyaSmartDoorBellType ThingSmartDoorBellType 
#endif 

#ifndef TYDoorBellError 
#define TYDoorBellError ThingDoorBellError 
#endif 

#ifndef TYDoorBellError_NoError 
#define TYDoorBellError_NoError ThingDoorBellError_NoError 
#endif 

#ifndef TYDoorBellError_AnsweredByOther 
#define TYDoorBellError_AnsweredByOther ThingDoorBellError_AnsweredByOther 
#endif 

#ifndef TYDoorBellError_DidCanceled 
#define TYDoorBellError_DidCanceled ThingDoorBellError_DidCanceled 
#endif 

#ifndef TYDoorBellError_TimeOut 
#define TYDoorBellError_TimeOut ThingDoorBellError_TimeOut 
#endif 

#ifndef TYDoorBellError_AnsweredBySelf 
#define TYDoorBellError_AnsweredBySelf ThingDoorBellError_AnsweredBySelf 
#endif 

#ifndef TYDoorBellError_NotAnswered 
#define TYDoorBellError_NotAnswered ThingDoorBellError_NotAnswered 
#endif 

#ifndef TYDoorBellError_NotSupport 
#define TYDoorBellError_NotSupport ThingDoorBellError_NotSupport 
#endif 

#ifndef TYDoorBellError_InvalidParam 
#define TYDoorBellError_InvalidParam ThingDoorBellError_InvalidParam 
#endif 

#ifndef TuyaSmartDoorBellCallModel 
#define TuyaSmartDoorBellCallModel ThingSmartDoorBellCallModel 
#endif 

#ifndef TuyaSmartDoorBellConfigDataSource 
#define TuyaSmartDoorBellConfigDataSource ThingSmartDoorBellConfigDataSource 
#endif 

#ifndef TuyaSmartDoorBellObserver 
#define TuyaSmartDoorBellObserver ThingSmartDoorBellObserver 
#endif 

#ifndef TuyaSmartDoorBellManager 
#define TuyaSmartDoorBellManager ThingSmartDoorBellManager 
#endif 

#ifndef TuyaSmartCameraKit 
#define TuyaSmartCameraKit ThingSmartCameraKit 
#endif 

#ifndef TuyaSmartCameraKit_version 
#define TuyaSmartCameraKit_version ThingSmartCameraKit_version 
#endif 

#ifndef TuyaSmartPTZControlDirection 
#define TuyaSmartPTZControlDirection ThingSmartPTZControlDirection 
#endif 

#ifndef TuyaSmartPTZControlDirectionUp 
#define TuyaSmartPTZControlDirectionUp ThingSmartPTZControlDirectionUp 
#endif 

#ifndef TuyaSmartPTZControlDirectionRightUp 
#define TuyaSmartPTZControlDirectionRightUp ThingSmartPTZControlDirectionRightUp 
#endif 

#ifndef TuyaSmartPTZControlDirectionRight 
#define TuyaSmartPTZControlDirectionRight ThingSmartPTZControlDirectionRight 
#endif 

#ifndef TuyaSmartPTZControlDirectionRightDown 
#define TuyaSmartPTZControlDirectionRightDown ThingSmartPTZControlDirectionRightDown 
#endif 

#ifndef TuyaSmartPTZControlDirectionDown 
#define TuyaSmartPTZControlDirectionDown ThingSmartPTZControlDirectionDown 
#endif 

#ifndef TuyaSmartPTZControlDirectionLeftDown 
#define TuyaSmartPTZControlDirectionLeftDown ThingSmartPTZControlDirectionLeftDown 
#endif 

#ifndef TuyaSmartPTZControlDirectionLeft 
#define TuyaSmartPTZControlDirectionLeft ThingSmartPTZControlDirectionLeft 
#endif 

#ifndef TuyaSmartPTZControlDirectionLeftUp 
#define TuyaSmartPTZControlDirectionLeftUp ThingSmartPTZControlDirectionLeftUp 
#endif 

#ifndef TuyaSmartPTZControlCruiseMode 
#define TuyaSmartPTZControlCruiseMode ThingSmartPTZControlCruiseMode 
#endif 

#ifndef TuyaSmartPTZControlCruiseModePanoramic 
#define TuyaSmartPTZControlCruiseModePanoramic ThingSmartPTZControlCruiseModePanoramic 
#endif 

#ifndef TuyaSmartPTZControlCruiseModeCollectionPoint 
#define TuyaSmartPTZControlCruiseModeCollectionPoint ThingSmartPTZControlCruiseModeCollectionPoint 
#endif 

#ifndef TuyaSmartPTZControlCruiseTimeMode 
#define TuyaSmartPTZControlCruiseTimeMode ThingSmartPTZControlCruiseTimeMode 
#endif 

#ifndef TuyaSmartPTZControlCruiseTimeModeAllDay 
#define TuyaSmartPTZControlCruiseTimeModeAllDay ThingSmartPTZControlCruiseTimeModeAllDay 
#endif 

#ifndef TuyaSmartPTZControlCruiseTimeModeCustom 
#define TuyaSmartPTZControlCruiseTimeModeCustom ThingSmartPTZControlCruiseTimeModeCustom 
#endif 

#ifndef TuyaSmartPTZControlCruiseState 
#define TuyaSmartPTZControlCruiseState ThingSmartPTZControlCruiseState 
#endif 

#ifndef TuyaSmartPTZControlCruiseStatePanoramic 
#define TuyaSmartPTZControlCruiseStatePanoramic ThingSmartPTZControlCruiseStatePanoramic 
#endif 

#ifndef TuyaSmartPTZControlCruiseStateCollectionPoint 
#define TuyaSmartPTZControlCruiseStateCollectionPoint ThingSmartPTZControlCruiseStateCollectionPoint 
#endif 

#ifndef TuyaSmartPTZControlCruiseStateNone 
#define TuyaSmartPTZControlCruiseStateNone ThingSmartPTZControlCruiseStateNone 
#endif 

#ifndef TYCameraCollectionPointModel 
#define TYCameraCollectionPointModel ThingCameraCollectionPointModel 
#endif 

#ifndef TuyaSmartPTZManager 
#define TuyaSmartPTZManager ThingSmartPTZManager 
#endif 

#ifndef TuyaSmartPTZManagerDeletate 
#define TuyaSmartPTZManagerDeletate ThingSmartPTZManagerDeletate 
#endif 

#ifndef TuyaSmartCameraMessage 
#define TuyaSmartCameraMessage ThingSmartCameraMessage 
#endif 

#ifndef TuyaCameraMessageAttachmentPicture 
#define TuyaCameraMessageAttachmentPicture ThingCameraMessageAttachmentPicture 
#endif 

#ifndef TuyaCameraMessageAttachmentVideo 
#define TuyaCameraMessageAttachmentVideo ThingCameraMessageAttachmentVideo 
#endif 

#ifndef TuyaCameraMessageAttachmentAudio 
#define TuyaCameraMessageAttachmentAudio ThingCameraMessageAttachmentAudio 
#endif 

#ifndef TuyaSmartCameraMessageModel 
#define TuyaSmartCameraMessageModel ThingSmartCameraMessageModel 
#endif 

#ifndef TuyaSmartCameraMessageSchemeModel 
#define TuyaSmartCameraMessageSchemeModel ThingSmartCameraMessageSchemeModel 
#endif 

#ifndef TuyaSmartCameraKitVersionNumber 
#define TuyaSmartCameraKitVersionNumber ThingSmartCameraKitVersionNumber 
#endif 

#ifndef TuyaSmartPlaybackDate 
#define TuyaSmartPlaybackDate ThingSmartPlaybackDate 
#endif 

#ifndef TuyaSmartCameraSDCardStorageDPName
#define TuyaSmartCameraSDCardStorageDPName ThingSmartCameraSDCardStorageDPName
#endif

#ifndef TuyaSmartCameraSDCardFormatDPName
#define TuyaSmartCameraSDCardFormatDPName ThingSmartCameraSDCardFormatDPName
#endif

#ifndef TuyaSmartCameraSDCardFormatStateDPName
#define TuyaSmartCameraSDCardFormatStateDPName ThingSmartCameraSDCardFormatStateDPName
#endif

#ifndef TuyaSmartCameraBasicIndicatorDPName
#define TuyaSmartCameraBasicIndicatorDPName ThingSmartCameraBasicIndicatorDPName
#endif

#ifndef TuyaSmartCameraWirelessElectricityDPName
#define TuyaSmartCameraWirelessElectricityDPName ThingSmartCameraWirelessElectricityDPName
#endif

#ifndef TuyaSmartCameraWirelessPowerModeDPName
#define TuyaSmartCameraWirelessPowerModeDPName ThingSmartCameraWirelessPowerModeDPName
#endif

#ifndef TuyaSmartCameraWirelessBatteryLockDPName
#define TuyaSmartCameraWirelessBatteryLockDPName ThingSmartCameraWirelessBatteryLockDPName
#endif

#ifndef TuyaSmartCameraRecordModeDPName
#define TuyaSmartCameraRecordModeDPName ThingSmartCameraRecordModeDPName
#endif

#ifndef TuyaSmartCameraSDCardRecordDPName
#define TuyaSmartCameraSDCardRecordDPName ThingSmartCameraSDCardRecordDPName
#endif

#ifndef TuyaSmartCameraSDCardStatusDPName
#define TuyaSmartCameraSDCardStatusDPName ThingSmartCameraSDCardStatusDPName
#endif

#ifndef TuyaSmartCameraDecibelSensitivityDPName
#define TuyaSmartCameraDecibelSensitivityDPName ThingSmartCameraDecibelSensitivityDPName
#endif

#ifndef TuyaSmartCameraBasicFlipDPName
#define TuyaSmartCameraBasicFlipDPName ThingSmartCameraBasicFlipDPName
#endif

#ifndef TuyaSmartCameraBasicOSDDPName
#define TuyaSmartCameraBasicOSDDPName ThingSmartCameraBasicOSDDPName
#endif

#ifndef TuyaSmartCameraBasicPrivateDPName
#define TuyaSmartCameraBasicPrivateDPName ThingSmartCameraBasicPrivateDPName
#endif

#ifndef TuyaSmartCameraBasicNightvisionDPName
#define TuyaSmartCameraBasicNightvisionDPName ThingSmartCameraBasicNightvisionDPName
#endif

#ifndef TuyaSmartCameraBasicPIRDPName
#define TuyaSmartCameraBasicPIRDPName ThingSmartCameraBasicPIRDPName
#endif

#ifndef TuyaSmartCameraMotionDetectDPName
#define TuyaSmartCameraMotionDetectDPName ThingSmartCameraMotionDetectDPName
#endif

#ifndef TuyaSmartCameraMotionSensitivityDPName
#define TuyaSmartCameraMotionSensitivityDPName ThingSmartCameraMotionSensitivityDPName
#endif

#ifndef TuyaSmartCameraDecibelDetectDPName
#define TuyaSmartCameraDecibelDetectDPName ThingSmartCameraDecibelDetectDPName
#endif

#ifndef TuyaSmartCameraSDCardUnmountDPName
#define TuyaSmartCameraSDCardUnmountDPName ThingSmartCameraSDCardUnmountDPName
#endif

#ifndef TuyaSmartCameraSDCardMuteRecordDPName
#define TuyaSmartCameraSDCardMuteRecordDPName ThingSmartCameraSDCardMuteRecordDPName
#endif

#ifndef TuyaSmartCameraPTZControlDPName
#define TuyaSmartCameraPTZControlDPName ThingSmartCameraPTZControlDPName
#endif

#ifndef TuyaSmartCameraPTZStopDPName
#define TuyaSmartCameraPTZStopDPName ThingSmartCameraPTZStopDPName
#endif

#ifndef TuyaSmartCameraWirelessLowpowerDPName
#define TuyaSmartCameraWirelessLowpowerDPName ThingSmartCameraWirelessLowpowerDPName
#endif

#ifndef TuyaSmartCameraWirelessAwakeDPName
#define TuyaSmartCameraWirelessAwakeDPName ThingSmartCameraWirelessAwakeDPName
#endif

#endif
