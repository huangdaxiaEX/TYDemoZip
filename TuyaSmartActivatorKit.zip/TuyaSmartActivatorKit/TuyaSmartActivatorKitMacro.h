#ifndef TuyaSmartActivatorKitMacro_h
#define TuyaSmartActivatorKitMacro_h

#ifndef TuyaSmartActivator 
#define TuyaSmartActivator ThingSmartActivator 
#endif 

#ifndef TYSuccessString 
#define TYSuccessString ThingSuccessString 
#endif 

#ifndef TYFailureError 
#define TYFailureError ThingFailureError 
#endif 

#ifndef TuyaSmartPegasusActivator 
#define TuyaSmartPegasusActivator ThingSmartPegasusActivator 
#endif 

#ifndef TuyaSmartAutoActivator 
#define TuyaSmartAutoActivator ThingSmartAutoActivator 
#endif 

#ifndef TYSuccessHandler 
#define TYSuccessHandler ThingSuccessHandler 
#endif 

#ifndef TuyaSmartDirectlyConnectedActivator 
#define TuyaSmartDirectlyConnectedActivator ThingSmartDirectlyConnectedActivator 
#endif 

#ifndef TYSuccessDict 
#define TYSuccessDict ThingSuccessDict 
#endif 

#ifndef TuyaSmartDiscovery 
#define TuyaSmartDiscovery ThingSmartDiscovery 
#endif 

#ifndef TuyaSmartHomeKitActivator 
#define TuyaSmartHomeKitActivator ThingSmartHomeKitActivator 
#endif 

#ifndef TuyaSmartRouterActivator 
#define TuyaSmartRouterActivator ThingSmartRouterActivator 
#endif 

#ifndef TuyaSmartActivatorKit 
#define TuyaSmartActivatorKit ThingSmartActivatorKit 
#endif 

#ifndef bindTuyaLinkDeviceWithQRCode
#define bindTuyaLinkDeviceWithQRCode bindThingLinkDeviceWithQRCode
#endif 

#ifndef TuyaSmartTuyaLinkActivator
#define TuyaSmartTuyaLinkActivator ThingSmartThingLinkActivator
#endif


#endif
