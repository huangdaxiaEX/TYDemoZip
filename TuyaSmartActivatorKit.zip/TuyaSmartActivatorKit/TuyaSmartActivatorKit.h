//
// TuyaSmartActivatorKit.h
// TuyaSmartActivatorKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartActivatorKit.

#ifndef TuyaSmartActivatorKit_h
#define TuyaSmartActivatorKit_h

#import "TuyaSmartActivatorKitMacro.h"

#import <TuyaSmartDeviceKit/TuyaSmartDeviceKit.h>
#import <TuyaSmartActivatorCoreKit/TuyaSmartActivatorCoreKit.h>

#import "TuyaSmartActivator+Home.h"
#import "TuyaSmartAutoActivator+Home.h"
#import "TuyaSmartDiscovery+Home.h"
#import "TuyaSmartHomeKitActivator+Home.h"
#import "TuyaSmartPegasusActivator+Home.h"
#import "TuyaSmartRouterActivator+Home.h"
#import "TuyaSmartDirectlyConnectedActivator+Home.h"

#endif /* TuyaSmartActivatorKit_h */
