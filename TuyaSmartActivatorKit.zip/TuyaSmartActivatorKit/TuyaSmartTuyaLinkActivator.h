//
// TuyaSmartTuyaLinkActivator.h
// TuyaSmartActivatorKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartTuyaLinkActivator.

#import "TuyaSmartActivatorKitMacro.h"
#import <ThingSmartActivatorKit/ThingSmartThingLinkActivator.h>
#import <Foundation/Foundation.h>
#import <TuyaSmartDeviceKit/TuyaSmartDeviceKit.h>
