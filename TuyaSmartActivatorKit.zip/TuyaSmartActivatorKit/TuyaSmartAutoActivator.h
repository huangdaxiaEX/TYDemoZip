//
// TuyaSmartAutoActivator.h
// TuyaSmartActivatorKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartAutoActivator.

#import "TuyaSmartActivatorKitMacro.h"
#import <ThingSmartActivatorKit/ThingSmartAutoActivator.h>
#import <TuyaSmartActivatorCoreKit/TuyaSmartAutoActivator.h>
