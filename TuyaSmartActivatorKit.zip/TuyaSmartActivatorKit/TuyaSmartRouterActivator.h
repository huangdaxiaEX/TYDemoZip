//
// TuyaSmartRouterActivator.h
// TuyaSmartActivatorKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartRouterActivator.

#import "TuyaSmartActivatorKitMacro.h"
#import <ThingSmartActivatorKit/ThingSmartRouterActivator.h>
#import <TuyaSmartActivatorCoreKit/TuyaSmartRouterActivator.h>
