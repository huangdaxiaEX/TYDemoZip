//
// TYMp4AVAssetWriter.h
// TuyaCameraSDK
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TYMp4AVAssetWriter.

#import "TuyaCameraSDKMacro.h"
#import <ThingCameraSDK/ThingMp4AVAssetWriter.h>
#import <Foundation/Foundation.h>
