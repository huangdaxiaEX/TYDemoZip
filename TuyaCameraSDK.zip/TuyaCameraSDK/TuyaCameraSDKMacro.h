#ifndef TuyaCameraSDKMacro_h
#define TuyaCameraSDKMacro_h

#ifndef AUDIO_SAMPLE_TYPE 
#define AUDIO_SAMPLE_TYPE AUDIO_SAMPLE_TYPE
#endif 

#ifndef TYAudioQueuePcmPlayer 
#define TYAudioQueuePcmPlayer ThingAudioQueuePcmPlayer 
#endif 

#ifndef __TYiOSMp4RecorderCAPI_H__ 
#define __TYiOSMp4RecorderCAPI_H__ __ThingiOSMp4RecorderCAPI_H__ 
#endif 

#ifndef TuyaDeviceEngineDelegate 
#define TuyaDeviceEngineDelegate ThingDeviceEngineDelegate 
#endif 

#ifndef TYNVRDelegate 
#define TYNVRDelegate ThingNVRDelegate 
#endif 

#ifndef TYNVR 
#define TYNVR ThingNVR 
#endif 

#ifndef TYMp4Writer 
#define TYMp4Writer ThingMp4Writer 
#endif 

#ifndef TuyaCameraDelegate 
#define TuyaCameraDelegate ThingCameraDelegate 
#endif 

#ifndef TuyaCamera 
#define TuyaCamera ThingCamera 
#endif 

#ifndef TuyaVideoClarityMode 
#define TuyaVideoClarityMode ThingVideoClarityMode 
#endif 

#ifndef TuyaPlayBackSpeedMode 
#define TuyaPlayBackSpeedMode ThingPlayBackSpeedMode 
#endif 

#ifndef TuyaRotateMode 
#define TuyaRotateMode ThingRotateMode 
#endif 

#ifndef TuyaCameraSDK_version 
#define TuyaCameraSDK_version ThingCameraSDK_version 
#endif 

#ifndef TYAVMuxer 
#define TYAVMuxer ThingAVMuxer 
#endif 

#ifndef kTYAVMuxer_NoErr 
#define kTYAVMuxer_NoErr kThingAVMuxer_NoErr 
#endif 

#ifndef kTYAVMuxer_Err 
#define kTYAVMuxer_Err kThingAVMuxer_Err 
#endif 

#ifndef kTYAVMuxer_InvalidParam 
#define kTYAVMuxer_InvalidParam kThingAVMuxer_InvalidParam 
#endif 

#ifndef kTYAVMuxer_Unsupported 
#define kTYAVMuxer_Unsupported kThingAVMuxer_Unsupported 
#endif 

#ifndef kTYAVMuxer_Undefined_Behavior 
#define kTYAVMuxer_Undefined_Behavior kThingAVMuxer_Undefined_Behavior 
#endif 

#ifndef TYAudioQueuePcmPickerDelegate 
#define TYAudioQueuePcmPickerDelegate ThingAudioQueuePcmPickerDelegate 
#endif 

#ifndef TYAudioQueuePcmPicker 
#define TYAudioQueuePcmPicker ThingAudioQueuePcmPicker 
#endif 

#ifndef __TUYACAMERADEFINES_H__ 
#define __TUYACAMERADEFINES_H__ __THINGCAMERADEFINES_H__ 
#endif 

#ifndef TuyaDeviceType 
#define TuyaDeviceType ThingDeviceType 
#endif 

#ifndef kTuyaErrCode_NoErr 
#define kTuyaErrCode_NoErr kThingErrCode_NoErr 
#endif 

#ifndef kTuyaErrCode_FragmentEnd 
#define kTuyaErrCode_FragmentEnd kThingErrCode_FragmentEnd 
#endif 

#ifndef kTuyaErrCode_Err 
#define kTuyaErrCode_Err kThingErrCode_Err 
#endif 

#ifndef kTuyaErrCode_CameraNotInitialized 
#define kTuyaErrCode_CameraNotInitialized kThingErrCode_CameraNotInitialized 
#endif 

#ifndef kTuyaErrCode_NotConnected 
#define kTuyaErrCode_NotConnected kThingErrCode_NotConnected 
#endif 

#ifndef kTuyaErrCode_SessionInvalid 
#define kTuyaErrCode_SessionInvalid kThingErrCode_SessionInvalid 
#endif 

#ifndef kTuyaErrCode_TimeOut 
#define kTuyaErrCode_TimeOut kThingErrCode_TimeOut 
#endif 

#ifndef kTuyaErrCode_ConnectionCancelled 
#define kTuyaErrCode_ConnectionCancelled kThingErrCode_ConnectionCancelled 
#endif 

#ifndef kTuyaErrCode_DeviceNotOnline 
#define kTuyaErrCode_DeviceNotOnline kThingErrCode_DeviceNotOnline 
#endif 

#ifndef kTuyaErrCode_CancelByUser 
#define kTuyaErrCode_CancelByUser kThingErrCode_CancelByUser 
#endif 

#ifndef kTuyaErrCode_InvalidCommand 
#define kTuyaErrCode_InvalidCommand kThingErrCode_InvalidCommand 
#endif 

#ifndef kTuyaErrCode_ParamsInvalid 
#define kTuyaErrCode_ParamsInvalid kThingErrCode_ParamsInvalid 
#endif 

#ifndef kTuyaErrCode_DataInvalid 
#define kTuyaErrCode_DataInvalid kThingErrCode_DataInvalid 
#endif 

#ifndef kTuyaErrCode_Interrupted 
#define kTuyaErrCode_Interrupted kThingErrCode_Interrupted 
#endif 

#ifndef kTuyaErrCode_OperationNotAllowed 
#define kTuyaErrCode_OperationNotAllowed kThingErrCode_OperationNotAllowed 
#endif 

#ifndef kTuyaErrCode_VersionNotSupported 
#define kTuyaErrCode_VersionNotSupported kThingErrCode_VersionNotSupported 
#endif 

#ifndef kTuyaErrCode_Busy 
#define kTuyaErrCode_Busy kThingErrCode_Busy 
#endif 

#ifndef kTuyaErrCode_OutOfMemory 
#define kTuyaErrCode_OutOfMemory kThingErrCode_OutOfMemory 
#endif 

#ifndef kTuyaErrCode_DownloadFailed 
#define kTuyaErrCode_DownloadFailed kThingErrCode_DownloadFailed 
#endif 

#ifndef kTuyaErrCode_NotPlayBacking 
#define kTuyaErrCode_NotPlayBacking kThingErrCode_NotPlayBacking 
#endif 

#ifndef kTuyaErrCode_SetPlaySpeedFailed 
#define kTuyaErrCode_SetPlaySpeedFailed kThingErrCode_SetPlaySpeedFailed 
#endif 

#ifndef kTuyaErrCode_NotPlayCloudDataing 
#define kTuyaErrCode_NotPlayCloudDataing kThingErrCode_NotPlayCloudDataing 
#endif 

#ifndef kTuyaErrCode_DelPlaybackDataFiled 
#define kTuyaErrCode_DelPlaybackDataFiled kThingErrCode_DelPlaybackDataFiled 
#endif 

#ifndef kTuyaErrCode_DownLoadFragmentError 
#define kTuyaErrCode_DownLoadFragmentError kThingErrCode_DownLoadFragmentError 
#endif 

#ifndef kTuyaErrCode_JpgSupportedOnly 
#define kTuyaErrCode_JpgSupportedOnly kThingErrCode_JpgSupportedOnly 
#endif 

#ifndef kTuyaErrCode_PLDownLoadStateError 
#define kTuyaErrCode_PLDownLoadStateError kThingErrCode_PLDownLoadStateError 
#endif 

#ifndef kTuyaErrCode_DownLoadImageFailed 
#define kTuyaErrCode_DownLoadImageFailed kThingErrCode_DownLoadImageFailed 
#endif 

#ifndef kTuyaErrCode_CurlError 
#define kTuyaErrCode_CurlError kThingErrCode_CurlError 
#endif 

#ifndef kTuyaErrCode_Mp4NotRecording 
#define kTuyaErrCode_Mp4NotRecording kThingErrCode_Mp4NotRecording 
#endif 

#ifndef kTuyaErrCode_Mp4SetAVConfigFailed 
#define kTuyaErrCode_Mp4SetAVConfigFailed kThingErrCode_Mp4SetAVConfigFailed 
#endif 

#ifndef kTuyaErrCode_Mp4HeaderWriteFailed 
#define kTuyaErrCode_Mp4HeaderWriteFailed kThingErrCode_Mp4HeaderWriteFailed 
#endif 

#ifndef kTuyaErrCode_Mp4TrailerWriteFailed 
#define kTuyaErrCode_Mp4TrailerWriteFailed kThingErrCode_Mp4TrailerWriteFailed 
#endif 

#ifndef kTuyaErrCode_StartAudioTalkFailed 
#define kTuyaErrCode_StartAudioTalkFailed kThingErrCode_StartAudioTalkFailed 
#endif 

#ifndef kTuyaErrCode_ResponseReturnErr 
#define kTuyaErrCode_ResponseReturnErr kThingErrCode_ResponseReturnErr 
#endif 

#ifndef kTuyaErrCode_ErrOccurDataTransport 
#define kTuyaErrCode_ErrOccurDataTransport kThingErrCode_ErrOccurDataTransport 
#endif 

#ifndef kTuyaErrCode_FileNotExists 
#define kTuyaErrCode_FileNotExists kThingErrCode_FileNotExists 
#endif 

#ifndef kTuyaErrCode_CreateFileFailed 
#define kTuyaErrCode_CreateFileFailed kThingErrCode_CreateFileFailed 
#endif 

#ifndef kTuyaErrCode_TooManyFilesDownload 
#define kTuyaErrCode_TooManyFilesDownload kThingErrCode_TooManyFilesDownload 
#endif 

#ifndef kTuyaErrCode_DeleteFilesFailed 
#define kTuyaErrCode_DeleteFilesFailed kThingErrCode_DeleteFilesFailed 
#endif 

#ifndef kTuyaErrCode_JpegFilterInitFailed 
#define kTuyaErrCode_JpegFilterInitFailed kThingErrCode_JpegFilterInitFailed 
#endif 

#ifndef kTuyaErrCode_AvformatOpenFailed 
#define kTuyaErrCode_AvformatOpenFailed kThingErrCode_AvformatOpenFailed 
#endif 

#ifndef kTuyaErrCode_FirstIFrameNotArrived 
#define kTuyaErrCode_FirstIFrameNotArrived kThingErrCode_FirstIFrameNotArrived 
#endif 

#ifndef kTuyaErrCode_FilterNotSupportCodec 
#define kTuyaErrCode_FilterNotSupportCodec kThingErrCode_FilterNotSupportCodec 
#endif 

#ifndef kTuyaErrCode_CloudDataAVParamChanged 
#define kTuyaErrCode_CloudDataAVParamChanged kThingErrCode_CloudDataAVParamChanged 
#endif 

#ifndef kTuyaSessionStatus_Connected 
#define kTuyaSessionStatus_Connected kThingSessionStatus_Connected 
#endif 

#ifndef kTuyaSessionStatus_ConnectTimeout 
#define kTuyaSessionStatus_ConnectTimeout kThingSessionStatus_ConnectTimeout 
#endif 

#ifndef kTuyaSessionStatus_ClosedRemote 
#define kTuyaSessionStatus_ClosedRemote kThingSessionStatus_ClosedRemote 
#endif 

#ifndef kTuyaSessionStatus_ClosedTimeOut 
#define kTuyaSessionStatus_ClosedTimeOut kThingSessionStatus_ClosedTimeOut 
#endif 

#ifndef kTuyaSessionStatus_ClosedCalled 
#define kTuyaSessionStatus_ClosedCalled kThingSessionStatus_ClosedCalled 
#endif 

#ifndef kTuyaVideoClarityProflow 
#define kTuyaVideoClarityProflow kThingVideoClarityProflow 
#endif 

#ifndef kTuyaVideoClarityStandard 
#define kTuyaVideoClarityStandard kThingVideoClarityStandard 
#endif 

#ifndef kTuyaVideoClarityHigh 
#define kTuyaVideoClarityHigh kThingVideoClarityHigh 
#endif 

#ifndef kTuyaVideoClaritySuperHigh 
#define kTuyaVideoClaritySuperHigh kThingVideoClaritySuperHigh 
#endif 

#ifndef kTuyaVideoClarityAudioOnly 
#define kTuyaVideoClarityAudioOnly kThingVideoClarityAudioOnly 
#endif 

#ifndef TY_VIDEO_CLARITY_PROFLOW 
#define TY_VIDEO_CLARITY_PROFLOW Thing_VIDEO_CLARIThing_PROFLOW 
#endif 

#ifndef TY_VIDEO_CLARITY_STANDARD 
#define TY_VIDEO_CLARITY_STANDARD Thing_VIDEO_CLARIThing_STANDARD 
#endif 

#ifndef TY_VIDEO_CLARITY_HIGH 
#define TY_VIDEO_CLARITY_HIGH Thing_VIDEO_CLARIThing_HIGH 
#endif 

#ifndef TY_VIDEO_CLARITY_S_HIGH 
#define TY_VIDEO_CLARITY_S_HIGH Thing_VIDEO_CLARIThing_S_HIGH 
#endif 

#ifndef TY_VIDEO_CLARITY_SS_HIGH 
#define TY_VIDEO_CLARITY_SS_HIGH Thing_VIDEO_CLARIThing_SS_HIGH 
#endif 

#ifndef TY_VIDEO_OUTPUT_FORMAT_RAWDATA 
#define TY_VIDEO_OUTPUT_FORMAT_RAWDATA Thing_VIDEO_OUTPUT_FORMAT_RAWDATA 
#endif 

#ifndef TY_VIDEO_OUTPUT_FORMAT_YUV 
#define TY_VIDEO_OUTPUT_FORMAT_YUV Thing_VIDEO_OUTPUT_FORMAT_YUV 
#endif 

#ifndef TY_AUDIO_OUTPUT_FORMAT_RAWDATA 
#define TY_AUDIO_OUTPUT_FORMAT_RAWDATA Thing_AUDIO_OUTPUT_FORMAT_RAWDATA 
#endif 

#ifndef TY_AUDIO_OUTPUT_FORMAT_PCM 
#define TY_AUDIO_OUTPUT_FORMAT_PCM Thing_AUDIO_OUTPUT_FORMAT_PCM 
#endif 

#ifndef TY_SPEED_05TIMES 
#define TY_SPEED_05TIMES Thing_SPEED_05TIMES 
#endif 

#ifndef TY_SPEED_10TIMES 
#define TY_SPEED_10TIMES Thing_SPEED_10TIMES 
#endif 

#ifndef TY_SPEED_15TIMES 
#define TY_SPEED_15TIMES Thing_SPEED_15TIMES 
#endif 

#ifndef TY_SPEED_20TIMES 
#define TY_SPEED_20TIMES Thing_SPEED_20TIMES 
#endif 

#ifndef TY_SPEED_25TIMES 
#define TY_SPEED_25TIMES Thing_SPEED_25TIMES 
#endif 

#ifndef TY_SPEED_30TIMES 
#define TY_SPEED_30TIMES Thing_SPEED_30TIMES 
#endif 

#ifndef TY_SPEED_35TIMES 
#define TY_SPEED_35TIMES Thing_SPEED_35TIMES 
#endif 

#ifndef TY_SPEED_40TIMES 
#define TY_SPEED_40TIMES Thing_SPEED_40TIMES 
#endif 

#ifndef TY_SPEED_80TIMES 
#define TY_SPEED_80TIMES Thing_SPEED_80TIMES 
#endif 

#ifndef TY_SPEED_160TIMES 
#define TY_SPEED_160TIMES Thing_SPEED_160TIMES 
#endif 

#ifndef TY_SPEED_320TIMES 
#define TY_SPEED_320TIMES Thing_SPEED_320TIMES 
#endif 

#ifndef TY_PLAYBACK_EVENT_TYPE_NONE 
#define TY_PLAYBACK_EVENT_TYPE_NONE Thing_PLAYBACK_EVENT_TYPE_NONE
#endif 

#ifndef TY_PLAYBACK_EVENT_TYPE_MD 
#define TY_PLAYBACK_EVENT_TYPE_MD Thing_PLAYBACK_EVENT_TYPE_MD
#endif 

#ifndef TY_PLAYBACK_EVENT_TYPE_FACE 
#define TY_PLAYBACK_EVENT_TYPE_FACE Thing_PLAYBACK_EVENT_TYPE_FACE
#endif 

#ifndef TY_PLAYBACK_EVENT_TYPE_BODY 
#define TY_PLAYBACK_EVENT_TYPE_BODY Thing_PLAYBACK_EVENT_TYPE_BODY
#endif 

#ifndef TY_PLAYBACK_EVENT_TYPE_MAX 
#define TY_PLAYBACK_EVENT_TYPE_MAX Thing_PLAYBACK_EVENT_TYPE_MAX 
#endif 

#ifndef TY_ROTATE_NORMAL 
#define TY_ROTATE_NORMAL Thing_ROTATE_NORMAL 
#endif 

#ifndef TY_ROTATE_90_ANGLE 
#define TY_ROTATE_90_ANGLE Thing_ROTATE_90_ANGLE 
#endif 

#ifndef TY_ROTATE_180_ANGLE 
#define TY_ROTATE_180_ANGLE Thing_ROTATE_180_ANGLE 
#endif 

#ifndef TY_ROTATE_270_ANGLE 
#define TY_ROTATE_270_ANGLE Thing_ROTATE_270_ANGLE 
#endif 

#ifndef TY_SMART_NET_WEAK 
#define TY_SMART_NET_WEAK Thing_SMART_NET_WEAK 
#endif 

#ifndef TY_SMART_NET_WIFI 
#define TY_SMART_NET_WIFI Thing_SMART_NET_WIFI 
#endif 

#ifndef TY_SMART_NET_GPRS_4G 
#define TY_SMART_NET_GPRS_4G Thing_SMART_NET_GPRS_4G 
#endif 

#ifndef TY_SMART_NET_GPRS_5G 
#define TY_SMART_NET_GPRS_5G Thing_SMART_NET_GPRS_5G 
#endif 

#ifndef TY_SMART_NET_UNKNOWN 
#define TY_SMART_NET_UNKNOWN Thing_SMART_NET_UNKNOWN 
#endif 

#ifndef TY_MIRROR_CLOSE 
#define TY_MIRROR_CLOSE Thing_MIRROR_CLOSE 
#endif 

#ifndef TY_MIRROR_HORIZONTAL 
#define TY_MIRROR_HORIZONTAL Thing_MIRROR_HORIZONTAL 
#endif 

#ifndef TY_MIRROR_VERTICALLY 
#define TY_MIRROR_VERTICALLY Thing_MIRROR_VERTICALLY 
#endif 

#ifndef TYPlayBackFragmentModel 
#define TYPlayBackFragmentModel ThingPlayBackFragmentModel 
#endif 

#ifndef TuyaCameraEngineDelegate 
#define TuyaCameraEngineDelegate ThingCameraEngineDelegate 
#endif 

#ifndef TuyaCameraEngine 
#define TuyaCameraEngine ThingCameraEngine 
#endif 

#ifndef TuyaSmartNetType 
#define TuyaSmartNetType ThingSmartNetType 
#endif 



#endif
