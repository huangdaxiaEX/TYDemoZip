//
// TuyaSmartPairingCoreKit.h
// TuyaSmartPairingCoreKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartPairingCoreKit.

#ifndef TuyaSmartPairingCoreKit_h
#define TuyaSmartPairingCoreKit_h

#import "TuyaSmartPairingCoreKitMacro.h"

#import <TuyaSmartPairingCoreKit/TuyaSmartPairingHeader.h>

#import <TuyaSmartPairingCoreKit/TuyaSmartPairConfiguration.h>
#import <TuyaSmartPairingCoreKit/TuyaSmartLogTrackConfiguration.h>

#import <TuyaSmartPairingCoreKit/TuyaSmartPairSuccessDevice.h>
#import <TuyaSmartPairingCoreKit/TuyaSmartPairErrorDevice.h>

#import <TuyaSmartPairingCoreKit/TuyaSmartPairingHandlerDelegate.h>
#import <TuyaSmartPairingCoreKit/TuyaSmartPairingParam.h>
#import <TuyaSmartPairingCoreKit/TYPairingManager.h>
#import <TuyaSmartPairingCoreKit/TYPairingProtocol.h>


#endif /* TuyaSmartPairingCoreKit_h */
