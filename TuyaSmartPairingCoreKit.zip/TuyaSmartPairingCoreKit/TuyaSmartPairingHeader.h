//
// TuyaSmartPairingHeader.h
// TuyaSmartPairingCoreKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartPairingHeader.

#import "TuyaSmartPairingCoreKitMacro.h"
#import <ThingSmartPairingCoreKit/ThingSmartPairingHeader.h>
#import <Foundation/Foundation.h>
