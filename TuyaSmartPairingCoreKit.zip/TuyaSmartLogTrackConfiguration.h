//
// TuyaSmartLogTrackConfiguration.h
// TuyaSmartPairingCoreKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartLogTrackConfiguration.

#import "TuyaSmartPairingCoreKitMacro.h"
#import <ThingSmartPairingCoreKit/ThingSmartLogTrackConfiguration.h>
#import <Foundation/Foundation.h>
