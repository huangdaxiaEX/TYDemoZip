//
// TuyaSmartPairErrorDevice.h
// TuyaSmartPairingCoreKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartPairErrorDevice.

#import "TuyaSmartPairingCoreKitMacro.h"
#import <ThingSmartPairingCoreKit/ThingSmartPairErrorDevice.h>
#import <Foundation/Foundation.h>
