#ifndef TuyaSmartPairingCoreKitMacro_h
#define TuyaSmartPairingCoreKitMacro_h

#ifndef TYPairingErrorCode 
#define TYPairingErrorCode ThingPairingErrorCode 
#endif 

#ifndef TYPairingErrorCodeSuccess 
#define TYPairingErrorCodeSuccess ThingPairingErrorCodeSuccess 
#endif 

#ifndef TYPairingErrorInvalidParamters 
#define TYPairingErrorInvalidParamters ThingPairingErrorInvalidParamters 
#endif 

#ifndef TYPairingErrorNotInPairing 
#define TYPairingErrorNotInPairing ThingPairingErrorNotInPairing 
#endif 

#ifndef TYPairingErrorOnlyAPPairingSupported 
#define TYPairingErrorOnlyAPPairingSupported ThingPairingErrorOnlyAPPairingSupported 
#endif 

#ifndef TYPairingErrorAPDirectNotSupported 
#define TYPairingErrorAPDirectNotSupported ThingPairingErrorAPDirectNotSupported 
#endif 

#ifndef TYPairingErrorInvalidDeviceUUID 
#define TYPairingErrorInvalidDeviceUUID ThingPairingErrorInvalidDeviceUUID 
#endif 

#ifndef TYPairingErrorDeviceNotSupported 
#define TYPairingErrorDeviceNotSupported ThingPairingErrorDeviceNotSupported 
#endif 

#ifndef TYPairingErrorDeviceIPNotFound 
#define TYPairingErrorDeviceIPNotFound ThingPairingErrorDeviceIPNotFound 
#endif 

#ifndef TYPairingErrorFailedToConnectWiFi 
#define TYPairingErrorFailedToConnectWiFi ThingPairingErrorFailedToConnectWiFi 
#endif 

#ifndef TYPairingErrorTimeout 
#define TYPairingErrorTimeout ThingPairingErrorTimeout 
#endif 

#ifndef TuyaSmartPairingConnectWiFiFailedErrorDomain 
#define TuyaSmartPairingConnectWiFiFailedErrorDomain ThingSmartPairingConnectWiFiFailedErrorDomain 
#endif 

#ifndef TYPairingCore 
#define TYPairingCore ThingPairingCore 
#endif 

#ifndef TuyaSmartPairingResumeConfigWiFiParam 
#define TuyaSmartPairingResumeConfigWiFiParam ThingSmartPairingResumeConfigWiFiParam 
#endif 

#ifndef TuyaSmartPairingWiFiInfo 
#define TuyaSmartPairingWiFiInfo ThingSmartPairingWiFiInfo 
#endif 

#ifndef TuyaSmartPairingScanWiFiListParam 
#define TuyaSmartPairingScanWiFiListParam ThingSmartPairingScanWiFiListParam 
#endif 

#ifndef TuyaSmartPairingParam 
#define TuyaSmartPairingParam ThingSmartPairingParam 
#endif 

#ifndef TuyaSmartPairingCoreKit 
#define TuyaSmartPairingCoreKit ThingSmartPairingCoreKit 
#endif 

#ifndef TYPollingRetry 
#define TYPollingRetry ThingPollingRetry 
#endif 

#ifndef TYApCompensation 
#define TYApCompensation ThingApCompensation 
#endif 

#ifndef TuyaSmartPairingHandlerDelegate 
#define TuyaSmartPairingHandlerDelegate ThingSmartPairingHandlerDelegate 
#endif 

#ifndef TYActivatorStep 
#define TYActivatorStep ThingActivatorStep 
#endif 

#ifndef TYSuccessHandler 
#define TYSuccessHandler ThingSuccessHandler 
#endif 

#ifndef TYFailureError 
#define TYFailureError ThingFailureError 
#endif 

#ifndef TYSuccessDict 
#define TYSuccessDict ThingSuccessDict 
#endif 

#ifndef TuyaSmartPairConfiguration 
#define TuyaSmartPairConfiguration ThingSmartPairConfiguration 
#endif 

#ifndef TuyaSmartLogTrackConfiguration 
#define TuyaSmartLogTrackConfiguration ThingSmartLogTrackConfiguration 
#endif 

#ifndef TYPairingManager 
#define TYPairingManager ThingPairingManager 
#endif 

#ifndef TYSuccessString 
#define TYSuccessString ThingSuccessString 
#endif 

#ifndef TYActivatorMode 
#define TYActivatorMode ThingActivatorMode 
#endif 

#ifndef TuyaSmartLogTrackHandleDelegate 
#define TuyaSmartLogTrackHandleDelegate ThingSmartLogTrackHandleDelegate 
#endif 

#ifndef TuyaSmartPairingHeader 
#define TuyaSmartPairingHeader ThingSmartPairingHeader 
#endif 

#ifndef TYActivatorModeEZ 
#define TYActivatorModeEZ ThingActivatorModeEZ 
#endif 

#ifndef TYActivatorModeAP 
#define TYActivatorModeAP ThingActivatorModeAP 
#endif 

#ifndef TYActivatorModeQRCode 
#define TYActivatorModeQRCode ThingActivatorModeQRCode 
#endif 

#ifndef TYActivatorModeWired 
#define TYActivatorModeWired ThingActivatorModeWired 
#endif 

#ifndef TYActivatorModeEZMulti 
#define TYActivatorModeEZMulti ThingActivatorModeEZMulti 
#endif 

#ifndef TYActivatorModeWiredGateway 
#define TYActivatorModeWiredGateway ThingActivatorModeWiredGateway 
#endif 

#ifndef TYActivatorModeELink 
#define TYActivatorModeELink ThingActivatorModeELink 
#endif 

#ifndef TYActivatorStepFound 
#define TYActivatorStepFound ThingActivatorStepFound 
#endif 

#ifndef TYActivatorStepRegisted 
#define TYActivatorStepRegisted ThingActivatorStepRegisted 
#endif 

#ifndef TYActivatorStepIntialized 
#define TYActivatorStepIntialized ThingActivatorStepIntialized 
#endif 

#ifndef TYActivatorStepTimeOut 
#define TYActivatorStepTimeOut ThingActivatorStepTimeOut 
#endif 

#ifndef TYPairingProtocol 
#define TYPairingProtocol ThingPairingProtocol 
#endif 

#ifndef TuyaSmartPairSuccessDevice 
#define TuyaSmartPairSuccessDevice ThingSmartPairSuccessDevice 
#endif 

#ifndef TuyaSmartPairErrorDevice 
#define TuyaSmartPairErrorDevice ThingSmartPairErrorDevice 
#endif 



#endif
