//
// TuyaSmartTimerKit.h
// TuyaSmartTimerKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartTimerKit.

#ifndef TuyaSmartTimerKit_h
#define TuyaSmartTimerKit_h

#import "TuyaSmartTimerKitMacro.h"

#import "TuyaSmartTimer.h"
#import "TuyaSmartTimer+TYDeprecatedApi.h"

#endif /* TuyaSmartTimerKit_h */
