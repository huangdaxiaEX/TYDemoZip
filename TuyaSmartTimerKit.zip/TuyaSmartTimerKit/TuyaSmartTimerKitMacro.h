#ifndef TuyaSmartTimerKitMacro_h
#define TuyaSmartTimerKitMacro_h

#ifndef TuyaSmartTimer_TYDeprecatedApi 
#define TuyaSmartTimer_TYDeprecatedApi TuyaSmartTimer_ThingDeprecatedApi 
#endif 

#ifndef TuyaSmartTimer 
#define TuyaSmartTimer ThingSmartTimer 
#endif 

#ifndef TYDeprecatedApi 
#define TYDeprecatedApi ThingDeprecatedApi 
#endif 

#ifndef TYSuccessHandler 
#define TYSuccessHandler ThingSuccessHandler 
#endif 

#ifndef TYFailureError 
#define TYFailureError ThingFailureError 
#endif 

#ifndef TuyaSmartTimerKit 
#define TuyaSmartTimerKit ThingSmartTimerKit 
#endif 

#ifndef TuyaSmartTimerKitVersionNumber 
#define TuyaSmartTimerKitVersionNumber ThingSmartTimerKitVersionNumber 
#endif 

#ifndef TuyaSmart_TuyaSmartTimer 
#define TuyaSmart_TuyaSmartTimer ThingSmart_ThingSmartTimer 
#endif 

#ifndef TYTimerModel 
#define TYTimerModel ThingTimerModel 
#endif 

#ifndef TYTimerTaskModel 
#define TYTimerTaskModel ThingTimerTaskModel 
#endif 

#ifndef TYCategoryTimersModel 
#define TYCategoryTimersModel ThingCategoryTimersModel 
#endif 

#ifndef TYSuccessDict 
#define TYSuccessDict ThingSuccessDict 
#endif 

#ifndef TYSuccessID 
#define TYSuccessID ThingSuccessID 
#endif 



#endif
