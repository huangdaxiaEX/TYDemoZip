//
// TuyaSmartTimerKit-iOS-umbrella.h
// TuyaSmartTimerKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartTimerKit-iOS-umbrella.

#import "TuyaSmartTimerKitMacro.h"
#import <ThingSmartTimerKit/ThingSmartTimerKit-iOS-umbrella.h>#import <UIKit/UIKit.h>
