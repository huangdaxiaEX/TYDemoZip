#ifndef TuyaAvLoggerSDKMacro_h
#define TuyaAvLoggerSDKMacro_h

#ifndef TuyaAvLoggerDelegate 
#define TuyaAvLoggerDelegate ThingAvLoggerDelegate 
#endif 

#ifndef TuyaAvLogger 
#define TuyaAvLogger ThingAvLogger 
#endif 



#endif
