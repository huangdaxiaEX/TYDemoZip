//
// TuyaSmartSceneActionModel.h
// TuyaSmartSceneKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartSceneActionModel.

#import "TuyaSmartSceneKitMacro.h"
#import <ThingSmartSceneKit/ThingSmartSceneActionModel.h>
#import <TuyaSmartSceneCoreKit/TuyaSmartSceneActionModel.h>
