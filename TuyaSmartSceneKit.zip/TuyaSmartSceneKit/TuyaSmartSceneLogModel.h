//
// TuyaSmartSceneLogModel.h
// TuyaSmartSceneKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartSceneLogModel.

#import "TuyaSmartSceneKitMacro.h"
#import <ThingSmartSceneKit/ThingSmartSceneLogModel.h>
#import <TuyaSmartSceneCoreKit/TuyaSmartSceneLogModel.h>
