//
// TuyaSmartSceneActionFactory.h
// TuyaSmartSceneKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartSceneActionFactory.

#import "TuyaSmartSceneKitMacro.h"
#import <ThingSmartSceneKit/ThingSmartSceneActionFactory.h>
#import <TuyaSmartSceneCoreKit/TuyaSmartSceneActionFactory.h>
