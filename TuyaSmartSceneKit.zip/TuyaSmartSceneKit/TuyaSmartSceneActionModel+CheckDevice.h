//
// TuyaSmartSceneActionModel+CheckDevice.h
// TuyaSmartSceneKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartSceneActionModel+CheckDevice.

#import "TuyaSmartSceneKitMacro.h"
#import <ThingSmartSceneKit/ThingSmartSceneActionModel+CheckDevice.h>
#import <TuyaSmartSceneCoreKit/TuyaSmartSceneActionModel+CheckDevice.h>
