//
// TuyaSmartSceneDataFactory.h
// TuyaSmartSceneKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartSceneDataFactory.

#import "TuyaSmartSceneKitMacro.h"
#import <ThingSmartSceneKit/ThingSmartSceneDataFactory.h>
#import <TuyaSmartSceneCoreKit/TuyaSmartSceneDataFactory.h>
