//
// TuyaSmartSceneManager+Home.h
// TuyaSmartSceneKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartSceneManager+Home.

#import "TuyaSmartSceneKitMacro.h"
#import <ThingSmartSceneKit/ThingSmartSceneManager+Home.h>
#import <TuyaSmartSceneCoreKit/TuyaSmartSceneCoreKit.h>
#import <TuyaSmartDeviceKit/TuyaSmartDeviceKit.h>
