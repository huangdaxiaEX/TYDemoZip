#ifndef TuyaSmartSceneKitMacro_h
#define TuyaSmartSceneKitMacro_h

#ifndef TuyaSmartSceneKit 
#define TuyaSmartSceneKit ThingSmartSceneKit 
#endif 

#ifndef TuyaSmartSceneManager 
#define TuyaSmartSceneManager ThingSmartSceneManager 
#endif 

#ifndef TuyaSmartSceneKitVersionNumber 
#define TuyaSmartSceneKitVersionNumber ThingSmartSceneKitVersionNumber 
#endif 



#endif
