#ifndef TuyaSmartP2pChannelKitMacro_h
#define TuyaSmartP2pChannelKitMacro_h

#ifndef TuyaSmartP2pConnectMode 
#define TuyaSmartP2pConnectMode ThingSmartP2pConnectMode 
#endif 

#ifndef TuyaSmartP2pConnectModeInternet 
#define TuyaSmartP2pConnectModeInternet ThingSmartP2pConnectModeInternet 
#endif 

#ifndef TuyaSmartP2pConnectModeLAN 
#define TuyaSmartP2pConnectModeLAN ThingSmartP2pConnectModeLAN 
#endif 

#ifndef TuyaSmartDeviceModel 
#define TuyaSmartDeviceModel ThingSmartDeviceModel 
#endif 

#ifndef TuyaSmartP2pChannel 
#define TuyaSmartP2pChannel ThingSmartP2pChannel 
#endif 

#ifndef TuyaSmartMQTTMessageModel 
#define TuyaSmartMQTTMessageModel ThingSmartMQTTMessageModel 
#endif 

#ifndef TYMQTTMessageCallback 
#define TYMQTTMessageCallback ThingMQTTMessageCallback 
#endif 

#ifndef TYCameraP2pCommandProxy 
#define TYCameraP2pCommandProxy ThingCameraP2pCommandProxy 
#endif 

#ifndef TuyaSmartP2pChannelKit 
#define TuyaSmartP2pChannelKit ThingSmartP2pChannelKit 
#endif 



#endif
