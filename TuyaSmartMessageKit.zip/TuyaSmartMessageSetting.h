//
// TuyaSmartMessageSetting.h
// TuyaSmartMessageKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartMessageSetting.

#import "TuyaSmartMessageKitMacro.h"
#import <ThingSmartMessageKit/ThingSmartMessageSetting.h>
#import <Foundation/Foundation.h>
#import <TuyaSmartBaseKit/TuyaSmartBaseKit.h>
