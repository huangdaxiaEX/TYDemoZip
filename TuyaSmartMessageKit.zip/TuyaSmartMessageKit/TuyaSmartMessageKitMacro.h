#ifndef TuyaSmartMessageKitMacro_h
#define TuyaSmartMessageKitMacro_h

#ifndef TuyaSmartMessage 
#define TuyaSmartMessage ThingSmartMessage 
#endif 

#ifndef TYDeprecatedApi 
#define TYDeprecatedApi ThingDeprecatedApi 
#endif 

#ifndef TYMessageType 
#define TYMessageType ThingMessageType 
#endif 

#ifndef TYFailureError 
#define TYFailureError ThingFailureError 
#endif 

#ifndef TYSuccessHandler 
#define TYSuccessHandler ThingSuccessHandler 
#endif 

#ifndef TYSuccessInt 
#define TYSuccessInt ThingSuccessInt 
#endif 

#ifndef TuyaSmartMessageListRequestModel 
#define TuyaSmartMessageListRequestModel ThingSmartMessageListRequestModel 
#endif 

#ifndef TuyaSmartMessageDetailListRequestModel 
#define TuyaSmartMessageDetailListRequestModel ThingSmartMessageDetailListRequestModel 
#endif 

#ifndef TuyaSmartMessageListDeleteRequestModel 
#define TuyaSmartMessageListDeleteRequestModel ThingSmartMessageListDeleteRequestModel 
#endif 

#ifndef TuyaSmartMessageListReadRequestModel 
#define TuyaSmartMessageListReadRequestModel ThingSmartMessageListReadRequestModel 
#endif 

#ifndef TuyaSmartMessageSettingDNDRequestModel 
#define TuyaSmartMessageSettingDNDRequestModel ThingSmartMessageSettingDNDRequestModel 
#endif 

#ifndef TuyaSmartMessageAuthorizationRequestModel 
#define TuyaSmartMessageAuthorizationRequestModel ThingSmartMessageAuthorizationRequestModel 
#endif 

#ifndef TuyaSmartMessageAttachModel 
#define TuyaSmartMessageAttachModel ThingSmartMessageAttachModel 
#endif 

#ifndef TuyaSmartMessageListModel 
#define TuyaSmartMessageListModel ThingSmartMessageListModel 
#endif 

#ifndef TuyaSmartMessageAuthorizationModel 
#define TuyaSmartMessageAuthorizationModel ThingSmartMessageAuthorizationModel 
#endif 

#ifndef TuyaSmartMessageSetting 
#define TuyaSmartMessageSetting ThingSmartMessageSetting 
#endif 

#ifndef TYSuccessBOOL 
#define TYSuccessBOOL ThingSuccessBOOL 
#endif 

#ifndef TYSuccessList 
#define TYSuccessList ThingSuccessList 
#endif 

#ifndef TYSuccessID 
#define TYSuccessID ThingSuccessID 
#endif 

#ifndef TYSuccessDict 
#define TYSuccessDict ThingSuccessDict 
#endif 

#ifndef TuyaSmartMessageUtils 
#define TuyaSmartMessageUtils ThingSmartMessageUtils 
#endif 

#ifndef TYMessageTypeAlarm 
#define TYMessageTypeAlarm ThingMessageTypeAlarm 
#endif 

#ifndef TYMessageTypeFamily 
#define TYMessageTypeFamily ThingMessageTypeFamily 
#endif 

#ifndef TYMessageTypeNotice 
#define TYMessageTypeNotice ThingMessageTypeNotice 
#endif 

#ifndef TuyaSmartMessageKit 
#define TuyaSmartMessageKit ThingSmartMessageKit 
#endif 

#ifndef TuyaSmartMessageKitVersionNumber 
#define TuyaSmartMessageKitVersionNumber ThingSmartMessageKitVersionNumber 
#endif 



#endif
