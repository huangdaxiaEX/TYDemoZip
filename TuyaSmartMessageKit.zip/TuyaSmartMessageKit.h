//
// TuyaSmartMessageKit.h
// TuyaSmartMessageKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartMessageKit.

#ifndef TuyaSmartMessageKit_h
#define TuyaSmartMessageKit_h

#import "TuyaSmartMessageKitMacro.h"

#import "TuyaSmartMessage.h"
#import "TuyaSmartMessage+TYDeprecatedApi.h"
#import "TuyaSmartMessageSetting.h"

#endif /* TuyaSmartMessageKit_h */
