//
// TuyaSmartHTTPDNS.h
// TuyaSmartBaseKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartHTTPDNS.

#import "TuyaSmartBaseKitMacro.h"
#import <ThingSmartBaseKit/ThingSmartHTTPDNS.h>
#import <TuyaSmartNetworkKit/TuyaSmartHTTPDNS.h>
