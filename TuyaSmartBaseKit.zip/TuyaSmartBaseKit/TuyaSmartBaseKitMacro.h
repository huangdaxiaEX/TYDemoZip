#ifndef TuyaSmartBaseKitMacro_h
#define TuyaSmartBaseKitMacro_h

#ifndef TuyaSmartSpeechService 
#define TuyaSmartSpeechService ThingSmartSpeechService 
#endif 

#ifndef TYSuccessString 
#define TYSuccessString ThingSuccessString 
#endif 

#ifndef TYFailureError 
#define TYFailureError ThingFailureError 
#endif 

#ifndef TYSuccessDict 
#define TYSuccessDict ThingSuccessDict 
#endif 

#ifndef TuyaSmartUser_LoginByQRCode 
#define TuyaSmartUser_LoginByQRCode ThingSmartUser_LoginByQRCode 
#endif 

#ifndef TuyaSmartUser 
#define TuyaSmartUser ThingSmartUser 
#endif 

#ifndef TYSuccessID 
#define TYSuccessID ThingSuccessID 
#endif 

#ifndef TuyaSmartUser_DeprecatedApi 
#define TuyaSmartUser_DeprecatedApi ThingSmartUser_DeprecatedApi 
#endif 

#ifndef TYSuccessHandler 
#define TYSuccessHandler ThingSuccessHandler 
#endif 

#ifndef TYRegionModel 
#define TYRegionModel ThingRegionModel 
#endif 

#ifndef TuyaSmartSDK 
#define TuyaSmartSDK ThingSmartSDK 
#endif 

#ifndef TYSuccessBOOL 
#define TYSuccessBOOL ThingSuccessBOOL 
#endif 

#ifndef TuyaSmartUser_Region 
#define TuyaSmartUser_Region ThingSmartUser_Region 
#endif 

#ifndef TuyaSmartUserNotificationUserSessionInvalid 
#define TuyaSmartUserNotificationUserSessionInvalid ThingSmartUserNotificationUserSessionInvalid 
#endif 

#ifndef TYRegType 
#define TYRegType ThingRegType 
#endif 

#ifndef TYRegEmailType 
#define TYRegEmailType ThingRegEmailType 
#endif 

#ifndef TYRegPhoneType 
#define TYRegPhoneType ThingRegPhoneType 
#endif 

#ifndef TYRegOtherType 
#define TYRegOtherType ThingRegOtherType 
#endif 

#ifndef TYRegQQType 
#define TYRegQQType ThingRegQQType 
#endif 

#ifndef TYRegWeiboType 
#define TYRegWeiboType ThingRegWeiboType 
#endif 

#ifndef TYRegFacebookType 
#define TYRegFacebookType ThingRegFacebookType 
#endif 

#ifndef TYRegTwitterType 
#define TYRegTwitterType ThingRegTwitterType 
#endif 

#ifndef TYRegWechatType 
#define TYRegWechatType ThingRegWechatType 
#endif 

#ifndef TYRegAppleIdType 
#define TYRegAppleIdType ThingRegAppleIdType 
#endif 

#ifndef TYRegGoogleType 
#define TYRegGoogleType ThingRegGoogleType 
#endif 

#ifndef TYRegLineType 
#define TYRegLineType ThingRegLineType 
#endif 

#ifndef TYPasswordRegularType 
#define TYPasswordRegularType ThingPasswordRegularType 
#endif 

#ifndef TYPasswordRegularLow 
#define TYPasswordRegularLow ThingPasswordRegularLow 
#endif 

#ifndef TYPasswordRegularMiddle 
#define TYPasswordRegularMiddle ThingPasswordRegularMiddle 
#endif 

#ifndef TYPasswordRegularHigh 
#define TYPasswordRegularHigh ThingPasswordRegularHigh 
#endif 

#ifndef TuyaSmartBaseKit 
#define TuyaSmartBaseKit ThingSmartBaseKit 
#endif 

#ifndef TUYA_HOMEKIT_SDK 
#define TUYA_HOMEKIT_SDK THING_HOMEKIT_SDK 
#endif 

#ifndef TuyaSmartUser_Anonymous 
#define TuyaSmartUser_Anonymous ThingSmartUser_Anonymous 
#endif 

#ifndef TuyaSmartUser_WCSession 
#define TuyaSmartUser_WCSession ThingSmartUser_WCSession 
#endif 

#ifndef TuyaSmartUserWCSessionKey 
#define TuyaSmartUserWCSessionKey ThingSmartUserWCSessionKey 
#endif 

#ifndef TuyaSmartBaseKitErrors 
#define TuyaSmartBaseKitErrors ThingSmartBaseKitErrors 
#endif 

#ifndef kTYBaseKitErrorDomain 
#define kTYBaseKitErrorDomain kThingBaseKitErrorDomain 
#endif 

#ifndef TYBaseKitError 
#define TYBaseKitError ThingBaseKitError 
#endif 

#ifndef kTYBaseKitErrorAPIRequestError 
#define kTYBaseKitErrorAPIRequestError kThingBaseKitErrorAPIRequestError 
#endif 

#ifndef kTYBaseKitErrorAPIResponseDataTypeIllegal 
#define kTYBaseKitErrorAPIResponseDataTypeIllegal kThingBaseKitErrorAPIResponseDataTypeIllegal 
#endif 

#ifndef kTYBaseKitErrorAPIResponseDataSignInconsistent 
#define kTYBaseKitErrorAPIResponseDataSignInconsistent kThingBaseKitErrorAPIResponseDataSignInconsistent 
#endif 

#ifndef kTYBaseKitErrorAPIResponseDataDecodeError 
#define kTYBaseKitErrorAPIResponseDataDecodeError kThingBaseKitErrorAPIResponseDataDecodeError 
#endif 

#ifndef kTYBaseKitErrorNetworkError 
#define kTYBaseKitErrorNetworkError kThingBaseKitErrorNetworkError 
#endif 



#endif
