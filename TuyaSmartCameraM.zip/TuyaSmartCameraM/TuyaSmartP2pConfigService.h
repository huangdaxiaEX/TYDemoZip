//
// TuyaSmartP2pConfigService.h
// TuyaSmartCameraM
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartP2pConfigService.

#import "TuyaSmartCameraMMacro.h"
#import <ThingSmartCameraM/ThingSmartP2pConfigService.h>
#import <Foundation/Foundation.h>
#import <TuyaSmartCameraBase/TuyaSmartCameraType.h>
