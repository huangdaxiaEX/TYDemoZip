#ifndef TuyaSmartCameraMMacro_h
#define TuyaSmartCameraMMacro_h

#ifndef TuyaNVRConnectState 
#define TuyaNVRConnectState ThingNVRConnectState 
#endif 

#ifndef TuyaNVRNotSupport 
#define TuyaNVRNotSupport ThingNVRNotSupport 
#endif 

#ifndef TuyaNVRDisconnected 
#define TuyaNVRDisconnected ThingNVRDisconnected 
#endif 

#ifndef TuyaNVRConnecting 
#define TuyaNVRConnecting ThingNVRConnecting 
#endif 

#ifndef TuyaNVRConnected 
#define TuyaNVRConnected ThingNVRConnected 
#endif 

#ifndef TuyaSmartNVR 
#define TuyaSmartNVR ThingSmartNVR 
#endif 

#ifndef TuyaSmartNVRDelegate 
#define TuyaSmartNVRDelegate ThingSmartNVRDelegate 
#endif 

#ifndef TuyaSmartP2pConnectMode 
#define TuyaSmartP2pConnectMode ThingSmartP2pConnectMode 
#endif 

#ifndef TuyaSmartCloudVideoPlayer 
#define TuyaSmartCloudVideoPlayer ThingSmartCloudVideoPlayer 
#endif 

#ifndef TuyaSmartCloudVideoPlayerDelegate 
#define TuyaSmartCloudVideoPlayerDelegate ThingSmartCloudVideoPlayerDelegate 
#endif 

#ifndef TuyaSmartVideoFrameInfo 
#define TuyaSmartVideoFrameInfo ThingSmartVideoFrameInfo 
#endif 

#ifndef TuyaSmartAudioFrameInfo 
#define TuyaSmartAudioFrameInfo ThingSmartAudioFrameInfo 
#endif 

#ifndef TuyaSmartCameraPlayBackSpeed 
#define TuyaSmartCameraPlayBackSpeed ThingSmartCameraPlayBackSpeed 
#endif 

#ifndef TuyaSmartVideoRotateDirection 
#define TuyaSmartVideoRotateDirection ThingSmartVideoRotateDirection 
#endif 

#ifndef TuyaSmartDeviceModel 
#define TuyaSmartDeviceModel ThingSmartDeviceModel 
#endif 

#ifndef TuyaSmartP2pConfigService 
#define TuyaSmartP2pConfigService ThingSmartP2pConfigService 
#endif 

#ifndef TuyaSmartCameraM 
#define TuyaSmartCameraM ThingSmartCameraM 
#endif 

#ifndef TuyaSmartCameraM_version 
#define TuyaSmartCameraM_version ThingSmartCameraM_version 
#endif 



#endif
