//
// TuyaSmartCameraM.h
// TuyaSmartCameraM
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartCameraM.

#ifndef TuyaSmartCameraM_h
#define TuyaSmartCameraM_h

#import "TuyaSmartCameraMMacro.h"

#import <Foundation/Foundation.h>

#import "TuyaSmartCloudVideoPlayer.h"
#import "TuyaSmartP2pConfigService.h"
#import "TuyaSmartNVR.h"

#endif /* TuyaSmartCameraM_h */
