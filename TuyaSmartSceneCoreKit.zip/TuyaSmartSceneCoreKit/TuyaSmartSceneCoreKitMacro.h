#ifndef TuyaSmartSceneCoreKitMacro_h
#define TuyaSmartSceneCoreKitMacro_h

#ifndef TuyaSmartSceneConditionFactory 
#define TuyaSmartSceneConditionFactory ThingSmartSceneConditionFactory 
#endif 

#ifndef TuyaSmartSceneLogData 
#define TuyaSmartSceneLogData ThingSmartSceneLogData 
#endif 

#ifndef TuyaSmartSceneLogModel 
#define TuyaSmartSceneLogModel ThingSmartSceneLogModel 
#endif 

#ifndef TuyaSmartCityModel 
#define TuyaSmartCityModel ThingSmartCityModel 
#endif 

#ifndef TuyaSmartSceneLogDetailData 
#define TuyaSmartSceneLogDetailData ThingSmartSceneLogDetailData 
#endif 

#ifndef TuyaSmartSceneLogDetailModel 
#define TuyaSmartSceneLogDetailModel ThingSmartSceneLogDetailModel 
#endif 

#ifndef TuyaSmartSceneColorHelper 
#define TuyaSmartSceneColorHelper ThingSmartSceneColorHelper 
#endif 

#ifndef TYSConditionExpressionType 
#define TYSConditionExpressionType ThingSConditionExpressionType 
#endif 

#ifndef TYSConditionExpressionTypePrecise 
#define TYSConditionExpressionTypePrecise ThingSConditionExpressionTypePrecise 
#endif 

#ifndef TYSConditionExpressionTypeSimple 
#define TYSConditionExpressionTypeSimple ThingSConditionExpressionTypeSimple 
#endif 

#ifndef TYSceneConditionStatus 
#define TYSceneConditionStatus ThingSceneConditionStatus 
#endif 

#ifndef TYSceneConditionStatusLoading 
#define TYSceneConditionStatusLoading ThingSceneConditionStatusLoading 
#endif 

#ifndef TYSceneConditionStatusSuccess 
#define TYSceneConditionStatusSuccess ThingSceneConditionStatusSuccess 
#endif 

#ifndef TYSceneConditionStatusOffline 
#define TYSceneConditionStatusOffline ThingSceneConditionStatusOffline 
#endif 

#ifndef TYSceneConditionStatusTimeout 
#define TYSceneConditionStatusTimeout ThingSceneConditionStatusTimeout 
#endif 

#ifndef TYConditionAutoType 
#define TYConditionAutoType ThingConditionAutoType 
#endif 

#ifndef TuyaSmartSceneConditionModel 
#define TuyaSmartSceneConditionModel ThingSmartSceneConditionModel 
#endif 

#ifndef TYSmartSceneDataFactory 
#define TYSmartSceneDataFactory ThingSmartSceneDataFactory 
#endif 

#ifndef TuyaSmartScenePreConditionFactory 
#define TuyaSmartScenePreConditionFactory ThingSmartScenePreConditionFactory 
#endif 

#ifndef TuyaSmartSceneManager 
#define TuyaSmartSceneManager ThingSmartSceneManager 
#endif 

#ifndef TuyaSmartSceneManagerDelegate 
#define TuyaSmartSceneManagerDelegate ThingSmartSceneManagerDelegate 
#endif 

#ifndef TYFailureError 
#define TYFailureError ThingFailureError 
#endif 

#ifndef TYSuccessHandler 
#define TYSuccessHandler ThingSuccessHandler 
#endif 

#ifndef TYSuccessID 
#define TYSuccessID ThingSuccessID 
#endif 

#ifndef TYSuccessList 
#define TYSuccessList ThingSuccessList 
#endif 

#ifndef TYSuccessDict 
#define TYSuccessDict ThingSuccessDict 
#endif 

#ifndef TuyaSmartSceneExprModel 
#define TuyaSmartSceneExprModel ThingSmartSceneExprModel 
#endif 

#ifndef TuyaSmartSceneBizEntryTypeNone 
#define TuyaSmartSceneBizEntryTypeNone ThingSmartSceneBizEntryTypeNone 
#endif 

#ifndef TuyaSmartSceneBizEntryTypeLight 
#define TuyaSmartSceneBizEntryTypeLight ThingSmartSceneBizEntryTypeLight 
#endif 

#ifndef TuyaSmartSceneBizEntryType 
#define TuyaSmartSceneBizEntryType ThingSmartSceneBizEntryType 
#endif 

#ifndef TuyaSmartSceneBizEntryModel 
#define TuyaSmartSceneBizEntryModel ThingSmartSceneBizEntryModel 
#endif 

#ifndef TuyaSmartScene 
#define TuyaSmartScene ThingSmartScene 
#endif 

#ifndef TuyaSmartConditionMatchType 
#define TuyaSmartConditionMatchType ThingSmartConditionMatchType 
#endif 

#ifndef TYSuccessBOOL 
#define TYSuccessBOOL ThingSuccessBOOL 
#endif 

#ifndef TuyaSmartSchemaModel 
#define TuyaSmartSchemaModel ThingSmartSchemaModel 
#endif 

#ifndef TuyaSmartSceneDPModel 
#define TuyaSmartSceneDPModel ThingSmartSceneDPModel 
#endif 

#ifndef TuyaSmartScenePreConditionModel 
#define TuyaSmartScenePreConditionModel ThingSmartScenePreConditionModel 
#endif 

#ifndef TuyaSmartSceneActionModel 
#define TuyaSmartSceneActionModel ThingSmartSceneActionModel 
#endif 

#ifndef TuyaSmartSceneCoreKit 
#define TuyaSmartSceneCoreKit ThingSmartSceneCoreKit 
#endif 

#ifndef TuyaSmartSceneCoreKitVersionNumber 
#define TuyaSmartSceneCoreKitVersionNumber ThingSmartSceneCoreKitVersionNumber 
#endif 

#ifndef TuyaSmartSceneCoreColorType 
#define TuyaSmartSceneCoreColorType ThingSmartSceneCoreColorType 
#endif 

#ifndef TuyaSmartSceneCoreColorBrightNess 
#define TuyaSmartSceneCoreColorBrightNess ThingSmartSceneCoreColorBrightNess 
#endif 

#ifndef TuyaSmartSceneCoreColorTempS 
#define TuyaSmartSceneCoreColorTempS ThingSmartSceneCoreColorTempS 
#endif 

#ifndef TuyaSmartSceneCoreActionDPStepType 
#define TuyaSmartSceneCoreActionDPStepType ThingSmartSceneCoreActionDPStepType 
#endif 

#ifndef TuyaSmartSceneCoreActionDPStepRegularType 
#define TuyaSmartSceneCoreActionDPStepRegularType ThingSmartSceneCoreActionDPStepRegularType 
#endif 

#ifndef TuyaSmartSceneCoreActionDPStepHighType 
#define TuyaSmartSceneCoreActionDPStepHighType ThingSmartSceneCoreActionDPStepHighType 
#endif 

#ifndef TuyaSmartSceneCoreActionDPStepLowType 
#define TuyaSmartSceneCoreActionDPStepLowType ThingSmartSceneCoreActionDPStepLowType 
#endif 

#ifndef TuyaSmartSceneCoreActionDpModel 
#define TuyaSmartSceneCoreActionDpModel ThingSmartSceneCoreActionDpModel 
#endif 

#ifndef TuyaSmartSceneCoreFunctionType 
#define TuyaSmartSceneCoreFunctionType ThingSmartSceneCoreFunctionType 
#endif 

#ifndef TuyaSmartSceneCoreFunctionSingleType 
#define TuyaSmartSceneCoreFunctionSingleType ThingSmartSceneCoreFunctionSingleType 
#endif 

#ifndef TuyaSmartSceneCoreFunctionGroupType 
#define TuyaSmartSceneCoreFunctionGroupType ThingSmartSceneCoreFunctionGroupType 
#endif 

#ifndef TuyaSmartSceneCoreFunctionCodeWhite 
#define TuyaSmartSceneCoreFunctionCodeWhite ThingSmartSceneCoreFunctionCodeWhite 
#endif 

#ifndef TuyaSmartSceneCoreFunctionCodeColor 
#define TuyaSmartSceneCoreFunctionCodeColor ThingSmartSceneCoreFunctionCodeColor 
#endif 

#ifndef TuyaSmartSceneCoreFeatureModel 
#define TuyaSmartSceneCoreFeatureModel ThingSmartSceneCoreFeatureModel 
#endif 

#ifndef TuyaSmartSceneConditionExprBuilder 
#define TuyaSmartSceneConditionExprBuilder ThingSmartSceneConditionExprBuilder 
#endif 

#ifndef TYSceneActionStatus 
#define TYSceneActionStatus ThingSceneActionStatus 
#endif 

#ifndef TYSceneActionStatusLoading 
#define TYSceneActionStatusLoading ThingSceneActionStatusLoading 
#endif 

#ifndef TYSceneActionStatusSuccess 
#define TYSceneActionStatusSuccess ThingSceneActionStatusSuccess 
#endif 

#ifndef TYSceneActionStatusOffline 
#define TYSceneActionStatusOffline ThingSceneActionStatusOffline 
#endif 

#ifndef TYSceneActionStatusTimeout 
#define TYSceneActionStatusTimeout ThingSceneActionStatusTimeout 
#endif 

#ifndef TYSceneActionStatusDelay 
#define TYSceneActionStatusDelay ThingSceneActionStatusDelay 
#endif 

#ifndef TuyaSmartConditionMatchAny 
#define TuyaSmartConditionMatchAny ThingSmartConditionMatchAny 
#endif 

#ifndef TuyaSmartConditionMatchAll 
#define TuyaSmartConditionMatchAll ThingSmartConditionMatchAll 
#endif 

#ifndef TuyaSmartSceneRecommendType 
#define TuyaSmartSceneRecommendType ThingSmartSceneRecommendType 
#endif 

#ifndef TuyaSmartSceneRecommendTypeNone 
#define TuyaSmartSceneRecommendTypeNone ThingSmartSceneRecommendTypeNone 
#endif 

#ifndef TuyaSmartSceneRecommendTypeScene 
#define TuyaSmartSceneRecommendTypeScene ThingSmartSceneRecommendTypeScene 
#endif 

#ifndef TuyaSmartSceneRecommendTypeAutomation 
#define TuyaSmartSceneRecommendTypeAutomation ThingSmartSceneRecommendTypeAutomation 
#endif 

#ifndef TuyaSmartSceneCollectionType 
#define TuyaSmartSceneCollectionType ThingSmartSceneCollectionType 
#endif 

#ifndef TuyaSmartSceneCollectionTypeNone 
#define TuyaSmartSceneCollectionTypeNone ThingSmartSceneCollectionTypeNone 
#endif 

#ifndef TuyaSmartSceneCollectionTypeScene 
#define TuyaSmartSceneCollectionTypeScene ThingSmartSceneCollectionTypeScene 
#endif 

#ifndef TuyaSmartSceneCollectionTypeAutomation 
#define TuyaSmartSceneCollectionTypeAutomation ThingSmartSceneCollectionTypeAutomation 
#endif 

#ifndef TuyaSmartScenePanelType 
#define TuyaSmartScenePanelType ThingSmartScenePanelType 
#endif 

#ifndef TuyaSmartScenePanelTypeNonAllDevevice 
#define TuyaSmartScenePanelTypeNonAllDevevice ThingSmartScenePanelTypeNonAllDevevice 
#endif 

#ifndef TuyaSmartScenePanelTypeAllDevices 
#define TuyaSmartScenePanelTypeAllDevices ThingSmartScenePanelTypeAllDevices 
#endif 

#ifndef TuyaSmartSceneWorkingStatus 
#define TuyaSmartSceneWorkingStatus ThingSmartSceneWorkingStatus 
#endif 

#ifndef TuyaSmartSceneWorkingStatusFine 
#define TuyaSmartSceneWorkingStatusFine ThingSmartSceneWorkingStatusFine 
#endif 

#ifndef TuyaSmartSceneWorkingStatusInvalid 
#define TuyaSmartSceneWorkingStatusInvalid ThingSmartSceneWorkingStatusInvalid 
#endif 

#ifndef TuyaSmartSceneWorkingStatusException 
#define TuyaSmartSceneWorkingStatusException ThingSmartSceneWorkingStatusException 
#endif 

#ifndef TuyaSmartSceneRuleGenre 
#define TuyaSmartSceneRuleGenre ThingSmartSceneRuleGenre 
#endif 

#ifndef TuyaSmartSceneRuleGenreNone 
#define TuyaSmartSceneRuleGenreNone ThingSmartSceneRuleGenreNone 
#endif 

#ifndef TuyaSmartSceneRuleGenreManual 
#define TuyaSmartSceneRuleGenreManual ThingSmartSceneRuleGenreManual 
#endif 

#ifndef TuyaSmartSceneRuleGenreAuto 
#define TuyaSmartSceneRuleGenreAuto ThingSmartSceneRuleGenreAuto 
#endif 

#ifndef TuyaSmartSceneModel 
#define TuyaSmartSceneModel ThingSmartSceneModel 
#endif 

#ifndef TuyaSmartSceneActionFactory 
#define TuyaSmartSceneActionFactory ThingSmartSceneActionFactory 
#endif 



#endif
