//
// TuyaSmartSchemaPropertyModel.h
// TuyaSmartDeviceCoreKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartSchemaPropertyModel.

#import "TuyaSmartDeviceCoreKitMacro.h"
#import <ThingSmartDeviceCoreKit/ThingSmartSchemaPropertyModel.h>
#import <Foundation/Foundation.h>
