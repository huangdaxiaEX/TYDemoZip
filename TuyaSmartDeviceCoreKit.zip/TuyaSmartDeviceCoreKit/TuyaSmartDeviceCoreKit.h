//
// TuyaSmartDeviceCoreKit.h
// TuyaSmartDeviceCoreKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartDeviceCoreKit.

#ifndef TuyaSmartDeviceCoreKit_h
#define TuyaSmartDeviceCoreKit_h

#import "TuyaSmartDeviceCoreKitMacro.h"

#import <TuyaSmartBaseKit/TuyaSmartBaseKit.h>

#if TARGET_OS_IOS
    #import <TuyaSmartMQTTChannelKit/TuyaSmartMQTTChannelKit.h>
    #import <TuyaSmartSocketChannelKit/TuyaSmartSocketChannelKit.h>

    #import "TuyaSmartDevice+WiFiBackup.h"

#elif TARGET_OS_WATCH
#endif

#import "TuyaSmartDevice.h"
#import "TuyaSmartGroup.h"
#import "TuyaSmartBleMeshModel.h"
#import "TuyaSmartSingleTransfer.h"
#import "TYCoreCacheService.h"

#import "TuyaSmartDevice+OfflineReminder.h"
#import "TuyaSmartDeviceCoreKitErrors.h"
#import "TuyaSmartDevice+OfflineReminder.h"
#import "TuyaSmartCommunication.h"
#import "TuyaSmartDeviceEventUtil.h"

#import "TuyaSmartCommunication.h"
#import "TuyaSmartDevice+LocalKey.h"

#import "TuyaSmartDevice+OTA.h"
#import "TuyaSmartDeviceModelUtils.h"

#import "TuyaSmartMQTTConfig.h"
#import "TuyaSmartSocketConfig.h"

#import "TuyaSmartLANAndMQTTVersionSupport.h"

#endif /* TuyaSmartDeviceCoreKit_h */
