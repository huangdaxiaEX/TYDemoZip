//
// TuyaSmartMQTTConfig.h
// TuyaSmartDeviceCoreKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartMQTTConfig.

#import "TuyaSmartDeviceCoreKitMacro.h"
#import <ThingSmartDeviceCoreKit/ThingSmartMQTTConfig.h>

#import <Foundation/Foundation.h>
