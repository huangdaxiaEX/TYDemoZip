#ifndef TuyaSmartDeviceCoreKitMacro_h
#define TuyaSmartDeviceCoreKitMacro_h

#ifndef TuyaSmartDevice 
#define TuyaSmartDevice ThingSmartDevice 
#endif 

#ifndef TYSuccessHandler 
#define TYSuccessHandler ThingSuccessHandler 
#endif 

#ifndef TYFailureError 
#define TYFailureError ThingFailureError 
#endif 

#ifndef TuyaSmartExtenModule 
#define TuyaSmartExtenModule ThingSmartExtenModule 
#endif 

#ifndef TuyaSmartExtenModuleModel 
#define TuyaSmartExtenModuleModel ThingSmartExtenModuleModel 
#endif 

#ifndef TuyaSmartExtenNBTLD 
#define TuyaSmartExtenNBTLD ThingSmartExtenNBTLD 
#endif 

#ifndef TuyaSmartExtenModuleReport 
#define TuyaSmartExtenModuleReport ThingSmartExtenModuleReport 
#endif 

#ifndef TuyaSmartBackupWifiModel 
#define TuyaSmartBackupWifiModel ThingSmartBackupWifiModel 
#endif 

#ifndef TuyaSmartUIComponent 
#define TuyaSmartUIComponent ThingSmartUIComponent 
#endif 

#ifndef TuyaSmart_TuyaSmartGroupModel 
#define TuyaSmart_TuyaSmartGroupModel ThingSmart_ThingSmartGroupModel 
#endif 

#ifndef TuyaSmartGroupTypeWifi 
#define TuyaSmartGroupTypeWifi ThingSmartGroupTypeWifi 
#endif 

#ifndef TuyaSmartGroupTypeMesh 
#define TuyaSmartGroupTypeMesh ThingSmartGroupTypeMesh 
#endif 

#ifndef TuyaSmartGroupTypeZigbee 
#define TuyaSmartGroupTypeZigbee ThingSmartGroupTypeZigbee 
#endif 

#ifndef TuyaSmartGroupTypeSIGMesh 
#define TuyaSmartGroupTypeSIGMesh ThingSmartGroupTypeSIGMesh 
#endif 

#ifndef TuyaSmartGroupTypeBeacon 
#define TuyaSmartGroupTypeBeacon ThingSmartGroupTypeBeacon 
#endif 

#ifndef TuyaSmartGroupTypeMatter 
#define TuyaSmartGroupTypeMatter ThingSmartGroupTypeMatter 
#endif 

#ifndef TuyaSmartGroupTypeThread 
#define TuyaSmartGroupTypeThread ThingSmartGroupTypeThread 
#endif 

#ifndef TuyaSmartGroupType 
#define TuyaSmartGroupType ThingSmartGroupType 
#endif 

#ifndef TuyaSmartGroupModel 
#define TuyaSmartGroupModel ThingSmartGroupModel 
#endif 

#ifndef TuyaSmartTransferState 
#define TuyaSmartTransferState ThingSmartTransferState 
#endif 

#ifndef TuyaSmartTransferConnected 
#define TuyaSmartTransferConnected ThingSmartTransferConnected 
#endif 

#ifndef TuyaSmartTransferDisconnected 
#define TuyaSmartTransferDisconnected ThingSmartTransferDisconnected 
#endif 

#ifndef TuyaSmartSingleTransfer 
#define TuyaSmartSingleTransfer ThingSmartSingleTransfer 
#endif 

#ifndef TuyaSmartTransferDelegate 
#define TuyaSmartTransferDelegate ThingSmartTransferDelegate 
#endif 

#ifndef TuyaSmartDeviceCoreKitErrors 
#define TuyaSmartDeviceCoreKitErrors ThingSmartDeviceCoreKitErrors 
#endif 

#ifndef kTYDeviceCoreKitErrorDomain 
#define kTYDeviceCoreKitErrorDomain kThingDeviceCoreKitErrorDomain 
#endif 

#ifndef TYDeviceCoreKitError 
#define TYDeviceCoreKitError ThingDeviceCoreKitError 
#endif 

#ifndef kTYDeviceCoreKitErrorDeviceNotSupport 
#define kTYDeviceCoreKitErrorDeviceNotSupport kThingDeviceCoreKitErrorDeviceNotSupport 
#endif 

#ifndef kTYDeviceCoreKitErrorSocketSendDataFailed 
#define kTYDeviceCoreKitErrorSocketSendDataFailed kThingDeviceCoreKitErrorSocketSendDataFailed 
#endif 

#ifndef kTYDeviceCoreKitErrorEmptyDpsData 
#define kTYDeviceCoreKitErrorEmptyDpsData kThingDeviceCoreKitErrorEmptyDpsData 
#endif 

#ifndef kTYDeviceCoreKitErrorGroupDeviceListEmpty 
#define kTYDeviceCoreKitErrorGroupDeviceListEmpty kThingDeviceCoreKitErrorGroupDeviceListEmpty 
#endif 

#ifndef kTYDeviceCoreKitErrorGroupIdLengthError 
#define kTYDeviceCoreKitErrorGroupIdLengthError kThingDeviceCoreKitErrorGroupIdLengthError 
#endif 

#ifndef kTYDeviceCoreKitErrorIllegalDpData 
#define kTYDeviceCoreKitErrorIllegalDpData kThingDeviceCoreKitErrorIllegalDpData 
#endif 

#ifndef kTYDeviceCoreKitErrorDeviceIdLengthError 
#define kTYDeviceCoreKitErrorDeviceIdLengthError kThingDeviceCoreKitErrorDeviceIdLengthError 
#endif 

#ifndef kTYDeviceCoreKitErrorDeviceLocalKeyNotFound 
#define kTYDeviceCoreKitErrorDeviceLocalKeyNotFound kThingDeviceCoreKitErrorDeviceLocalKeyNotFound 
#endif 

#ifndef kTYDeviceCoreKitErrorDeviceProductIDLengthError 
#define kTYDeviceCoreKitErrorDeviceProductIDLengthError kThingDeviceCoreKitErrorDeviceProductIDLengthError 
#endif 

#ifndef kTYDeviceCoreKitErrorIllegalCommunicationType 
#define kTYDeviceCoreKitErrorIllegalCommunicationType kThingDeviceCoreKitErrorIllegalCommunicationType 
#endif 

#ifndef TuyaSmart_BleMeshSubDeviceModuleModel 
#define TuyaSmart_BleMeshSubDeviceModuleModel ThingSmart_BleMeshSubDeviceModuleModel 
#endif 

#ifndef TuyaSmartDeviceMcuModel 
#define TuyaSmartDeviceMcuModel ThingSmartDeviceMcuModel 
#endif 

#ifndef TuyaSmartDeviceZigbeeModel 
#define TuyaSmartDeviceZigbeeModel ThingSmartDeviceZigbeeModel 
#endif 

#ifndef TuyaSmartDeviceBluetoothModel 
#define TuyaSmartDeviceBluetoothModel ThingSmartDeviceBluetoothModel 
#endif 

#ifndef TuyaSmartDeviceWifiModel 
#define TuyaSmartDeviceWifiModel ThingSmartDeviceWifiModel 
#endif 

#ifndef TuyaSmartDeviceInfraredModel 
#define TuyaSmartDeviceInfraredModel ThingSmartDeviceInfraredModel 
#endif 

#ifndef TuyaSmartDeviceGprsModel 
#define TuyaSmartDeviceGprsModel ThingSmartDeviceGprsModel 
#endif 

#ifndef TuyaSmartDeviceSubpiecesModel 
#define TuyaSmartDeviceSubpiecesModel ThingSmartDeviceSubpiecesModel 
#endif 

#ifndef TuyaSmartDeviceSMeshModel 
#define TuyaSmartDeviceSMeshModel ThingSmartDeviceSMeshModel 
#endif 

#ifndef TuyaSmartDeviceNBIoTModel 
#define TuyaSmartDeviceNBIoTModel ThingSmartDeviceNBIoTModel 
#endif 

#ifndef TuyaSmartDeviceModuleModel 
#define TuyaSmartDeviceModuleModel ThingSmartDeviceModuleModel 
#endif 

#ifndef TuyaSmart_TuyaSmartDeviceModel 
#define TuyaSmart_TuyaSmartDeviceModel ThingSmart_ThingSmartDeviceModel 
#endif 

#ifndef TuyaSmartDeviceModelTypeWifiDev 
#define TuyaSmartDeviceModelTypeWifiDev ThingSmartDeviceModelTypeWifiDev 
#endif 

#ifndef TuyaSmartDeviceModelTypeBle 
#define TuyaSmartDeviceModelTypeBle ThingSmartDeviceModelTypeBle 
#endif 

#ifndef TuyaSmartDeviceModelTypeGprs 
#define TuyaSmartDeviceModelTypeGprs ThingSmartDeviceModelTypeGprs 
#endif 

#ifndef TuyaSmartDeviceModelTypeNBIoT 
#define TuyaSmartDeviceModelTypeNBIoT ThingSmartDeviceModelTypeNBIoT 
#endif 

#ifndef TuyaSmartDeviceModelTypeZigbeeGateway 
#define TuyaSmartDeviceModelTypeZigbeeGateway ThingSmartDeviceModelTypeZigbeeGateway 
#endif 

#ifndef TuyaSmartDeviceModelTypeZigbeeSubDev 
#define TuyaSmartDeviceModelTypeZigbeeSubDev ThingSmartDeviceModelTypeZigbeeSubDev 
#endif 

#ifndef TuyaSmartDeviceModelTypeMeshBleSubDev 
#define TuyaSmartDeviceModelTypeMeshBleSubDev ThingSmartDeviceModelTypeMeshBleSubDev 
#endif 

#ifndef TuyaSmartDeviceModelTypeInfraredGateway 
#define TuyaSmartDeviceModelTypeInfraredGateway ThingSmartDeviceModelTypeInfraredGateway 
#endif 

#ifndef TuyaSmartDeviceModelTypeInfraredSubDev 
#define TuyaSmartDeviceModelTypeInfraredSubDev ThingSmartDeviceModelTypeInfraredSubDev 
#endif 

#ifndef TuyaSmartDeviceModelTypeWifiGateway 
#define TuyaSmartDeviceModelTypeWifiGateway ThingSmartDeviceModelTypeWifiGateway 
#endif 

#ifndef TuyaSmartDeviceModelTypeWifiSubDev 
#define TuyaSmartDeviceModelTypeWifiSubDev ThingSmartDeviceModelTypeWifiSubDev 
#endif 

#ifndef TuyaSmartDeviceModelTypeSIGMeshGateway 
#define TuyaSmartDeviceModelTypeSIGMeshGateway ThingSmartDeviceModelTypeSIGMeshGateway 
#endif 

#ifndef TuyaSmartDeviceModelTypeSIGMeshSubDev 
#define TuyaSmartDeviceModelTypeSIGMeshSubDev ThingSmartDeviceModelTypeSIGMeshSubDev 
#endif 

#ifndef TuyaSmartDeviceModelTypeBeacon 
#define TuyaSmartDeviceModelTypeBeacon ThingSmartDeviceModelTypeBeacon 
#endif 

#ifndef TuyaSmartDeviceModelTypeCat1 
#define TuyaSmartDeviceModelTypeCat1 ThingSmartDeviceModelTypeCat1 
#endif 

#ifndef TuyaSmartDeviceModelTypeThreadGateway 
#define TuyaSmartDeviceModelTypeThreadGateway ThingSmartDeviceModelTypeThreadGateway 
#endif 

#ifndef TuyaSmartDeviceModelTypeThreadSubDev 
#define TuyaSmartDeviceModelTypeThreadSubDev ThingSmartDeviceModelTypeThreadSubDev 
#endif 

#ifndef TuyaSmartDeviceModelType 
#define TuyaSmartDeviceModelType ThingSmartDeviceModelType 
#endif 

#ifndef TuyaSmartDeviceOnlineType 
#define TuyaSmartDeviceOnlineType ThingSmartDeviceOnlineType 
#endif 

#ifndef TuyaSmartDeviceOnlineTypeOffline 
#define TuyaSmartDeviceOnlineTypeOffline ThingSmartDeviceOnlineTypeOffline 
#endif 

#ifndef TuyaSmartDeviceOnlineTypeWifi 
#define TuyaSmartDeviceOnlineTypeWifi ThingSmartDeviceOnlineTypeWifi 
#endif 

#ifndef TuyaSmartDeviceOnlineTypeLan 
#define TuyaSmartDeviceOnlineTypeLan ThingSmartDeviceOnlineTypeLan 
#endif 

#ifndef TuyaSmartDeviceOnlineTypeBLE 
#define TuyaSmartDeviceOnlineTypeBLE ThingSmartDeviceOnlineTypeBLE 
#endif 

#ifndef TuyaSmartDeviceOnlineTypeMeshBLE 
#define TuyaSmartDeviceOnlineTypeMeshBLE ThingSmartDeviceOnlineTypeMeshBLE 
#endif 

#ifndef TuyaSmartDeviceOnlineTypeBeacon 
#define TuyaSmartDeviceOnlineTypeBeacon ThingSmartDeviceOnlineTypeBeacon 
#endif 

#ifndef TuyaSmartDeviceModel 
#define TuyaSmartDeviceModel ThingSmartDeviceModel 
#endif 

#ifndef TuyaSmart_TuyaSmartGroupDevListModel 
#define TuyaSmart_TuyaSmartGroupDevListModel ThingSmart_ThingSmartGroupDevListModel 
#endif 

#ifndef TuyaSmartGroupDevListModel 
#define TuyaSmartGroupDevListModel ThingSmartGroupDevListModel 
#endif 

#ifndef TuyaSmartMQTTMessageModel 
#define TuyaSmartMQTTMessageModel ThingSmartMQTTMessageModel 
#endif 

#ifndef TuyaSmartFirmwareUpgradeStatusModel 
#define TuyaSmartFirmwareUpgradeStatusModel ThingSmartFirmwareUpgradeStatusModel 
#endif 

#ifndef TuyaSmart_TuyaSmartFirmwareUpgradeModel 
#define TuyaSmart_TuyaSmartFirmwareUpgradeModel ThingSmart_ThingSmartFirmwareUpgradeModel 
#endif 

#ifndef TuyaSmartFirmwareUpgradeModel 
#define TuyaSmartFirmwareUpgradeModel ThingSmartFirmwareUpgradeModel 
#endif 

#ifndef TYCommunicationType 
#define TYCommunicationType ThingCommunicationType 
#endif 

#ifndef TYCommunicationTypeLAN 
#define TYCommunicationTypeLAN ThingCommunicationTypeLAN 
#endif 

#ifndef TYCommunicationTypeMQTT 
#define TYCommunicationTypeMQTT ThingCommunicationTypeMQTT 
#endif 

#ifndef TYCommunicationTypeHTTP 
#define TYCommunicationTypeHTTP ThingCommunicationTypeHTTP 
#endif 

#ifndef TYCommunicationTypeBLE 
#define TYCommunicationTypeBLE ThingCommunicationTypeBLE 
#endif 

#ifndef TYCommunicationTypeSIGMesh 
#define TYCommunicationTypeSIGMesh ThingCommunicationTypeSIGMesh 
#endif 

#ifndef TYCommunicationTypeBLEMesh 
#define TYCommunicationTypeBLEMesh ThingCommunicationTypeBLEMesh 
#endif 

#ifndef TYCommunicationTypeBLEBeacon 
#define TYCommunicationTypeBLEBeacon ThingCommunicationTypeBLEBeacon 
#endif 

#ifndef TYCommunicationTypeCloudMode 
#define TYCommunicationTypeCloudMode ThingCommunicationTypeCloudMode 
#endif 

#ifndef TuyaSmartCommunicationMode 
#define TuyaSmartCommunicationMode ThingSmartCommunicationMode 
#endif 

#ifndef TuyaSmartCommunication 
#define TuyaSmartCommunication ThingSmartCommunication 
#endif 

#ifndef TYDeviceOSCategory 
#define TYDeviceOSCategory ThingDeviceOSCategory 
#endif 

#ifndef TYDeviceOSCategoryDefault 
#define TYDeviceOSCategoryDefault ThingDeviceOSCategoryDefault 
#endif 

#ifndef TYDeviceOSCategoryWifiPv2_0 
#define TYDeviceOSCategoryWifiPv2_0 ThingDeviceOSCategoryWifiPv2_0 
#endif 

#ifndef TYDeviceOSCategoryWifiPv2_1 
#define TYDeviceOSCategoryWifiPv2_1 ThingDeviceOSCategoryWifiPv2_1 
#endif 

#ifndef TYDeviceOSCategoryWifiPv2_2 
#define TYDeviceOSCategoryWifiPv2_2 ThingDeviceOSCategoryWifiPv2_2 
#endif 

#ifndef TYDeviceOSCategoryWifiPv2_3 
#define TYDeviceOSCategoryWifiPv2_3 ThingDeviceOSCategoryWifiPv2_3 
#endif 

#ifndef TYDeviceOSCategoryWifiPvUnknown 
#define TYDeviceOSCategoryWifiPvUnknown ThingDeviceOSCategoryWifiPvUnknown 
#endif 

#ifndef TYDeviceOSCategoryGPRS 
#define TYDeviceOSCategoryGPRS ThingDeviceOSCategoryGPRS 
#endif 

#ifndef TYDeviceOSCategoryNB 
#define TYDeviceOSCategoryNB ThingDeviceOSCategoryNB 
#endif 

#ifndef TYDeviceOSCategoryBle 
#define TYDeviceOSCategoryBle ThingDeviceOSCategoryBle 
#endif 

#ifndef TYDeviceOSCategoryBleSub 
#define TYDeviceOSCategoryBleSub ThingDeviceOSCategoryBleSub 
#endif 

#ifndef TYDeviceOSCategoryBleWifi 
#define TYDeviceOSCategoryBleWifi ThingDeviceOSCategoryBleWifi 
#endif 

#ifndef TYDeviceOSCategoryBleCat1 
#define TYDeviceOSCategoryBleCat1 ThingDeviceOSCategoryBleCat1 
#endif 

#ifndef TYDeviceOSCategoryBlePlugPlayFull 
#define TYDeviceOSCategoryBlePlugPlayFull ThingDeviceOSCategoryBlePlugPlayFull 
#endif 

#ifndef TYDeviceOSCategoryBlePlugPlayHalf 
#define TYDeviceOSCategoryBlePlugPlayHalf ThingDeviceOSCategoryBlePlugPlayHalf 
#endif 

#ifndef TYDeviceOSCategoryBleMultiuser 
#define TYDeviceOSCategoryBleMultiuser ThingDeviceOSCategoryBleMultiuser 
#endif 

#ifndef TYDeviceOSCategoryBleWifiMultiuser 
#define TYDeviceOSCategoryBleWifiMultiuser ThingDeviceOSCategoryBleWifiMultiuser 
#endif 

#ifndef TYDeviceOSCategoryBleMesh 
#define TYDeviceOSCategoryBleMesh ThingDeviceOSCategoryBleMesh 
#endif 

#ifndef TYDeviceOSCategoryBleMeshSub 
#define TYDeviceOSCategoryBleMeshSub ThingDeviceOSCategoryBleMeshSub 
#endif 

#ifndef TYDeviceOSCategoryZigBeeSub 
#define TYDeviceOSCategoryZigBeeSub ThingDeviceOSCategoryZigBeeSub 
#endif 

#ifndef TYDeviceOSCategoryInfraredWifi 
#define TYDeviceOSCategoryInfraredWifi ThingDeviceOSCategoryInfraredWifi 
#endif 

#ifndef TYDeviceOSCategoryInfraredZigBee 
#define TYDeviceOSCategoryInfraredZigBee ThingDeviceOSCategoryInfraredZigBee 
#endif 

#ifndef TYDeviceOSCategory433 
#define TYDeviceOSCategory433 ThingDeviceOSCategory433 
#endif 

#ifndef TYDeviceOSCategory433Gateway 
#define TYDeviceOSCategory433Gateway ThingDeviceOSCategory433Gateway 
#endif 

#ifndef TYDeviceOSCategorySigMesh 
#define TYDeviceOSCategorySigMesh ThingDeviceOSCategorySigMesh 
#endif 

#ifndef TYDeviceOSCategorySigMeshSub 
#define TYDeviceOSCategorySigMeshSub ThingDeviceOSCategorySigMeshSub 
#endif 

#ifndef TYDeviceOSCategorySigMeshSingleFire 
#define TYDeviceOSCategorySigMeshSingleFire ThingDeviceOSCategorySigMeshSingleFire 
#endif 

#ifndef TYDeviceOSCategoryCat1 
#define TYDeviceOSCategoryCat1 ThingDeviceOSCategoryCat1 
#endif 

#ifndef TYDeviceOSCategoryBeacon 
#define TYDeviceOSCategoryBeacon ThingDeviceOSCategoryBeacon 
#endif 

#ifndef TYDeviceOSCategoryBeaconSub 
#define TYDeviceOSCategoryBeaconSub ThingDeviceOSCategoryBeaconSub 
#endif 

#ifndef TYDeviceOSCategoryGatewayWifi 
#define TYDeviceOSCategoryGatewayWifi ThingDeviceOSCategoryGatewayWifi 
#endif 

#ifndef TYDeviceOSCategoryGatewayCable 
#define TYDeviceOSCategoryGatewayCable ThingDeviceOSCategoryGatewayCable 
#endif 

#ifndef TYDeviceOSCategoryGatewaySigMeshElection 
#define TYDeviceOSCategoryGatewaySigMeshElection ThingDeviceOSCategoryGatewaySigMeshElection 
#endif 

#ifndef TYDeviceOSCategoryGroupWifi 
#define TYDeviceOSCategoryGroupWifi ThingDeviceOSCategoryGroupWifi 
#endif 

#ifndef TYDeviceOSCategoryGroupBleMesh 
#define TYDeviceOSCategoryGroupBleMesh ThingDeviceOSCategoryGroupBleMesh 
#endif 

#ifndef TYDeviceOSCategoryGroupZigBee 
#define TYDeviceOSCategoryGroupZigBee ThingDeviceOSCategoryGroupZigBee 
#endif 

#ifndef TYDeviceOSCategoryGroupSigMesh 
#define TYDeviceOSCategoryGroupSigMesh ThingDeviceOSCategoryGroupSigMesh 
#endif 

#ifndef TYDeviceOSCategoryGroupBeacon 
#define TYDeviceOSCategoryGroupBeacon ThingDeviceOSCategoryGroupBeacon 
#endif 

#ifndef TYEventPipelineType 
#define TYEventPipelineType ThingEventPipelineType 
#endif 

#ifndef TYEventPipelineTypeLAN 
#define TYEventPipelineTypeLAN ThingEventPipelineTypeLAN 
#endif 

#ifndef TYEventPipelineTypeMQTT 
#define TYEventPipelineTypeMQTT ThingEventPipelineTypeMQTT 
#endif 

#ifndef TYEventPipelineTypeHTTP 
#define TYEventPipelineTypeHTTP ThingEventPipelineTypeHTTP 
#endif 

#ifndef TYEventPipelineTypeBLE 
#define TYEventPipelineTypeBLE ThingEventPipelineTypeBLE 
#endif 

#ifndef TYEventPipelineTypeSIGMesh 
#define TYEventPipelineTypeSIGMesh ThingEventPipelineTypeSIGMesh 
#endif 

#ifndef TYEventPipelineTypeBLEMesh 
#define TYEventPipelineTypeBLEMesh ThingEventPipelineTypeBLEMesh 
#endif 

#ifndef TYEventPipelineTypeOther 
#define TYEventPipelineTypeOther ThingEventPipelineTypeOther 
#endif 

#ifndef TYEventDpOptCode 
#define TYEventDpOptCode ThingEventDpOptCode 
#endif 

#ifndef TYEventDpOptCodeNoNextPipeline 
#define TYEventDpOptCodeNoNextPipeline ThingEventDpOptCodeNoNextPipeline 
#endif 

#ifndef TYEventDpOptCodePublishUnknownFail 
#define TYEventDpOptCodePublishUnknownFail ThingEventDpOptCodePublishUnknownFail 
#endif 

#ifndef TYEventDpOptCodeReportUnknownFail 
#define TYEventDpOptCodeReportUnknownFail ThingEventDpOptCodeReportUnknownFail 
#endif 

#ifndef TYEventDpOptCodeOffline 
#define TYEventDpOptCodeOffline ThingEventDpOptCodeOffline 
#endif 

#ifndef TYEventDpOptCodePublishApiFail 
#define TYEventDpOptCodePublishApiFail ThingEventDpOptCodePublishApiFail 
#endif 

#ifndef TYEventDpOptCodePublishVerifyFail 
#define TYEventDpOptCodePublishVerifyFail ThingEventDpOptCodePublishVerifyFail 
#endif 

#ifndef TYEventDpOptCodePublishNoPipeline 
#define TYEventDpOptCodePublishNoPipeline ThingEventDpOptCodePublishNoPipeline 
#endif 

#ifndef TYEventDpOptCodeUpgrading 
#define TYEventDpOptCodeUpgrading ThingEventDpOptCodeUpgrading 
#endif 

#ifndef TYEventDpOptCodeBleMTPFail 
#define TYEventDpOptCodeBleMTPFail ThingEventDpOptCodeBleMTPFail 
#endif 

#ifndef TYEventDpOptCodePhoneBleOff 
#define TYEventDpOptCodePhoneBleOff ThingEventDpOptCodePhoneBleOff 
#endif 

#ifndef TYEventDpOptCodeLocalKeyFail 
#define TYEventDpOptCodeLocalKeyFail ThingEventDpOptCodeLocalKeyFail 
#endif 

#ifndef TYEventDpOptCodeEncodeFail 
#define TYEventDpOptCodeEncodeFail ThingEventDpOptCodeEncodeFail 
#endif 

#ifndef TYEventDpOptCodeReportVerifyFail 
#define TYEventDpOptCodeReportVerifyFail ThingEventDpOptCodeReportVerifyFail 
#endif 

#ifndef TYEventDpOptCodeReportTimeout 
#define TYEventDpOptCodeReportTimeout ThingEventDpOptCodeReportTimeout 
#endif 

#ifndef TYEventDpOptCodeReportValueNotSame 
#define TYEventDpOptCodeReportValueNotSame ThingEventDpOptCodeReportValueNotSame 
#endif 

#ifndef TYEventDpOptCodeReportReplayBlock 
#define TYEventDpOptCodeReportReplayBlock ThingEventDpOptCodeReportReplayBlock 
#endif 

#ifndef TYEventDpOptCodeReportDualModeBlock 
#define TYEventDpOptCodeReportDualModeBlock ThingEventDpOptCodeReportDualModeBlock 
#endif 

#ifndef TYErrorDpEventPipelineKey 
#define TYErrorDpEventPipelineKey ThingErrorDpEventPipelineKey 
#endif 

#ifndef TYErrorDpEventOptCodeKey 
#define TYErrorDpEventOptCodeKey ThingErrorDpEventOptCodeKey 
#endif 

#ifndef TuyaSmartDeviceEventHelper 
#define TuyaSmartDeviceEventHelper ThingSmartDeviceEventHelper 
#endif 

#ifndef TuyaSmartDeviceEventUtil 
#define TuyaSmartDeviceEventUtil ThingSmartDeviceEventUtil 
#endif 

#ifndef tysdkControlEventWithAttribute 
#define tysdkControlEventWithAttribute thingsdkControlEventWithAttribute 
#endif 

#ifndef tysdkLanControlEventWithAttribute 
#define tysdkLanControlEventWithAttribute thingsdkLanControlEventWithAttribute 
#endif 

#ifndef tysdkThingModelControlWithAttribute 
#define tysdkThingModelControlWithAttribute thingsdkThingModelControlWithAttribute 
#endif 

#ifndef tysdkDpBuriedPublishDevice 
#define tysdkDpBuriedPublishDevice thingsdkDpBuriedPublishDevice 
#endif 

#ifndef tysdkDpBuriedPublishGroup 
#define tysdkDpBuriedPublishGroup thingsdkDpBuriedPublishGroup 
#endif 

#ifndef tysdkDpBuriedReportFailWithDevId 
#define tysdkDpBuriedReportFailWithDevId thingsdkDpBuriedReportFailWithDevId 
#endif 

#ifndef TuyaSmartDeviceCoreKit 
#define TuyaSmartDeviceCoreKit ThingSmartDeviceCoreKit 
#endif 

#ifndef TUYA_DEVICECORE_VERSION 
#define TUYA_DEVICECORE_VERSION THING_DEVICECORE_VERSION 
#endif 

#ifndef TUYA_CURRENT_GW_PROTOCOL_VERSION 
#define TUYA_CURRENT_GW_PROTOCOL_VERSION THING_CURRENT_GW_PROTOCOL_VERSION 
#endif 

#ifndef TUYA_CURRENT_LAN_PROTOCOL_VERSION 
#define TUYA_CURRENT_LAN_PROTOCOL_VERSION THING_CURRENT_LAN_PROTOCOL_VERSION 
#endif 

#ifndef TuyaSmartMQTTChannelDelegate 
#define TuyaSmartMQTTChannelDelegate ThingSmartMQTTChannelDelegate 
#endif 

#ifndef TuyaSmartSocketChannelDelegate 
#define TuyaSmartSocketChannelDelegate ThingSmartSocketChannelDelegate 
#endif 

#ifndef TYOTAErrorDomain 
#define TYOTAErrorDomain ThingOTAErrorDomain 
#endif 

#ifndef TYOTAErrorCode 
#define TYOTAErrorCode ThingOTAErrorCode 
#endif 

#ifndef TYOTAErrorCodeAllLatest 
#define TYOTAErrorCodeAllLatest ThingOTAErrorCodeAllLatest 
#endif 

#ifndef TYOTAErrorCodeCheckNoFirmware 
#define TYOTAErrorCodeCheckNoFirmware ThingOTAErrorCodeCheckNoFirmware 
#endif 

#ifndef TYOTAErrorCodeOnlyOneCanUpgradeSameTime 
#define TYOTAErrorCodeOnlyOneCanUpgradeSameTime ThingOTAErrorCodeOnlyOneCanUpgradeSameTime 
#endif 

#ifndef TYOTAErrorCodeDownloadFail 
#define TYOTAErrorCodeDownloadFail ThingOTAErrorCodeDownloadFail 
#endif 

#ifndef TYOTAErrorCodeFetchIfNeedSignalLimitFail 
#define TYOTAErrorCodeFetchIfNeedSignalLimitFail ThingOTAErrorCodeFetchIfNeedSignalLimitFail 
#endif 

#ifndef TYOTAErrorCodeSignalStrengthNotSatisfy 
#define TYOTAErrorCodeSignalStrengthNotSatisfy ThingOTAErrorCodeSignalStrengthNotSatisfy 
#endif 

#ifndef TYOTAErrorCodeLinkDeviceFail 
#define TYOTAErrorCodeLinkDeviceFail ThingOTAErrorCodeLinkDeviceFail 
#endif 

#ifndef TYOTAErrorCodeBLESubSwitchTimeOut 
#define TYOTAErrorCodeBLESubSwitchTimeOut ThingOTAErrorCodeBLESubSwitchTimeOut 
#endif 

#ifndef TYOTAErrorCodeDownloadCheckMD5Error 
#define TYOTAErrorCodeDownloadCheckMD5Error ThingOTAErrorCodeDownloadCheckMD5Error 
#endif 

#ifndef TYOTAErrorCodeSendUpgradePackageError 
#define TYOTAErrorCodeSendUpgradePackageError ThingOTAErrorCodeSendUpgradePackageError 
#endif 

#ifndef TYOTAErrorCodeDeviceOffline 
#define TYOTAErrorCodeDeviceOffline ThingOTAErrorCodeDeviceOffline 
#endif 

#ifndef TYOTAErrorCodeDeivcePreVerifyFail 
#define TYOTAErrorCodeDeivcePreVerifyFail ThingOTAErrorCodeDeivcePreVerifyFail 
#endif 

#ifndef TYOTAErrorCodeBluetoothNotOpen 
#define TYOTAErrorCodeBluetoothNotOpen ThingOTAErrorCodeBluetoothNotOpen 
#endif 

#ifndef TYOTAErrorCodeCheckUpdateFail 
#define TYOTAErrorCodeCheckUpdateFail ThingOTAErrorCodeCheckUpdateFail 
#endif 

#ifndef TYOTAErrorCodeCommonError 
#define TYOTAErrorCodeCommonError ThingOTAErrorCodeCommonError 
#endif 

#ifndef TYOTA 
#define TYOTA ThingOTA 
#endif 

#ifndef tysdk_OTAErrorWithCode 
#define tysdk_OTAErrorWithCode thingsdk_OTAErrorWithCode 
#endif 

#ifndef tysdk_OTADefaultErrorWithCode 
#define tysdk_OTADefaultErrorWithCode thingsdk_OTADefaultErrorWithCode 
#endif 

#ifndef TuyaSmart_TuyaSmartDevice 
#define TuyaSmart_TuyaSmartDevice ThingSmart_ThingSmartDevice 
#endif 

#ifndef TYDeviceOnlineModeLocal 
#define TYDeviceOnlineModeLocal ThingDeviceOnlineModeLocal 
#endif 

#ifndef TYDeviceOnlineModeInternet 
#define TYDeviceOnlineModeInternet ThingDeviceOnlineModeInternet 
#endif 

#ifndef TYDeviceOnlineModeOffline 
#define TYDeviceOnlineModeOffline ThingDeviceOnlineModeOffline 
#endif 

#ifndef TYDeviceOnlineMode 
#define TYDeviceOnlineMode ThingDeviceOnlineMode 
#endif 

#ifndef TYDevicePublishModeLocal 
#define TYDevicePublishModeLocal ThingDevicePublishModeLocal 
#endif 

#ifndef TYDevicePublishModeInternet 
#define TYDevicePublishModeInternet ThingDevicePublishModeInternet 
#endif 

#ifndef TYDevicePublishModeAuto 
#define TYDevicePublishModeAuto ThingDevicePublishModeAuto 
#endif 

#ifndef TYDevicePublishMode 
#define TYDevicePublishMode ThingDevicePublishMode 
#endif 

#ifndef TuyaSmartThingMessageType 
#define TuyaSmartThingMessageType ThingSmartThingMessageType 
#endif 

#ifndef TuyaSmartThingMessageTypeProperty 
#define TuyaSmartThingMessageTypeProperty ThingSmartThingMessageTypeProperty 
#endif 

#ifndef TuyaSmartThingMessageTypeAction 
#define TuyaSmartThingMessageTypeAction ThingSmartThingMessageTypeAction 
#endif 

#ifndef TuyaSmartThingMessageTypeEvent 
#define TuyaSmartThingMessageTypeEvent ThingSmartThingMessageTypeEvent 
#endif 

#ifndef TuyaSmartDeviceDelegate 
#define TuyaSmartDeviceDelegate ThingSmartDeviceDelegate 
#endif 

#ifndef TuyaSmartDeviceUpgradeStatus 
#define TuyaSmartDeviceUpgradeStatus ThingSmartDeviceUpgradeStatus 
#endif 

#ifndef TYSuccessList 
#define TYSuccessList ThingSuccessList 
#endif 

#ifndef TYSuccessID 
#define TYSuccessID ThingSuccessID 
#endif 

#ifndef TYSuccessDict 
#define TYSuccessDict ThingSuccessDict 
#endif 

#ifndef TYSuccessBOOL 
#define TYSuccessBOOL ThingSuccessBOOL 
#endif 

#ifndef TuyaSmartDeviceModelUtils 
#define TuyaSmartDeviceModelUtils ThingSmartDeviceModelUtils 
#endif 

#ifndef TuyaSmartDeviceUpgradeStatusDefault 
#define TuyaSmartDeviceUpgradeStatusDefault ThingSmartDeviceUpgradeStatusDefault 
#endif 

#ifndef TuyaSmartDeviceUpgradeStatusReady 
#define TuyaSmartDeviceUpgradeStatusReady ThingSmartDeviceUpgradeStatusReady 
#endif 

#ifndef TuyaSmartDeviceUpgradeStatusUpgrading 
#define TuyaSmartDeviceUpgradeStatusUpgrading ThingSmartDeviceUpgradeStatusUpgrading 
#endif 

#ifndef TuyaSmartDeviceUpgradeStatusSuccess 
#define TuyaSmartDeviceUpgradeStatusSuccess ThingSmartDeviceUpgradeStatusSuccess 
#endif 

#ifndef TuyaSmartDeviceUpgradeStatusFailure 
#define TuyaSmartDeviceUpgradeStatusFailure ThingSmartDeviceUpgradeStatusFailure 
#endif 

#ifndef TuyaSmartDeviceUpgradeStatusWaitingExectue 
#define TuyaSmartDeviceUpgradeStatusWaitingExectue ThingSmartDeviceUpgradeStatusWaitingExectue 
#endif 

#ifndef TuyaSmartDeviceUpgradeStatusDownloaded 
#define TuyaSmartDeviceUpgradeStatusDownloaded ThingSmartDeviceUpgradeStatusDownloaded 
#endif 

#ifndef TuyaSmartDeviceUpgradeStatusTimeout 
#define TuyaSmartDeviceUpgradeStatusTimeout ThingSmartDeviceUpgradeStatusTimeout 
#endif 

#ifndef TuyaSmartDeviceUpgradeStatusLocalPrepare 
#define TuyaSmartDeviceUpgradeStatusLocalPrepare ThingSmartDeviceUpgradeStatusLocalPrepare 
#endif 

#ifndef TuyaSmartDeviceUpgradeMode 
#define TuyaSmartDeviceUpgradeMode ThingSmartDeviceUpgradeMode 
#endif 

#ifndef TuyaSmartDeviceUpgradeModeNormal 
#define TuyaSmartDeviceUpgradeModeNormal ThingSmartDeviceUpgradeModeNormal 
#endif 

#ifndef TuyaSmartDeviceUpgradeModePidVersion 
#define TuyaSmartDeviceUpgradeModePidVersion ThingSmartDeviceUpgradeModePidVersion 
#endif 

#ifndef TuyaSmart_TuyaSmartSchemaModel 
#define TuyaSmart_TuyaSmartSchemaModel ThingSmart_ThingSmartSchemaModel 
#endif 

#ifndef TuyaSmartSchemaModel 
#define TuyaSmartSchemaModel ThingSmartSchemaModel 
#endif 

#ifndef TuyaSmartLanMessageModel 
#define TuyaSmartLanMessageModel ThingSmartLanMessageModel 
#endif 

#ifndef TuyaSmart_TuyaSmartSchemaPropertyModel 
#define TuyaSmart_TuyaSmartSchemaPropertyModel ThingSmart_ThingSmartSchemaPropertyModel 
#endif 

#ifndef TuyaSmartSchemaPropertyModel 
#define TuyaSmartSchemaPropertyModel ThingSmartSchemaPropertyModel 
#endif 

#ifndef TYCoreCacheServiceDelegate 
#define TYCoreCacheServiceDelegate ThingCoreCacheServiceDelegate 
#endif 

#ifndef TYCoreCacheService 
#define TYCoreCacheService ThingCoreCacheService 
#endif 

#ifndef TYSDK_SINGLETON 
#define TYSDK_SINGLETON ThingSDK_SINGLETON 
#endif 

#ifndef TuyaSmart_TuyaSmartGroup 
#define TuyaSmart_TuyaSmartGroup ThingSmart_ThingSmartGroup 
#endif 

#ifndef TuyaSmartGroup 
#define TuyaSmartGroup ThingSmartGroup 
#endif 

#ifndef TuyaSmartGroupDelegate 
#define TuyaSmartGroupDelegate ThingSmartGroupDelegate 
#endif 

#ifndef TuyaSmartDeviceOTAModelUpgradeStatusNone 
#define TuyaSmartDeviceOTAModelUpgradeStatusNone ThingSmartDeviceOTAModelUpgradeStatusNone 
#endif 

#ifndef TuyaSmartDeviceOTAModelUpgradeStatusUpgrading 
#define TuyaSmartDeviceOTAModelUpgradeStatusUpgrading ThingSmartDeviceOTAModelUpgradeStatusUpgrading 
#endif 

#ifndef TuyaSmartDeviceOTAModelUpgradeStatus 
#define TuyaSmartDeviceOTAModelUpgradeStatus ThingSmartDeviceOTAModelUpgradeStatus 
#endif 

#ifndef TuyaSmartDeviceCapability 
#define TuyaSmartDeviceCapability ThingSmartDeviceCapability 
#endif 

#ifndef TuyaSmartDeviceCapabilityOTAControlDP 
#define TuyaSmartDeviceCapabilityOTAControlDP ThingSmartDeviceCapabilityOTAControlDP 
#endif 

#ifndef TuyaSmartDeviceCapabilityUseLEOnline 
#define TuyaSmartDeviceCapabilityUseLEOnline ThingSmartDeviceCapabilityUseLEOnline 
#endif 

#ifndef TuyaSmartDeviceCapabilityBeacon 
#define TuyaSmartDeviceCapabilityBeacon ThingSmartDeviceCapabilityBeacon 
#endif 

#ifndef TuyaSmartDeviceCapabilityLinkEncrypt 
#define TuyaSmartDeviceCapabilityLinkEncrypt ThingSmartDeviceCapabilityLinkEncrypt 
#endif 

#ifndef TuyaSmartDeviceCapabilityExtend 
#define TuyaSmartDeviceCapabilityExtend ThingSmartDeviceCapabilityExtend 
#endif 

#ifndef TuyaSmartDeviceCapabilityTimer 
#define TuyaSmartDeviceCapabilityTimer ThingSmartDeviceCapabilityTimer 
#endif 

#ifndef TuyaSmartDeviceCapabilityLinkBT 
#define TuyaSmartDeviceCapabilityLinkBT ThingSmartDeviceCapabilityLinkBT 
#endif 

#ifndef TuyaSmartDeviceOTAModel 
#define TuyaSmartDeviceOTAModel ThingSmartDeviceOTAModel 
#endif 

#ifndef TuyaSmartMQTTConfiguration 
#define TuyaSmartMQTTConfiguration ThingSmartMQTTConfiguration 
#endif 

#ifndef TuyaSmartMQTTConfigTransferProtocol 
#define TuyaSmartMQTTConfigTransferProtocol ThingSmartMQTTConfigTransferProtocol 
#endif 

#ifndef TuyaSmartMQTTConfigModel 
#define TuyaSmartMQTTConfigModel ThingSmartMQTTConfigModel 
#endif 

#ifndef TuyaSmartMQTTConfig 
#define TuyaSmartMQTTConfig ThingSmartMQTTConfig 
#endif 

#ifndef TuyaSmartSocketConfig 
#define TuyaSmartSocketConfig ThingSmartSocketConfig 
#endif 

#ifndef TuyaSmartStatusSchemaModel 
#define TuyaSmartStatusSchemaModel ThingSmartStatusSchemaModel 
#endif 

#ifndef TuyaSmartFunctionSchemaModel 
#define TuyaSmartFunctionSchemaModel ThingSmartFunctionSchemaModel 
#endif 

#ifndef TuyaSmartStandSchemaModel 
#define TuyaSmartStandSchemaModel ThingSmartStandSchemaModel 
#endif 

#ifndef TuyaSmart_TuyaSmartBleMeshModel 
#define TuyaSmart_TuyaSmartBleMeshModel ThingSmart_ThingSmartBleMeshModel 
#endif 

#ifndef TuyaSmartBleMeshModel 
#define TuyaSmartBleMeshModel ThingSmartBleMeshModel 
#endif 

#ifndef TuyaSmartThingServiceModel 
#define TuyaSmartThingServiceModel ThingSmartThingServiceModel 
#endif 

#ifndef TuyaSmartThingProperty 
#define TuyaSmartThingProperty ThingSmartThingProperty 
#endif 

#ifndef TuyaSmartThingAction 
#define TuyaSmartThingAction ThingSmartThingAction 
#endif 

#ifndef TuyaSmartThingEvent 
#define TuyaSmartThingEvent ThingSmartThingEvent 
#endif 

#ifndef TuyaSmartThingModel 
#define TuyaSmartThingModel ThingSmartThingModel 
#endif 



#endif
