//
// TuyaSmartFirmwareUpgradeStatusModel.h
// TuyaSmartDeviceCoreKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartFirmwareUpgradeStatusModel.

#import "TuyaSmartDeviceCoreKitMacro.h"
#import <ThingSmartDeviceCoreKit/ThingSmartFirmwareUpgradeStatusModel.h>
#import <Foundation/Foundation.h>
