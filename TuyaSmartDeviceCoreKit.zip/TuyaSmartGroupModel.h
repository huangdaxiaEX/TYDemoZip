//
// TuyaSmartGroupModel.h
// TuyaSmartDeviceCoreKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartGroupModel.

#import "TuyaSmartDeviceCoreKitMacro.h"
#import <ThingSmartDeviceCoreKit/ThingSmartGroupModel.h>
#import <Foundation/Foundation.h>
