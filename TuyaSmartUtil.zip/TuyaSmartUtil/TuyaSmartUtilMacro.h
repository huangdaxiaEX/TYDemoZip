#ifndef TuyaSmartUtilMacro_h
#define TuyaSmartUtilMacro_h

#ifndef TYSDKOpenSSLHelper 
#define TYSDKOpenSSLHelper ThingSDKOpenSSLHelper 
#endif 

#ifndef TuyaSmartModuleRouter 
#define TuyaSmartModuleRouter ThingSmartModuleRouter 
#endif 

#ifndef TYSDKURL 
#define TYSDKURL ThingSDKURL 
#endif 

#ifndef tysdk_urlEncodeString 
#define tysdk_urlEncodeString thingsdk_urlEncodeString 
#endif 

#ifndef tysdk_urlDecodeString 
#define tysdk_urlDecodeString thingsdk_urlDecodeString 
#endif 

#ifndef TYSDKQuery 
#define TYSDKQuery ThingSDKQuery 
#endif 

#ifndef tysdk_queryDict 
#define tysdk_queryDict thingsdk_queryDict 
#endif 

#ifndef TYSDKHex 
#define TYSDKHex ThingSDKHex 
#endif 

#ifndef tysdk_stringFromHexString 
#define tysdk_stringFromHexString thingsdk_stringFromHexString 
#endif 

#ifndef tysdk_hexString 
#define tysdk_hexString thingsdk_hexString 
#endif 

#ifndef tysdk_dataTransformBigSmall 
#define tysdk_dataTransformBigSmall thingsdk_dataTransformBigSmall 
#endif 

#ifndef tysdk_dataFromHexString 
#define tysdk_dataFromHexString thingsdk_dataFromHexString 
#endif 

#ifndef TYSDKLocalNetworkStatus 
#define TYSDKLocalNetworkStatus ThingSDKLocalNetworkStatus 
#endif 

#ifndef kTYSDKLocalNetworkStatusNotConnected 
#define kTYSDKLocalNetworkStatusNotConnected kThingSDKLocalNetworkStatusNotConnected 
#endif 

#ifndef kTYSDKLocalNetworkStatusNotDeterminedOrDenied 
#define kTYSDKLocalNetworkStatusNotDeterminedOrDenied kThingSDKLocalNetworkStatusNotDeterminedOrDenied 
#endif 

#ifndef kTYSDKLocalNetworkStatusStatusAuthorized 
#define kTYSDKLocalNetworkStatusStatusAuthorized kThingSDKLocalNetworkStatusStatusAuthorized 
#endif 

#ifndef TYSDKLocalNetworkManager 
#define TYSDKLocalNetworkManager ThingSDKLocalNetworkManager 
#endif 

#ifndef TYSDKRandom 
#define TYSDKRandom ThingSDKRandom 
#endif 

#ifndef tysdk_randomIntBetweenMin 
#define tysdk_randomIntBetweenMin thingsdk_randomIntBetweenMin 
#endif 

#ifndef tysdk_randomFloat 
#define tysdk_randomFloat thingsdk_randomFloat 
#endif 

#ifndef tysdk_randomFloatBetweenMin 
#define tysdk_randomFloatBetweenMin thingsdk_randomFloatBetweenMin 
#endif 

#ifndef TYSDKCategory 
#define TYSDKCategory ThingSDKCategory 
#endif 

#ifndef tysdk_safeSetObject 
#define tysdk_safeSetObject thingsdk_safeSetObject 
#endif 

#ifndef TYNetworkStatusListener 
#define TYNetworkStatusListener ThingNetworkStatusListener 
#endif 

#ifndef TuyaSmartModuleProtocol 
#define TuyaSmartModuleProtocol ThingSmartModuleProtocol 
#endif 

#ifndef TuyaSmartDeviceCoreEntry 
#define TuyaSmartDeviceCoreEntry ThingSmartDeviceCoreEntry 
#endif 

#ifndef TuyaSmartChannelRegEntry 
#define TuyaSmartChannelRegEntry ThingSmartChannelRegEntry 
#endif 

#ifndef TYSDKJSON 
#define TYSDKJSON ThingSDKJSON 
#endif 

#ifndef tysdk_objectFromJSONString 
#define tysdk_objectFromJSONString thingsdk_objectFromJSONString 
#endif 

#ifndef tysdk_JSONString 
#define tysdk_JSONString thingsdk_JSONString 
#endif 

#ifndef tysdk_JSONStringWithOptions 
#define tysdk_JSONStringWithOptions thingsdk_JSONStringWithOptions 
#endif 

#ifndef TYAntiReplayService 
#define TYAntiReplayService ThingAntiReplayService 
#endif 

#ifndef TYSDK_SINGLETON 
#define TYSDK_SINGLETON ThingSDK_SINGLETON 
#endif 

#ifndef TYSDKNotification 
#define TYSDKNotification ThingSDKNotification 
#endif 

#ifndef tysdk_postNotificationName 
#define tysdk_postNotificationName thingsdk_postNotificationName 
#endif 

#ifndef TYSDKEnCrypt 
#define TYSDKEnCrypt ThingSDKEnCrypt 
#endif 

#ifndef tysdk_sha1String 
#define tysdk_sha1String thingsdk_sha1String 
#endif 

#ifndef tysdk_md5String 
#define tysdk_md5String thingsdk_md5String 
#endif 

#ifndef tysdk_sha256String 
#define tysdk_sha256String thingsdk_sha256String 
#endif 

#ifndef tysdk_aes128EncryptWithKey 
#define tysdk_aes128EncryptWithKey thingsdk_aes128EncryptWithKey 
#endif 

#ifndef tysdk_aes128CBCEncryptWithKey 
#define tysdk_aes128CBCEncryptWithKey thingsdk_aes128CBCEncryptWithKey 
#endif 

#ifndef tysdk_aes128NoPaddingEncryptWithKey 
#define tysdk_aes128NoPaddingEncryptWithKey thingsdk_aes128NoPaddingEncryptWithKey 
#endif 

#ifndef tysdk_aes128DecryptWithKey 
#define tysdk_aes128DecryptWithKey thingsdk_aes128DecryptWithKey 
#endif 

#ifndef tysdk_aes128CBCDecryptWithKey 
#define tysdk_aes128CBCDecryptWithKey thingsdk_aes128CBCDecryptWithKey 
#endif 

#ifndef tysdk_aes128NoPaddingDecryptWithKey 
#define tysdk_aes128NoPaddingDecryptWithKey thingsdk_aes128NoPaddingDecryptWithKey 
#endif 

#ifndef tysdk_aes256EncryptWithKey 
#define tysdk_aes256EncryptWithKey thingsdk_aes256EncryptWithKey 
#endif 

#ifndef tysdk_aes256DecryptWithKey 
#define tysdk_aes256DecryptWithKey thingsdk_aes256DecryptWithKey 
#endif 

#ifndef tysdk_hexRSAEncryptWithPublicKey 
#define tysdk_hexRSAEncryptWithPublicKey thingsdk_hexRSAEncryptWithPublicKey 
#endif 

#ifndef tysdk_hexRSANoPaddingEncryptWithPublicKey 
#define tysdk_hexRSANoPaddingEncryptWithPublicKey thingsdk_hexRSANoPaddingEncryptWithPublicKey 
#endif 

#ifndef tysdk_hmacSHA256StringWithKey 
#define tysdk_hmacSHA256StringWithKey thingsdk_hmacSHA256StringWithKey 
#endif 

#ifndef TYSDKEncrypt 
#define TYSDKEncrypt ThingSDKEncrypt 
#endif 

#ifndef tysdk_aes128EncryptWithKeyData 
#define tysdk_aes128EncryptWithKeyData thingsdk_aes128EncryptWithKeyData 
#endif 

#ifndef tysdk_aes128CBCEncryptWithKeyData 
#define tysdk_aes128CBCEncryptWithKeyData thingsdk_aes128CBCEncryptWithKeyData 
#endif 

#ifndef tysdk_aes128NoPaddingEncryptWithKeyData 
#define tysdk_aes128NoPaddingEncryptWithKeyData thingsdk_aes128NoPaddingEncryptWithKeyData 
#endif 

#ifndef tysdk_aes128DecryptWithKeyData 
#define tysdk_aes128DecryptWithKeyData thingsdk_aes128DecryptWithKeyData 
#endif 

#ifndef tysdk_aes128CBCDecryptWithKeyData 
#define tysdk_aes128CBCDecryptWithKeyData thingsdk_aes128CBCDecryptWithKeyData 
#endif 

#ifndef tysdk_aes128NoPaddingDecryptWithKeyData 
#define tysdk_aes128NoPaddingDecryptWithKeyData thingsdk_aes128NoPaddingDecryptWithKeyData 
#endif 

#ifndef tysdk_aes256EncryptWithKeyData 
#define tysdk_aes256EncryptWithKeyData thingsdk_aes256EncryptWithKeyData 
#endif 

#ifndef tysdk_aes256DecryptWithKeyData 
#define tysdk_aes256DecryptWithKeyData thingsdk_aes256DecryptWithKeyData 
#endif 

#ifndef tysdk_hmacSHA256DataWithKey 
#define tysdk_hmacSHA256DataWithKey thingsdk_hmacSHA256DataWithKey 
#endif 

#ifndef tysdk_hmacSHA256DataWithKeyData 
#define tysdk_hmacSHA256DataWithKeyData thingsdk_hmacSHA256DataWithKeyData 
#endif 

#ifndef tysdk_encryptAes128GcmWithKey 
#define tysdk_encryptAes128GcmWithKey thingsdk_encryptAes128GcmWithKey 
#endif 

#ifndef tysdk_decryptAes128GcmWithKey 
#define tysdk_decryptAes128GcmWithKey thingsdk_decryptAes128GcmWithKey 
#endif 

#ifndef tysdk_aes128GCMDencryptWithKeyData 
#define tysdk_aes128GCMDencryptWithKeyData thingsdk_aes128GCMDencryptWithKeyData 
#endif 

#ifndef tysdk_aes128GCMEncryptWithKeyData 
#define tysdk_aes128GCMEncryptWithKeyData thingsdk_aes128GCMEncryptWithKeyData 
#endif 

#ifndef TuyaSmartMbedTLS 
#define TuyaSmartMbedTLS ThingSmartMbedTLS 
#endif 

#ifndef TuyaSmartMbedTLSDelegate 
#define TuyaSmartMbedTLSDelegate ThingSmartMbedTLSDelegate 
#endif 

#ifndef TYSDKFile 
#define TYSDKFile ThingSDKFile 
#endif 

#ifndef tysdk_getAtDocumentPath 
#define tysdk_getAtDocumentPath thingsdk_getAtDocumentPath 
#endif 

#ifndef tysdk_mkdirAtPath 
#define tysdk_mkdirAtPath thingsdk_mkdirAtPath 
#endif 

#ifndef tysdk_fileExistsAtPath 
#define tysdk_fileExistsAtPath thingsdk_fileExistsAtPath 
#endif 

#ifndef tysdk_delFileAtPath 
#define tysdk_delFileAtPath thingsdk_delFileAtPath 
#endif 

#ifndef tysdk_createFileAtPath 
#define tysdk_createFileAtPath thingsdk_createFileAtPath 
#endif 

#ifndef TYWeakProxy 
#define TYWeakProxy ThingWeakProxy 
#endif 

#ifndef TuyaSmartWeakProxy 
#define TuyaSmartWeakProxy ThingSmartWeakProxy 
#endif 

#ifndef TYSDKOffset 
#define TYSDKOffset ThingSDKOffset 
#endif 

#ifndef tysdk_serverTimeIntervalSince1970 
#define tysdk_serverTimeIntervalSince1970 thingsdk_serverTimeIntervalSince1970 
#endif 

#ifndef tysdk_timeZone 
#define tysdk_timeZone thingsdk_timeZone 
#endif 

#ifndef TYErrorDomain 
#define TYErrorDomain ThingErrorDomain 
#endif 

#ifndef TUYA_NETWORK_ERROR 
#define TUYA_NETWORK_ERROR THING_NETWORK_ERROR 
#endif 

#ifndef TUYA_COMMON_ERROR 
#define TUYA_COMMON_ERROR THING_COMMON_ERROR 
#endif 

#ifndef TUYA_PANEL_DECOMPRESS_ERROR 
#define TUYA_PANEL_DECOMPRESS_ERROR THING_PANEL_DECOMPRESS_ERROR 
#endif 

#ifndef TUYA_PANEL_SIZE_ERROR 
#define TUYA_PANEL_SIZE_ERROR THING_PANEL_SIZE_ERROR 
#endif 

#ifndef TUYA_TIME_VALIDATE_FAILED 
#define TUYA_TIME_VALIDATE_FAILED THING_TIME_VALIDATE_FAILED 
#endif 

#ifndef TUYA_GW_OFFLINE 
#define TUYA_GW_OFFLINE THING_GW_OFFLINE 
#endif 

#ifndef TUYA_USER_HAS_EXISTS 
#define TUYA_USER_HAS_EXISTS THING_USER_HAS_EXISTS 
#endif 

#ifndef TUYA_ILLEGAL_DP_DATA 
#define TUYA_ILLEGAL_DP_DATA THING_ILLEGAL_DP_DATA 
#endif 

#ifndef TUYA_DEVICE_HAS_RESET 
#define TUYA_DEVICE_HAS_RESET THING_DEVICE_HAS_RESET 
#endif 

#ifndef TUYA_USER_SESSION_LOSS 
#define TUYA_USER_SESSION_LOSS THING_USER_SESSION_LOSS 
#endif 

#ifndef TUYA_USER_SESSION_INVALID 
#define TUYA_USER_SESSION_INVALID THING_USER_SESSION_INVALID 
#endif 

#ifndef TUYA_QR_PROTOCOL_NOT_RECOGNIZED 
#define TUYA_QR_PROTOCOL_NOT_RECOGNIZED THING_QR_PROTOCOL_NOT_RECOGNIZED 
#endif 

#ifndef TUYA_TIMEOUT_ERROR 
#define TUYA_TIMEOUT_ERROR THING_TIMEOUT_ERROR 
#endif 

#ifndef TUYA_NO_AVAILABLE_NODE_ID 
#define TUYA_NO_AVAILABLE_NODE_ID THING_NO_AVAILABLE_NODE_ID 
#endif 

#ifndef TUYA_MOBILE_FORMAT_ERROR 
#define TUYA_MOBILE_FORMAT_ERROR THING_MOBILE_FORMAT_ERROR 
#endif 

#ifndef TUYA_MOBILE_ILLEGAL 
#define TUYA_MOBILE_ILLEGAL THING_MOBILE_ILLEGAL 
#endif 

#ifndef TUYA_MOBILE_CODE_ERROR 
#define TUYA_MOBILE_CODE_ERROR THING_MOBILE_CODE_ERROR 
#endif 

#ifndef TUYA_EMAIL_FORMAT_ERROR 
#define TUYA_EMAIL_FORMAT_ERROR THING_EMAIL_FORMAT_ERROR 
#endif 

#ifndef TUYA_EMAIL_ILLEGAL 
#define TUYA_EMAIL_ILLEGAL THING_EMAIL_ILLEGAL 
#endif 

#ifndef TUYA_EMAIL_CODE_ERROR 
#define TUYA_EMAIL_CODE_ERROR THING_EMAIL_CODE_ERROR 
#endif 

#ifndef TUYA_USER_NOT_EXISTS 
#define TUYA_USER_NOT_EXISTS THING_USER_NOT_EXISTS 
#endif 

#ifndef TUYA_GROUP_DEVICE_LIST_NOT_EMPTY 
#define TUYA_GROUP_DEVICE_LIST_NOT_EMPTY TUYA_GROUP_DEVICE_LIST_NOT_EMPThing 
#endif 

#ifndef TUYA_SOCKET_TCP_DISCONNECT 
#define TUYA_SOCKET_TCP_DISCONNECT THING_SOCKET_TCP_DISCONNECT 
#endif 

#ifndef TUYA_SOCKET_TCP_RESPONSE_ERROR 
#define TUYA_SOCKET_TCP_RESPONSE_ERROR THING_SOCKET_TCP_RESPONSE_ERROR 
#endif 

#ifndef TYSDKErrorCode 
#define TYSDKErrorCode ThingSDKErrorCode 
#endif 

#ifndef TYSDKDomain 
#define TYSDKDomain ThingSDKDomain 
#endif 

#ifndef tysdk_errorWithErrorCode 
#define tysdk_errorWithErrorCode thingsdk_errorWithErrorCode 
#endif 

#ifndef tysdk_errorWithCodeString 
#define tysdk_errorWithCodeString thingsdk_errorWithCodeString 
#endif 

#ifndef kTuyaSmartReachabilityChangedNotification 
#define kTuyaSmartReachabilityChangedNotification kThingSmartReachabilityChangedNotification 
#endif 

#ifndef TYSDKNetworkStatus 
#define TYSDKNetworkStatus ThingSDKNetworkStatus 
#endif 

#ifndef TYSDKNotReachable 
#define TYSDKNotReachable ThingSDKNotReachable 
#endif 

#ifndef TYSDKReachableViaWiFi 
#define TYSDKReachableViaWiFi ThingSDKReachableViaWiFi 
#endif 

#ifndef TYSDKReachableViaWWAN 
#define TYSDKReachableViaWWAN ThingSDKReachableViaWWAN 
#endif 

#ifndef TuyaSmartReachability 
#define TuyaSmartReachability ThingSmartReachability 
#endif 

#ifndef TuyaSmartNetworkReachable 
#define TuyaSmartNetworkReachable ThingSmartNetworkReachable 
#endif 

#ifndef TuyaSmartNetworkUnreachable 
#define TuyaSmartNetworkUnreachable ThingSmartNetworkUnreachable 
#endif 

#ifndef TuyaSmartUtil 
#define TuyaSmartUtil ThingSmartUtil 
#endif 

#ifndef TYSDK_DEF_SINGLETON 
#define TYSDK_DEF_SINGLETON ThingSDK_DEF_SINGLETON 
#endif 

#ifndef WEAKSELF_TYSDK 
#define WEAKSELF_TYSDK WEAKSELF_ThingSDK 
#endif 

#ifndef weakSelf_TYSDK 
#define weakSelf_TYSDK weakSelf_ThingSDK 
#endif 

#ifndef TYSuccessHandler 
#define TYSuccessHandler ThingSuccessHandler 
#endif 

#ifndef TYSuccessDict 
#define TYSuccessDict ThingSuccessDict 
#endif 

#ifndef TYSuccessString 
#define TYSuccessString ThingSuccessString 
#endif 

#ifndef TYSuccessList 
#define TYSuccessList ThingSuccessList 
#endif 

#ifndef TYSuccessBOOL 
#define TYSuccessBOOL ThingSuccessBOOL 
#endif 

#ifndef TYSuccessID 
#define TYSuccessID ThingSuccessID 
#endif 

#ifndef TYSuccessInt 
#define TYSuccessInt ThingSuccessInt 
#endif 

#ifndef TYSuccessLongLong 
#define TYSuccessLongLong ThingSuccessLongLong 
#endif 

#ifndef TYSuccessData 
#define TYSuccessData ThingSuccessData 
#endif 

#ifndef TYFailureHandler 
#define TYFailureHandler ThingFailureHandler 
#endif 

#ifndef TYFailureError 
#define TYFailureError ThingFailureError 
#endif 

#ifndef TYSDKLogUtils 
#define TYSDKLogUtils ThingSDKLogUtils 
#endif 

#ifndef tysdk_logByte 
#define tysdk_logByte thingsdk_logByte 
#endif 

#ifndef tysdk_eventWithType 
#define tysdk_eventWithType thingsdk_eventWithType 
#endif 

#ifndef tysdk_eventIdentifiter 
#define tysdk_eventIdentifiter thingsdk_eventIdentifiter 
#endif 

#ifndef tysdk_toInt 
#define tysdk_toInt thingsdk_toInt 
#endif 

#ifndef tysdk_toUInt 
#define tysdk_toUInt thingsdk_toUInt 
#endif 

#ifndef tysdk_hexToUInt 
#define tysdk_hexToUInt thingsdk_hexToUInt 
#endif 

#ifndef tysdk_toString 
#define tysdk_toString thingsdk_toString 
#endif 

#ifndef tysdk_toFloat 
#define tysdk_toFloat thingsdk_toFloat 
#endif 

#ifndef tysdk_toDouble 
#define tysdk_toDouble thingsdk_toDouble 
#endif 

#ifndef tysdk_toArray 
#define tysdk_toArray thingsdk_toArray 
#endif 

#ifndef tysdk_toDictionary 
#define tysdk_toDictionary thingsdk_toDictionary 
#endif 

#ifndef tysdk_toBool 
#define tysdk_toBool thingsdk_toBool 
#endif 

#ifndef tysdk_swizzleInstanceMethod 
#define tysdk_swizzleInstanceMethod thingsdk_swizzleInstanceMethod 
#endif 

#ifndef tysdk_swizzleClassMethod 
#define tysdk_swizzleClassMethod thingsdk_swizzleClassMethod 
#endif 

#ifndef TYSDKSafeMutableArray 
#define TYSDKSafeMutableArray ThingSDKSafeMutableArray 
#endif 

#ifndef TYSDKSafeMutableDictionary 
#define TYSDKSafeMutableDictionary ThingSDKSafeMutableDictionary 
#endif 

#ifndef TYSDKUserDefault 
#define TYSDKUserDefault ThingSDKUserDefault 
#endif 

#ifndef tysdk_setUserDefault 
#define tysdk_setUserDefault thingsdk_setUserDefault 
#endif 

#ifndef tysdk_getUserDefault 
#define tysdk_getUserDefault thingsdk_getUserDefault 
#endif 

#ifndef tysdk_removeUserDefault 
#define tysdk_removeUserDefault thingsdk_removeUserDefault 
#endif 

#ifndef tysdk_dispatch_async_on_default_global_thread 
#define tysdk_dispatch_async_on_default_global_thread thingsdk_dispatch_async_on_default_global_thread 
#endif 

#ifndef tysdk_dispatch_async_on_main_thread 
#define tysdk_dispatch_async_on_main_thread thingsdk_dispatch_async_on_main_thread 
#endif 

#ifndef tysdk_dispatch_sync_on_main_thread 
#define tysdk_dispatch_sync_on_main_thread thingsdk_dispatch_sync_on_main_thread 
#endif 

#ifndef TYSDKUtil 
#define TYSDKUtil ThingSDKUtil 
#endif 

#ifndef tysdk_currentWifiSSID 
#define tysdk_currentWifiSSID thingsdk_currentWifiSSID 
#endif 

#ifndef tysdk_currentWifiBSSID 
#define tysdk_currentWifiBSSID thingsdk_currentWifiBSSID 
#endif 

#ifndef tysdk_getIntValueByHex 
#define tysdk_getIntValueByHex thingsdk_getIntValueByHex 
#endif 

#ifndef tysdk_getISOcountryCode 
#define tysdk_getISOcountryCode thingsdk_getISOcountryCode 
#endif 

#ifndef tysdk_compareVesionWithDeviceVersion 
#define tysdk_compareVesionWithDeviceVersion thingsdk_compareVesionWithDeviceVersion 
#endif 

#ifndef tysdk_xorEncodeData 
#define tysdk_xorEncodeData thingsdk_xorEncodeData 
#endif 

#ifndef TYUtilHostAppExtensionString 
#define TYUtilHostAppExtensionString ThingUtilHostAppExtensionString 
#endif 

#ifndef TYUtilTodayWidgetExtensionString 
#define TYUtilTodayWidgetExtensionString ThingUtilTodayWidgetExtensionString 
#endif 

#ifndef TYUtilIntentExtensionString 
#define TYUtilIntentExtensionString ThingUtilIntentExtensionString 
#endif 

#ifndef TYUtilIntentUIExtensionString 
#define TYUtilIntentUIExtensionString ThingUtilIntentUIExtensionString 
#endif 

#ifndef TYUtilWatchKitExtensionString 
#define TYUtilWatchKitExtensionString ThingUtilWatchKitExtensionString 
#endif 

#ifndef tysdk_currentExtensionString 
#define tysdk_currentExtensionString thingsdk_currentExtensionString 
#endif 

#ifndef tysdk_isHostApp 
#define tysdk_isHostApp thingsdk_isHostApp 
#endif 

#ifndef tysdk_isAppExtension 
#define tysdk_isAppExtension thingsdk_isAppExtension 
#endif 

#ifndef tysdk_isWatchKitExtension 
#define tysdk_isWatchKitExtension thingsdk_isWatchKitExtension 
#endif 

#ifndef TYAntiReplayModel 
#define TYAntiReplayModel ThingAntiReplayModel 
#endif 

#ifndef TYLog 
#define TYLog ThingLog 
#endif 

#ifndef TYSDKLog 
#define TYSDKLog ThingSDKLog 
#endif 

#ifndef TYSDKLogDebug 
#define TYSDKLogDebug ThingSDKLogDebug 
#endif 

#ifndef TYSDKLogInfo 
#define TYSDKLogInfo ThingSDKLogInfo 
#endif 

#ifndef TYSDKLogWarn 
#define TYSDKLogWarn ThingSDKLogWarn 
#endif 

#ifndef TYSDKLogError 
#define TYSDKLogError ThingSDKLogError 
#endif 

#ifndef TYSmartUtilLog 
#define TYSmartUtilLog ThingSmartUtilLog 
#endif 

#ifndef logToTYLogLibrary 
#define logToTYLogLibrary logToThingLogLibrary 
#endif 

#ifndef TYSDKLocalizedString 
#define TYSDKLocalizedString ThingSDKLocalizedString 
#endif 

#ifndef TYSDKLanguage 
#define TYSDKLanguage ThingSDKLanguage 
#endif 

#ifndef tysdk_bundle 
#define tysdk_bundle thingsdk_bundle 
#endif 

#ifndef tysdk_getAppleLanguages 
#define tysdk_getAppleLanguages thingsdk_getAppleLanguages 
#endif 

#ifndef tysdk_localizedStringForKey 
#define tysdk_localizedStringForKey thingsdk_localizedStringForKey 
#endif 

#ifndef TYSDKDevice 
#define TYSDKDevice ThingSDKDevice 
#endif 

#ifndef tysdk_UUID 
#define tysdk_UUID thingsdk_UUID 
#endif 

#ifndef tysdk_generateUUID 
#define tysdk_generateUUID thingsdk_generateUUID 
#endif 

#ifndef tysdk_deviceNameString 
#define tysdk_deviceNameString thingsdk_deviceNameString 
#endif 

#ifndef tysdk_model 
#define tysdk_model thingsdk_model 
#endif 

#ifndef tysdk_systemName 
#define tysdk_systemName thingsdk_systemName 
#endif 

#ifndef tysdk_systemVersion 
#define tysdk_systemVersion thingsdk_systemVersion 
#endif 



#endif
