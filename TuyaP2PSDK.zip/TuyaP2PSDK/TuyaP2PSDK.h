//
// TuyaP2PSDK.h
// TuyaP2PSDK
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaP2PSDK.

#ifndef TuyaP2PSDK_h
#define TuyaP2PSDK_h

#import "TuyaP2PSDKMacro.h"
#import <UIKit/UIKit.h>
#endif
#endif
#endif

#import "TYP2PSdk.h"
