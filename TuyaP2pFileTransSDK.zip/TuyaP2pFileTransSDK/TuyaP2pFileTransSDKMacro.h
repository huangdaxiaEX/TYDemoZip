#ifndef TuyaP2pFileTransSDKMacro_h
#define TuyaP2pFileTransSDKMacro_h

#ifndef tuya_p2p_file_trans_defines 
#define tuya_p2p_file_trans_defines thing_p2p_file_trans_defines 
#endif 

#ifndef TuyaP2pFileTransSDK_version 
#define TuyaP2pFileTransSDK_version ThingP2pFileTransSDK_version 
#endif 

#ifndef kTuyaEvent_Download_Start 
#define kTuyaEvent_Download_Start kThingEvent_Download_Start 
#endif 

#ifndef kTuyaEvent_Download_Cancel 
#define kTuyaEvent_Download_Cancel kThingEvent_Download_Cancel 
#endif 

#ifndef kTuyaEvent_Upload_Start 
#define kTuyaEvent_Upload_Start kThingEvent_Upload_Start 
#endif 

#ifndef kTuyaEvent_Upload_Cancel 
#define kTuyaEvent_Upload_Cancel kThingEvent_Upload_Cancel 
#endif 

#ifndef kTuyaErrCode_NoErr 
#define kTuyaErrCode_NoErr kThingErrCode_NoErr 
#endif 

#ifndef kTuyaErrCode_FragmentEnd 
#define kTuyaErrCode_FragmentEnd kThingErrCode_FragmentEnd 
#endif 

#ifndef kTuyaErrCode_Err 
#define kTuyaErrCode_Err kThingErrCode_Err 
#endif 

#ifndef kTuyaErrCode_ModuleNotInitialized 
#define kTuyaErrCode_ModuleNotInitialized kThingErrCode_ModuleNotInitialized 
#endif 

#ifndef kTuyaErrCode_NotConnected 
#define kTuyaErrCode_NotConnected kThingErrCode_NotConnected 
#endif 

#ifndef kTuyaErrCode_SessionInvalid 
#define kTuyaErrCode_SessionInvalid kThingErrCode_SessionInvalid 
#endif 

#ifndef kTuyaErrCode_TimeOut 
#define kTuyaErrCode_TimeOut kThingErrCode_TimeOut 
#endif 

#ifndef kTuyaErrCode_ConnectionCancelled 
#define kTuyaErrCode_ConnectionCancelled kThingErrCode_ConnectionCancelled 
#endif 

#ifndef kTuyaErrCode_DeviceNotOnline 
#define kTuyaErrCode_DeviceNotOnline kThingErrCode_DeviceNotOnline 
#endif 

#ifndef kTuyaErrCode_CancelByUser 
#define kTuyaErrCode_CancelByUser kThingErrCode_CancelByUser 
#endif 

#ifndef kTuyaErrCode_DeviceError 
#define kTuyaErrCode_DeviceError kThingErrCode_DeviceError 
#endif 

#ifndef kTuyaErrCode_InvalidCommand 
#define kTuyaErrCode_InvalidCommand kThingErrCode_InvalidCommand 
#endif 

#ifndef kTuyaErrCode_ParamsInvalid 
#define kTuyaErrCode_ParamsInvalid kThingErrCode_ParamsInvalid 
#endif 

#ifndef kTuyaErrCode_DataInvalid 
#define kTuyaErrCode_DataInvalid kThingErrCode_DataInvalid 
#endif 

#ifndef kTuyaErrCode_Interrupted 
#define kTuyaErrCode_Interrupted kThingErrCode_Interrupted 
#endif 

#ifndef kTuyaErrCode_OperationNotAllowed 
#define kTuyaErrCode_OperationNotAllowed kThingErrCode_OperationNotAllowed 
#endif 

#ifndef kTuyaErrCode_VersionNotSupported 
#define kTuyaErrCode_VersionNotSupported kThingErrCode_VersionNotSupported 
#endif 

#ifndef kTuyaErrCode_DownloadFailed 
#define kTuyaErrCode_DownloadFailed kThingErrCode_DownloadFailed 
#endif 

#ifndef kTuyaErrCode_ResponseReturnErr 
#define kTuyaErrCode_ResponseReturnErr kThingErrCode_ResponseReturnErr 
#endif 

#ifndef kTuyaErrCode_ErrOccurDataTransport 
#define kTuyaErrCode_ErrOccurDataTransport kThingErrCode_ErrOccurDataTransport 
#endif 

#ifndef kTuyaErrCode_FileNotExists 
#define kTuyaErrCode_FileNotExists kThingErrCode_FileNotExists 
#endif 

#ifndef kTuyaErrCode_CreateFileFailed 
#define kTuyaErrCode_CreateFileFailed kThingErrCode_CreateFileFailed 
#endif 

#ifndef kTuyaErrCode_TooManyFilesDownload 
#define kTuyaErrCode_TooManyFilesDownload kThingErrCode_TooManyFilesDownload 
#endif 

#ifndef kTuyaErrCode_DeleteFilesFailed 
#define kTuyaErrCode_DeleteFilesFailed kThingErrCode_DeleteFilesFailed 
#endif 

#ifndef kTuyaErrCode_FileNameTooLong 
#define kTuyaErrCode_FileNameTooLong kThingErrCode_FileNameTooLong 
#endif 

#ifndef kTuyaSessionStatus_Connected 
#define kTuyaSessionStatus_Connected kThingSessionStatus_Connected 
#endif 

#ifndef kTuyaSessionStatus_ConnectTimeout 
#define kTuyaSessionStatus_ConnectTimeout kThingSessionStatus_ConnectTimeout 
#endif 

#ifndef kTuyaSessionStatus_ClosedRemote 
#define kTuyaSessionStatus_ClosedRemote kThingSessionStatus_ClosedRemote 
#endif 

#ifndef kTuyaSessionStatus_ClosedTimeOut 
#define kTuyaSessionStatus_ClosedTimeOut kThingSessionStatus_ClosedTimeOut 
#endif 

#ifndef kTuyaSessionStatus_ClosedCalled 
#define kTuyaSessionStatus_ClosedCalled kThingSessionStatus_ClosedCalled 
#endif 

#ifndef tuya_p2p_file_trans_callback 
#define tuya_p2p_file_trans_callback thing_p2p_file_trans_callback 
#endif 

#ifndef tuya_p2p_file_trans 
#define tuya_p2p_file_trans thing_p2p_file_trans 
#endif 

#ifndef TYP2PFileTransDelegate 
#define TYP2PFileTransDelegate ThingP2PFileTransDelegate 
#endif 

#ifndef TYP2PFileTrans 
#define TYP2PFileTrans ThingP2PFileTrans 
#endif 

#ifndef tuya_p2p_file_trans_sdk 
#define tuya_p2p_file_trans_sdk thing_p2p_file_trans_sdk 
#endif 

#ifndef TYMQTTSender 
#define TYMQTTSender ThingMQTTSender 
#endif 

#ifndef TYHttpsRequest 
#define TYHttpsRequest ThingHttpsRequest 
#endif 

#ifndef TYPhotoFrameSDK 
#define TYPhotoFrameSDK ThingPhotoFrameSDK 
#endif 



#endif
