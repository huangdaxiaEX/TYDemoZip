//
// tuya_p2p_file_trans_defines.h
// TuyaP2pFileTransSDK
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for tuya_p2p_file_trans_defines.

#import "TuyaP2pFileTransSDKMacro.h"
#import <ThingP2pFileTransSDK/tuya_p2p_file_trans_defines.h>
