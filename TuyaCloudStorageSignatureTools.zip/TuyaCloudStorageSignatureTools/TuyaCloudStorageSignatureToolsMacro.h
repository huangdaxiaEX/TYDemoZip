#ifndef TuyaCloudStorageSignatureToolsMacro_h
#define TuyaCloudStorageSignatureToolsMacro_h

#ifndef TuyaCloudStorageSignatureTools 
#define TuyaCloudStorageSignatureTools ThingCloudStorageSignatureTools 
#endif 



#endif
