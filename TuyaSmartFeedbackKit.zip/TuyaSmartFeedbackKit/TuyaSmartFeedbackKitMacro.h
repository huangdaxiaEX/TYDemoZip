#ifndef TuyaSmartFeedbackKitMacro_h
#define TuyaSmartFeedbackKitMacro_h

#ifndef TuyaSmartFeedbackItemModel 
#define TuyaSmartFeedbackItemModel ThingSmartFeedbackItemModel 
#endif 

#ifndef TuyaSmartFeedbackTalkListModel 
#define TuyaSmartFeedbackTalkListModel ThingSmartFeedbackTalkListModel 
#endif 

#ifndef TuyaSmartFeedbackKit 
#define TuyaSmartFeedbackKit ThingSmartFeedbackKit 
#endif 

#ifndef TuyaSmartFeedback 
#define TuyaSmartFeedback ThingSmartFeedback 
#endif 

#ifndef TYFailureError 
#define TYFailureError ThingFailureError 
#endif 

#ifndef TYSuccessHandler 
#define TYSuccessHandler ThingSuccessHandler 
#endif 

#ifndef TuyaSmartFeedbackTypeListModel 
#define TuyaSmartFeedbackTypeListModel ThingSmartFeedbackTypeListModel 
#endif 

#ifndef TuyaSmartFeedbackQuestion 
#define TuyaSmartFeedbackQuestion ThingSmartFeedbackQuestion 
#endif 

#ifndef TuyaSmartFeedbackAnswer 
#define TuyaSmartFeedbackAnswer ThingSmartFeedbackAnswer 
#endif 

#ifndef TuyaSmartFeedbackType 
#define TuyaSmartFeedbackType ThingSmartFeedbackType 
#endif 

#ifndef TuyaSmartFeedbackModel 
#define TuyaSmartFeedbackModel ThingSmartFeedbackModel 
#endif 



#endif
