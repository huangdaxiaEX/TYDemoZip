#ifndef TuyaVideoCodecSDKMacro_h
#define TuyaVideoCodecSDKMacro_h

#ifndef TYVideoCodecDefines 
#define TYVideoCodecDefines ThingVideoCodecDefines 
#endif 

#ifndef TuyaVideoCodecSDK_version 
#define TuyaVideoCodecSDK_version ThingVideoCodecSDK_version 
#endif 

#ifndef TY_VIDEO_DECODER_UNKNOW 
#define TY_VIDEO_DECODER_UNKNOW Thing_VIDEO_DECODER_UNKNOW 
#endif 

#ifndef TY_VIDEO_DECODER_H264 
#define TY_VIDEO_DECODER_H264 Thing_VIDEO_DECODER_H264 
#endif 

#ifndef TY_VIDEO_DECODER_H265 
#define TY_VIDEO_DECODER_H265 Thing_VIDEO_DECODER_H265 
#endif 

#ifndef TY_VIDEO_DECODER_MJPEG 
#define TY_VIDEO_DECODER_MJPEG Thing_VIDEO_DECODER_MJPEG 
#endif 

#ifndef TY_OUTPUT_YUV_UNKNOW 
#define TY_OUTPUT_YUV_UNKNOW Thing_OUTPUT_YUV_UNKNOW 
#endif 

#ifndef TY_OUTPUT_YUV_YUV420P 
#define TY_OUTPUT_YUV_YUV420P Thing_OUTPUT_YUV_YUV420P 
#endif 

#ifndef TY_OUTPUT_YUV_NV12 
#define TY_OUTPUT_YUV_NV12 Thing_OUTPUT_YUV_NV12 
#endif 

#ifndef TY_OUTPUT_YUV_PIXELBUFFER 
#define TY_OUTPUT_YUV_PIXELBUFFER Thing_OUTPUT_YUV_PIXELBUFFER 
#endif 

#ifndef TY_OUTPUT_YUV_TPYE_ID 
#define TY_OUTPUT_YUV_TPYE_ID Thing_OUTPUT_YUV_TPYE_ID 
#endif 

#ifndef TY_VIDEO_DECODER_TYPE_ID 
#define TY_VIDEO_DECODER_TYPE_ID Thing_VIDEO_DECODER_TYPE_ID 
#endif 

#ifndef TYfnVideoFrameRecved 
#define TYfnVideoFrameRecved ThingfnVideoFrameRecved 
#endif 

#ifndef TYGetSystemVersion 
#define TYGetSystemVersion ThingGetSystemVersion 
#endif 

#ifndef TYVideoDecoderSdkAPIs 
#define TYVideoDecoderSdkAPIs ThingVideoDecoderSdkAPIs 
#endif 

#ifndef TuyaVideoDecoderDelegate 
#define TuyaVideoDecoderDelegate ThingVideoDecoderDelegate 
#endif 

#ifndef TuyaVideoDecoder 
#define TuyaVideoDecoder ThingVideoDecoder 
#endif 



#endif
