//
// NSNumber+Characteristic.h
// TYBluetooth
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for NSNumber+Characteristic.

#import "TYBluetoothMacro.h"
#import <ThingBluetooth/NSNumber+Characteristic.h>
#import <Foundation/Foundation.h>
