#ifndef TYBluetoothMacro_h
#define TYBluetoothMacro_h

#ifndef TYBLEService 
#define TYBLEService ThingBLEService 
#endif 

#ifndef TYBLECentralPeripheralDiscoverServicesCallback 
#define TYBLECentralPeripheralDiscoverServicesCallback ThingBLECentralPeripheralDiscoverServicesCallback 
#endif 

#ifndef TYBLECentralPeripheralRSSIValueCallback 
#define TYBLECentralPeripheralRSSIValueCallback ThingBLECentralPeripheralRSSIValueCallback 
#endif 

#ifndef TYBLEPeripheral 
#define TYBLEPeripheral ThingBLEPeripheral 
#endif 

#ifndef TYBLECentralManager 
#define TYBLECentralManager ThingBLECentralManager 
#endif 

#ifndef TYBLECentralCharacteristicReadCallback 
#define TYBLECentralCharacteristicReadCallback ThingBLECentralCharacteristicReadCallback 
#endif 

#ifndef TYBLECentralCharacteristicNotifyCallback 
#define TYBLECentralCharacteristicNotifyCallback ThingBLECentralCharacteristicNotifyCallback 
#endif 

#ifndef TYBLECentralCharacteristicWriteCallback 
#define TYBLECentralCharacteristicWriteCallback ThingBLECentralCharacteristicWriteCallback 
#endif 

#ifndef TYBLECharacteristic 
#define TYBLECharacteristic ThingBLECharacteristic 
#endif 

#ifndef TYBLECentralServiceDiscoverCharacteristcsCallback 
#define TYBLECentralServiceDiscoverCharacteristcsCallback ThingBLECentralServiceDiscoverCharacteristcsCallback 
#endif 

#ifndef TYBLECentralManagerProtocol 
#define TYBLECentralManagerProtocol ThingBLECentralManagerProtocol 
#endif 

#ifndef TYBLECentralManagerState 
#define TYBLECentralManagerState ThingBLECentralManagerState 
#endif 

#ifndef TYBLECentralManagerStateUnknown 
#define TYBLECentralManagerStateUnknown ThingBLECentralManagerStateUnknown 
#endif 

#ifndef TYBLECentralManagerStateUnauthorized 
#define TYBLECentralManagerStateUnauthorized ThingBLECentralManagerStateUnauthorized 
#endif 

#ifndef TYBLECentralManagerStatePoweredOff 
#define TYBLECentralManagerStatePoweredOff ThingBLECentralManagerStatePoweredOff 
#endif 

#ifndef TYBLECentralManagerStatePoweredOn 
#define TYBLECentralManagerStatePoweredOn ThingBLECentralManagerStatePoweredOn 
#endif 

#ifndef TYBLECentralManagerDiscoveryDelegate 
#define TYBLECentralManagerDiscoveryDelegate ThingBLECentralManagerDiscoveryDelegate 
#endif 

#ifndef TYBLECentralManagerSessionDelegate 
#define TYBLECentralManagerSessionDelegate ThingBLECentralManagerSessionDelegate 
#endif 

#ifndef TYBLEConfig 
#define TYBLEConfig ThingBLEConfig 
#endif 

#ifndef TYSmartBLEAPMMessageModel 
#define TYSmartBLEAPMMessageModel ThingSmartBLEAPMMessageModel 
#endif 

#ifndef TYSmartBLEAPMEnum 
#define TYSmartBLEAPMEnum ThingSmartBLEAPMEnum 
#endif 

#ifndef TYSmartBLEAPMType_Activate 
#define TYSmartBLEAPMType_Activate ThingSmartBLEAPMType_Activate 
#endif 

#ifndef TYSmartBLEAPMType_Online 
#define TYSmartBLEAPMType_Online ThingSmartBLEAPMType_Online 
#endif 

#ifndef TYSmartBLEAPMType_Offline 
#define TYSmartBLEAPMType_Offline ThingSmartBLEAPMType_Offline 
#endif 

#ifndef TYSmartBLEAPMType_Delete 
#define TYSmartBLEAPMType_Delete ThingSmartBLEAPMType_Delete 
#endif 

#ifndef TYSmartBLEAPMType_Publish 
#define TYSmartBLEAPMType_Publish ThingSmartBLEAPMType_Publish 
#endif 

#ifndef TYSmartBLEAPMType_Report 
#define TYSmartBLEAPMType_Report ThingSmartBLEAPMType_Report 
#endif 

#ifndef TYSmartBLEAPMType 
#define TYSmartBLEAPMType ThingSmartBLEAPMType 
#endif 

#ifndef TYBluetoothUtil 
#define TYBluetoothUtil ThingBluetoothUtil 
#endif 

#ifndef TY_LOG_EVENT_BLE_RECONNECTION 
#define TY_LOG_EVENT_BLE_RECONNECTION Thing_LOG_EVENT_BLE_RECONNECTION 
#endif 

#ifndef TY_RECONNECT_LOG_TYPE_BLE_SUCCESS 
#define TY_RECONNECT_LOG_TYPE_BLE_SUCCESS Thing_RECONNECT_LOG_TYPE_BLE_SUCCESS 
#endif 

#ifndef TY_RECONNECT_LOG_TYPE_BLE_RETRY_SUCCESS 
#define TY_RECONNECT_LOG_TYPE_BLE_RETRY_SUCCESS Thing_RECONNECT_LOG_TYPE_BLE_RETRY_SUCCESS 
#endif 

#ifndef TY_RECONNECT_LOG_TYPE_BLE_FAILURE 
#define TY_RECONNECT_LOG_TYPE_BLE_FAILURE Thing_RECONNECT_LOG_TYPE_BLE_FAILURE 
#endif 

#ifndef TYSmartBLEAPMService 
#define TYSmartBLEAPMService ThingSmartBLEAPMService 
#endif 

#ifndef TYBLEAgentCentralNotifyCallback 
#define TYBLEAgentCentralNotifyCallback ThingBLEAgentCentralNotifyCallback 
#endif 

#ifndef TYBLEAgentCentralReadCallback 
#define TYBLEAgentCentralReadCallback ThingBLEAgentCentralReadCallback 
#endif 

#ifndef TYBLEAgentCentralWriteCallback 
#define TYBLEAgentCentralWriteCallback ThingBLEAgentCentralWriteCallback 
#endif 

#ifndef TYBLEAgentCentralDiscoverCallback 
#define TYBLEAgentCentralDiscoverCallback ThingBLEAgentCentralDiscoverCallback 
#endif 

#ifndef TYBLEAgentCentralConnectionCallback 
#define TYBLEAgentCentralConnectionCallback ThingBLEAgentCentralConnectionCallback 
#endif 

#ifndef TYBLEAgentRole 
#define TYBLEAgentRole ThingBLEAgentRole 
#endif 

#ifndef kTYBLEAgentDiscovery 
#define kTYBLEAgentDiscovery kThingBLEAgentDiscovery 
#endif 

#ifndef kTYBLEAgentSession 
#define kTYBLEAgentSession kThingBLEAgentSession 
#endif 

#ifndef kTYBLEAgentBoth 
#define kTYBLEAgentBoth kThingBLEAgentBoth 
#endif 

#ifndef TYBLEAgent 
#define TYBLEAgent ThingBLEAgent 
#endif 

#ifndef TY_BLE_AGENT_SIGEL_BLE 
#define TY_BLE_AGENT_SIGEL_BLE Thing_BLE_AGENT_SIGEL_BLE 
#endif 

#ifndef TY_BLE_AGENT_BLE_MESH 
#define TY_BLE_AGENT_BLE_MESH Thing_BLE_AGENT_BLE_MESH 
#endif 

#ifndef TY_BLE_AGENT_SIG_MESH 
#define TY_BLE_AGENT_SIG_MESH Thing_BLE_AGENT_SIG_MESH 
#endif 

#ifndef TY_BLE_AGENT_BLE_BEACON 
#define TY_BLE_AGENT_BLE_BEACON Thing_BLE_AGENT_BLE_BEACON 
#endif 

#ifndef TY_BLE_AGENT_BLE_MATTER 
#define TY_BLE_AGENT_BLE_MATTER Thing_BLE_AGENT_BLE_MATTER 
#endif 

#ifndef TYBLEAgentHub 
#define TYBLEAgentHub ThingBLEAgentHub 
#endif 

#ifndef TYCategory 
#define TYCategory ThingCategory 
#endif 

#ifndef TYBluetooth 
#define TYBluetooth ThingBluetooth 
#endif 



#endif
