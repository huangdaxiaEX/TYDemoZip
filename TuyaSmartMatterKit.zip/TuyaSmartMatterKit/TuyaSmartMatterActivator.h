//
// TuyaSmartMatterActivator.h
// TuyaSmartMatterKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartMatterActivator.

#import "TuyaSmartMatterKitMacro.h"
#import <ThingSmartMatterKit/ThingSmartMatterActivator.h>
#import <Foundation/Foundation.h>
