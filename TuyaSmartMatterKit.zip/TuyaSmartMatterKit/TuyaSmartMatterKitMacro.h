#ifndef TuyaSmartMatterKitMacro_h
#define TuyaSmartMatterKitMacro_h

#ifndef TuyaSmartMatterMultipleFabricPasscodeModel 
#define TuyaSmartMatterMultipleFabricPasscodeModel ThingSmartMatterMultipleFabricPasscodeModel 
#endif 

#ifndef TuyaSmartMatterBonjourModel 
#define TuyaSmartMatterBonjourModel ThingSmartMatterBonjourModel 
#endif 

#ifndef TuyaSmartMatterShareManager 
#define TuyaSmartMatterShareManager ThingSmartMatterShareManager 
#endif 

#ifndef TYSuccessHandler 
#define TYSuccessHandler ThingSuccessHandler 
#endif 

#ifndef TYFailureError 
#define TYFailureError ThingFailureError 
#endif 

#ifndef TuyaSmartMatterManager 
#define TuyaSmartMatterManager ThingSmartMatterManager 
#endif 

#ifndef TYSDK_SINGLETON 
#define TYSDK_SINGLETON ThingSDK_SINGLETON 
#endif 

#ifndef TYRendezvousInformationFlags 
#define TYRendezvousInformationFlags ThingRendezvousInformationFlags 
#endif 

#ifndef TYCommissioningFlow 
#define TYCommissioningFlow ThingCommissioningFlow 
#endif 

#ifndef TYOptionalQRCodeInfoType 
#define TYOptionalQRCodeInfoType ThingOptionalQRCodeInfoType 
#endif 

#ifndef TYMatterOptionalQRCodeInfo 
#define TYMatterOptionalQRCodeInfo ThingMatterOptionalQRCodeInfo 
#endif 

#ifndef TuyaSmartMatterSetupPayload 
#define TuyaSmartMatterSetupPayload ThingSmartMatterSetupPayload 
#endif 

#ifndef TuyaSmartMatterDeviceModel 
#define TuyaSmartMatterDeviceModel ThingSmartMatterDeviceModel 
#endif 

#ifndef TuyaSmartMatterDeviceCache 
#define TuyaSmartMatterDeviceCache ThingSmartMatterDeviceCache 
#endif 

#ifndef TuyaSmartMatterDeviceNOCModel 
#define TuyaSmartMatterDeviceNOCModel ThingSmartMatterDeviceNOCModel 
#endif 

#ifndef TuyaSmartMatterDevice 
#define TuyaSmartMatterDevice ThingSmartMatterDevice 
#endif 

#ifndef TuyaSmartMatterDeviceNodeModel 
#define TuyaSmartMatterDeviceNodeModel ThingSmartMatterDeviceNodeModel 
#endif 

#ifndef TuyaSmartMatterKitErrors 
#define TuyaSmartMatterKitErrors ThingSmartMatterKitErrors 
#endif 

#ifndef kTuyaSmartMatterKitErrorDomain 
#define kTuyaSmartMatterKitErrorDomain kThingSmartMatterKitErrorDomain 
#endif 

#ifndef TYSmartMatterKitError 
#define TYSmartMatterKitError ThingSmartMatterKitError 
#endif 

#ifndef kTYSmartMatterKitErrorFetchNodeIdError 
#define kTYSmartMatterKitErrorFetchNodeIdError kThingSmartMatterKitErrorFetchNodeIdError 
#endif 

#ifndef kTYSmartMatterKitErrorCheckFailed 
#define kTYSmartMatterKitErrorCheckFailed kThingSmartMatterKitErrorCheckFailed 
#endif 

#ifndef kTYSmartMatterKitErrorScanFailed 
#define kTYSmartMatterKitErrorScanFailed kThingSmartMatterKitErrorScanFailed 
#endif 

#ifndef kTYSmartMatterKitErrorBLEPairFailed 
#define kTYSmartMatterKitErrorBLEPairFailed kThingSmartMatterKitErrorBLEPairFailed 
#endif 

#ifndef kTYSmartMatterKitErrorDnsSDDiscoveryFailed 
#define kTYSmartMatterKitErrorDnsSDDiscoveryFailed kThingSmartMatterKitErrorDnsSDDiscoveryFailed 
#endif 

#ifndef kTYSmartMatterKitErrorCommissonFailed 
#define kTYSmartMatterKitErrorCommissonFailed kThingSmartMatterKitErrorCommissonFailed 
#endif 

#ifndef kTYSmartMatterKitErrorActivityCloudFailed 
#define kTYSmartMatterKitErrorActivityCloudFailed kThingSmartMatterKitErrorActivityCloudFailed 
#endif 

#ifndef kTYSmartMatterKitErrorFetchDeviceModelFailed 
#define kTYSmartMatterKitErrorFetchDeviceModelFailed kThingSmartMatterKitErrorFetchDeviceModelFailed 
#endif 

#ifndef kTYSmartMatterKitErrorGetThreadFailed 
#define kTYSmartMatterKitErrorGetThreadFailed kThingSmartMatterKitErrorGetThreadFailed 
#endif 

#ifndef kTYSmartMatterKitErrorDeviceNotSupport 
#define kTYSmartMatterKitErrorDeviceNotSupport kThingSmartMatterKitErrorDeviceNotSupport 
#endif 

#ifndef kTYSmartMatterKitErrorACLFailed 
#define kTYSmartMatterKitErrorACLFailed kThingSmartMatterKitErrorACLFailed 
#endif 

#ifndef kTYSmartMatterKitErrorPaseSessionFailed 
#define kTYSmartMatterKitErrorPaseSessionFailed kThingSmartMatterKitErrorPaseSessionFailed 
#endif 

#ifndef kTYSmartMatterKitErrorFabricInfoFailed 
#define kTYSmartMatterKitErrorFabricInfoFailed kThingSmartMatterKitErrorFabricInfoFailed 
#endif 

#ifndef kTYSmartMatterKitErrorCommonError 
#define kTYSmartMatterKitErrorCommonError kThingSmartMatterKitErrorCommonError 
#endif 

#ifndef kTYSmartMatterKitErrorFetchPassCodeFailed 
#define kTYSmartMatterKitErrorFetchPassCodeFailed kThingSmartMatterKitErrorFetchPassCodeFailed 
#endif 

#ifndef kTYSmartMatterKitErrorFabricNullInfo 
#define kTYSmartMatterKitErrorFabricNullInfo kThingSmartMatterKitErrorFabricNullInfo 
#endif 

#ifndef kTYSmartMatterKitErrorActiveTokenFailed 
#define kTYSmartMatterKitErrorActiveTokenFailed kThingSmartMatterKitErrorActiveTokenFailed 
#endif 

#ifndef kTYSmartMatterKitErrorQueryDeviceFailed 
#define kTYSmartMatterKitErrorQueryDeviceFailed kThingSmartMatterKitErrorQueryDeviceFailed 
#endif 

#ifndef kTYSmartMatterKitErrorFetchGatewayNodeIdFailed 
#define kTYSmartMatterKitErrorFetchGatewayNodeIdFailed kThingSmartMatterKitErrorFetchGatewayNodeIdFailed 
#endif 

#ifndef kTYSmartMatterKitFetchGatewayDeviceFailed 
#define kTYSmartMatterKitFetchGatewayDeviceFailed kThingSmartMatterKitFetchGatewayDeviceFailed 
#endif 

#ifndef kTYSmartMatterKitNOCChainFailed 
#define kTYSmartMatterKitNOCChainFailed kThingSmartMatterKitNOCChainFailed 
#endif 

#ifndef kTYSmartMatterKitRequestACLFailed 
#define kTYSmartMatterKitRequestACLFailed kThingSmartMatterKitRequestACLFailed 
#endif 

#ifndef kTYSmartMatterKitErrorFetchNodeIdFailed 
#define kTYSmartMatterKitErrorFetchNodeIdFailed kThingSmartMatterKitErrorFetchNodeIdFailed 
#endif 

#ifndef kTYSmartMatterKitErrorNodeEmptyFailed 
#define kTYSmartMatterKitErrorNodeEmptyFailed kThingSmartMatterKitErrorNodeEmptyFailed 
#endif 

#ifndef kTYSmartMatterKitCloundACLEmpty 
#define kTYSmartMatterKitCloundACLEmpty kThingSmartMatterKitCloundACLEmpty 
#endif 

#ifndef kTYSmartMatterKitWriteACLFailed 
#define kTYSmartMatterKitWriteACLFailed kThingSmartMatterKitWriteACLFailed 
#endif 

#ifndef kTYSmartMatterKitNotifyAclFailed 
#define kTYSmartMatterKitNotifyAclFailed kThingSmartMatterKitNotifyAclFailed 
#endif 

#ifndef kTYSmartMatterKitErrorDeviceOffLine 
#define kTYSmartMatterKitErrorDeviceOffLine kThingSmartMatterKitErrorDeviceOffLine 
#endif 

#ifndef kTYSmartMatterKitErrorControllerFailed 
#define kTYSmartMatterKitErrorControllerFailed kThingSmartMatterKitErrorControllerFailed 
#endif 

#ifndef kTYSmartMatterKitErrorInvaildParams 
#define kTYSmartMatterKitErrorInvaildParams kThingSmartMatterKitErrorInvaildParams 
#endif 

#ifndef kTYSmartMatterKitErrorConnectClose 
#define kTYSmartMatterKitErrorConnectClose kThingSmartMatterKitErrorConnectClose 
#endif 

#ifndef kTYSmartMatterKitErrorConnectDelete 
#define kTYSmartMatterKitErrorConnectDelete kThingSmartMatterKitErrorConnectDelete 
#endif 

#ifndef kTYSmartMatterKitErrorCommonFailed 
#define kTYSmartMatterKitErrorCommonFailed kThingSmartMatterKitErrorCommonFailed 
#endif 

#ifndef kTYSmartMatterKitErrorBLEScanFailed 
#define kTYSmartMatterKitErrorBLEScanFailed kThingSmartMatterKitErrorBLEScanFailed 
#endif 

#ifndef kTYSmartMatterKitErrorBLEScanTimeout 
#define kTYSmartMatterKitErrorBLEScanTimeout kThingSmartMatterKitErrorBLEScanTimeout 
#endif 

#ifndef kTYSmartMatterKitErrorNoUUID 
#define kTYSmartMatterKitErrorNoUUID kThingSmartMatterKitErrorNoUUID 
#endif 

#ifndef kTYSmartMatterKitErrorMatterConnectFailed 
#define kTYSmartMatterKitErrorMatterConnectFailed kThingSmartMatterKitErrorMatterConnectFailed 
#endif 

#ifndef kTYSmartMatterKitErrorReadAttributeFailed 
#define kTYSmartMatterKitErrorReadAttributeFailed kThingSmartMatterKitErrorReadAttributeFailed 
#endif 

#ifndef kTYSmartMatterKitErrorSendCommandFailed 
#define kTYSmartMatterKitErrorSendCommandFailed kThingSmartMatterKitErrorSendCommandFailed 
#endif 

#ifndef kTYSmartMatterKitErrorC3UUIDNoExist 
#define kTYSmartMatterKitErrorC3UUIDNoExist kThingSmartMatterKitErrorC3UUIDNoExist 
#endif 

#ifndef kTYSmartMatterKitErrorC3UUIDEmpty 
#define kTYSmartMatterKitErrorC3UUIDEmpty kThingSmartMatterKitErrorC3UUIDEmpty 
#endif 

#ifndef kTYSmartMatterKitErrorC3ParseFailed 
#define kTYSmartMatterKitErrorC3ParseFailed kThingSmartMatterKitErrorC3ParseFailed 
#endif 

#ifndef kTYSmartMatterKitErrorNotSupportAttribute 
#define kTYSmartMatterKitErrorNotSupportAttribute kThingSmartMatterKitErrorNotSupportAttribute 
#endif 

#ifndef kTYSmartMatterKitErrorNoChipDevice 
#define kTYSmartMatterKitErrorNoChipDevice kThingSmartMatterKitErrorNoChipDevice 
#endif 

#ifndef kTYSmartMatterKitErrorTimeOut 
#define kTYSmartMatterKitErrorTimeOut kThingSmartMatterKitErrorTimeOut 
#endif 

#ifndef kTYSmartMatterKitFetchDPEngineFileFailed 
#define kTYSmartMatterKitFetchDPEngineFileFailed kThingSmartMatterKitFetchDPEngineFileFailed 
#endif 

#ifndef kTYSmartMatterKitDPEngineAddDevice 
#define kTYSmartMatterKitDPEngineAddDevice kThingSmartMatterKitDPEngineAddDevice 
#endif 

#ifndef kTYSmartMatterKitDPEngineControlFailed 
#define kTYSmartMatterKitDPEngineControlFailed kThingSmartMatterKitDPEngineControlFailed 
#endif 

#ifndef kTYSmartMatterKitMatterModelEmpty 
#define kTYSmartMatterKitMatterModelEmpty kThingSmartMatterKitMatterModelEmpty 
#endif 

#ifndef kTYSmartMatterKitErrorReadVendorIdFailed 
#define kTYSmartMatterKitErrorReadVendorIdFailed kThingSmartMatterKitErrorReadVendorIdFailed 
#endif 

#ifndef kTYSmartMatterKitErrorReadProductIDFailed 
#define kTYSmartMatterKitErrorReadProductIDFailed kThingSmartMatterKitErrorReadProductIDFailed 
#endif 

#ifndef kTYSmartMatterKitErrorOpenPairingWindowFailed 
#define kTYSmartMatterKitErrorOpenPairingWindowFailed kThingSmartMatterKitErrorOpenPairingWindowFailed 
#endif 

#ifndef TuyaSmartMatterActivatorDelegate 
#define TuyaSmartMatterActivatorDelegate ThingSmartMatterActivatorDelegate 
#endif 

#ifndef TuyaSmartMatterActivator 
#define TuyaSmartMatterActivator ThingSmartMatterActivator 
#endif 

#ifndef TYSuccessDict 
#define TYSuccessDict ThingSuccessDict 
#endif 

#ifndef TuyaSmartDeviceModel 
#define TuyaSmartDeviceModel ThingSmartDeviceModel 
#endif 

#ifndef TuyaSmartMatterThreadScanResultModel 
#define TuyaSmartMatterThreadScanResultModel ThingSmartMatterThreadScanResultModel 
#endif 

#ifndef TuyaSmartMatterDeviceType 
#define TuyaSmartMatterDeviceType ThingSmartMatterDeviceType 
#endif 

#ifndef TuyaSmartMatterDeviceTypeUnknow 
#define TuyaSmartMatterDeviceTypeUnknow ThingSmartMatterDeviceTypeUnknow 
#endif 

#ifndef TuyaSmartMatterDeviceTypeThread 
#define TuyaSmartMatterDeviceTypeThread ThingSmartMatterDeviceTypeThread 
#endif 

#ifndef TuyaSmartMatterDeviceTypeWIFI 
#define TuyaSmartMatterDeviceTypeWIFI ThingSmartMatterDeviceTypeWIFI 
#endif 

#ifndef TuyaSmartMatterDeviceTypeOnNetwork 
#define TuyaSmartMatterDeviceTypeOnNetwork ThingSmartMatterDeviceTypeOnNetwork 
#endif 

#ifndef TuyaSmartMatterDeviceTypeAP 
#define TuyaSmartMatterDeviceTypeAP ThingSmartMatterDeviceTypeAP 
#endif 

#ifndef WTYBaseDevice 
#define WTYBaseDevice WThingBaseDevice 
#endif 

#ifndef tuyaProductId 
#define tuyaProductId thingProductId 
#endif 

#ifndef TuyaSmartMatterMultipleFabricShare 
#define TuyaSmartMatterMultipleFabricShare ThingSmartMatterMultipleFabricShare 
#endif 

#ifndef TYSuccessInt 
#define TYSuccessInt ThingSuccessInt 
#endif 

#ifndef TYSuccessString 
#define TYSuccessString ThingSuccessString 
#endif 

#ifndef TuyaSmartMatterKit 
#define TuyaSmartMatterKit ThingSmartMatterKit 
#endif 



#endif
