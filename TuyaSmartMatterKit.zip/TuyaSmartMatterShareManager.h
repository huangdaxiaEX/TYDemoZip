//
// TuyaSmartMatterShareManager.h
// TuyaSmartMatterKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartMatterShareManager.

#import "TuyaSmartMatterKitMacro.h"
#import <ThingSmartMatterKit/ThingSmartMatterShareManager.h>
#import <Foundation/Foundation.h>
