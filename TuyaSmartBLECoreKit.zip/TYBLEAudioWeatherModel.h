//
// TYBLEAudioWeatherModel.h
// TuyaSmartBLECoreKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TYBLEAudioWeatherModel.

#import "TuyaSmartBLECoreKitMacro.h"
#import <ThingSmartBLECoreKit/ThingBLEAudioWeatherModel.h>
#import <Foundation/Foundation.h>
