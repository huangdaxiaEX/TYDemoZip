#ifndef TuyaSmartBLECoreKitMacro_h
#define TuyaSmartBLECoreKitMacro_h

#ifndef TuyaSmartBLEConfigNotifyItem 
#define TuyaSmartBLEConfigNotifyItem ThingSmartBLEConfigNotifyItem 
#endif 

#ifndef TYBLEDataManager 
#define TYBLEDataManager ThingBLEDataManager 
#endif 

#ifndef TYSDK_SINGLETON 
#define TYSDK_SINGLETON ThingSDK_SINGLETON 
#endif 

#ifndef TYBLEConfigType 
#define TYBLEConfigType ThingBLEConfigType 
#endif 

#ifndef TYBLEConfigProtocol 
#define TYBLEConfigProtocol ThingBLEConfigProtocol 
#endif 

#ifndef TYBLEDeviceInfoProtocol 
#define TYBLEDeviceInfoProtocol ThingBLEDeviceInfoProtocol 
#endif 

#ifndef TYBLECryptologyProtcol 
#define TYBLECryptologyProtcol ThingBLECryptologyProtcol 
#endif 

#ifndef TYBLEWriteNotifyProtocol 
#define TYBLEWriteNotifyProtocol ThingBLEWriteNotifyProtocol 
#endif 

#ifndef TYBLESubPackageStatus_AllSuccess 
#define TYBLESubPackageStatus_AllSuccess ThingBLESubPackageStatus_AllSuccess 
#endif 

#ifndef TYBLESubPackageStatus_CurrentSuccess 
#define TYBLESubPackageStatus_CurrentSuccess ThingBLESubPackageStatus_CurrentSuccess 
#endif 

#ifndef TYBLESubPackageStatus_CurrentFailure 
#define TYBLESubPackageStatus_CurrentFailure ThingBLESubPackageStatus_CurrentFailure 
#endif 

#ifndef TYBLESubPackageStatus_Failure 
#define TYBLESubPackageStatus_Failure ThingBLESubPackageStatus_Failure 
#endif 

#ifndef TYBLESubPackageStatus 
#define TYBLESubPackageStatus ThingBLESubPackageStatus 
#endif 

#ifndef TYSuccessData 
#define TYSuccessData ThingSuccessData 
#endif 

#ifndef TYFailureError 
#define TYFailureError ThingFailureError 
#endif 

#ifndef TYSuccessHandler 
#define TYSuccessHandler ThingSuccessHandler 
#endif 

#ifndef TuyaSmartBLEOTAType 
#define TuyaSmartBLEOTAType ThingSmartBLEOTAType 
#endif 

#ifndef TYSDKSubValue 
#define TYSDKSubValue ThingSDKSubValue 
#endif 

#ifndef tysdk_subdataWithRange 
#define tysdk_subdataWithRange thingsdk_subdataWithRange 
#endif 

#ifndef tysdk_substringFromIndex 
#define tysdk_substringFromIndex thingsdk_substringFromIndex 
#endif 

#ifndef tysdk_substringToIndex 
#define tysdk_substringToIndex thingsdk_substringToIndex 
#endif 

#ifndef tysdk_substringWithRange 
#define tysdk_substringWithRange thingsdk_substringWithRange 
#endif 

#ifndef TYBLERequest 
#define TYBLERequest ThingBLERequest 
#endif 

#ifndef TYBLEWriteService 
#define TYBLEWriteService ThingBLEWriteService 
#endif 

#ifndef TuyaSmartBLECapabilityOTAControlled 
#define TuyaSmartBLECapabilityOTAControlled ThingSmartBLECapabilityOTAControlled 
#endif 

#ifndef TuyaSmartBLECapabilityLELogitify 
#define TuyaSmartBLECapabilityLELogitify ThingSmartBLECapabilityLELogitify 
#endif 

#ifndef TuyaSmartBLECapabilityBeaconable 
#define TuyaSmartBLECapabilityBeaconable ThingSmartBLECapabilityBeaconable 
#endif 

#ifndef TuyaSmartBLECapabilityLink 
#define TuyaSmartBLECapabilityLink ThingSmartBLECapabilityLink 
#endif 

#ifndef TuyaSmartBLECapabilityExtenModule 
#define TuyaSmartBLECapabilityExtenModule ThingSmartBLECapabilityExtenModule 
#endif 

#ifndef TuyaSmartBLECapability 
#define TuyaSmartBLECapability ThingSmartBLECapability 
#endif 

#ifndef TYBLEScanType 
#define TYBLEScanType ThingBLEScanType 
#endif 

#ifndef TYBLEScanTypeNoraml 
#define TYBLEScanTypeNoraml ThingBLEScanTypeNoraml 
#endif 

#ifndef TYBLEScanTypeQRCode 
#define TYBLEScanTypeQRCode ThingBLEScanTypeQRCode 
#endif 

#ifndef TYBLEBigDataProgressBlock 
#define TYBLEBigDataProgressBlock ThingBLEBigDataProgressBlock 
#endif 

#ifndef TuyaSmartBLEManager 
#define TuyaSmartBLEManager ThingSmartBLEManager 
#endif 

#ifndef TYBLEWeatherModel 
#define TYBLEWeatherModel ThingBLEWeatherModel 
#endif 

#ifndef TuyaSmartDeviceModel 
#define TuyaSmartDeviceModel ThingSmartDeviceModel 
#endif 

#ifndef TuyaSmartBLEManagerDelegate 
#define TuyaSmartBLEManagerDelegate ThingSmartBLEManagerDelegate 
#endif 

#ifndef TuyaSmartBLELocalDataDelegate 
#define TuyaSmartBLELocalDataDelegate ThingSmartBLELocalDataDelegate 
#endif 

#ifndef TuyaSmartBLEAlexaAudioDelegate 
#define TuyaSmartBLEAlexaAudioDelegate ThingSmartBLEAlexaAudioDelegate 
#endif 

#ifndef TYAudioErrorCode 
#define TYAudioErrorCode ThingAudioErrorCode 
#endif 

#ifndef TYAudioAudioFormat 
#define TYAudioAudioFormat ThingAudioAudioFormat 
#endif 

#ifndef TYBLEScanHandler 
#define TYBLEScanHandler ThingBLEScanHandler 
#endif 

#ifndef TYFailureHandler 
#define TYFailureHandler ThingFailureHandler 
#endif 

#ifndef TYSuccessBOOL 
#define TYSuccessBOOL ThingSuccessBOOL 
#endif 

#ifndef TYBLEStatusHandler 
#define TYBLEStatusHandler ThingBLEStatusHandler 
#endif 

#ifndef TYBLEDevInfo 
#define TYBLEDevInfo ThingBLEDevInfo 
#endif 

#ifndef TYBLESecurityDevInfo 
#define TYBLESecurityDevInfo ThingBLESecurityDevInfo 
#endif 

#ifndef TYBLEPlugPlayDevInfo 
#define TYBLEPlugPlayDevInfo ThingBLEPlugPlayDevInfo 
#endif 

#ifndef TYBLEWriteNotify 
#define TYBLEWriteNotify ThingBLEWriteNotify 
#endif 

#ifndef TYBLEWriteNotifyDelegate 
#define TYBLEWriteNotifyDelegate ThingBLEWriteNotifyDelegate 
#endif 

#ifndef TYBLECMDToken 
#define TYBLECMDToken ThingBLECMDToken 
#endif 

#ifndef TuyaSmartBLEActiveDelegate 
#define TuyaSmartBLEActiveDelegate ThingSmartBLEActiveDelegate 
#endif 

#ifndef TuyaSmartBLEEncKeyType 
#define TuyaSmartBLEEncKeyType ThingSmartBLEEncKeyType 
#endif 

#ifndef TuyaSmartBLEEncKeyTypeActive 
#define TuyaSmartBLEEncKeyTypeActive ThingSmartBLEEncKeyTypeActive 
#endif 

#ifndef TuyaSmartBLEEncKeyTypeRemove 
#define TuyaSmartBLEEncKeyTypeRemove ThingSmartBLEEncKeyTypeRemove 
#endif 

#ifndef TYSuccessDict 
#define TYSuccessDict ThingSuccessDict 
#endif 

#ifndef TYSuccessID 
#define TYSuccessID ThingSuccessID 
#endif 

#ifndef TYBLEGCDTimer 
#define TYBLEGCDTimer ThingBLEGCDTimer 
#endif 

#ifndef TYBLEConfigType_QRY_DEV_INFO 
#define TYBLEConfigType_QRY_DEV_INFO ThingBLEConfigType_QRY_DEV_INFO 
#endif 

#ifndef TYBLEConfigType_PAIR 
#define TYBLEConfigType_PAIR ThingBLEConfigType_PAIR 
#endif 

#ifndef TYBLEConfigType_CMD 
#define TYBLEConfigType_CMD ThingBLEConfigType_CMD 
#endif 

#ifndef TYBLEConfigType_STAT 
#define TYBLEConfigType_STAT ThingBLEConfigType_STAT 
#endif 

#ifndef TYBLEConfigType_SET_PWD 
#define TYBLEConfigType_SET_PWD ThingBLEConfigType_SET_PWD 
#endif 

#ifndef TYBLEConfigType_UNPAIR 
#define TYBLEConfigType_UNPAIR ThingBLEConfigType_UNPAIR 
#endif 

#ifndef TYBLEConfigType_RESET 
#define TYBLEConfigType_RESET ThingBLEConfigType_RESET 
#endif 

#ifndef TYBLEConfigType_OTA_START 
#define TYBLEConfigType_OTA_START ThingBLEConfigType_OTA_START 
#endif 

#ifndef TYBLEConfigType_OTA_INFO 
#define TYBLEConfigType_OTA_INFO ThingBLEConfigType_OTA_INFO 
#endif 

#ifndef TYBLEConfigType_OTA_INFO_AES 
#define TYBLEConfigType_OTA_INFO_AES ThingBLEConfigType_OTA_INFO_AES 
#endif 

#ifndef TYBLEConfigType_OTA_INFO_ASY 
#define TYBLEConfigType_OTA_INFO_ASY ThingBLEConfigType_OTA_INFO_ASY 
#endif 

#ifndef TYBLEConfigType_OTA_OFFSET 
#define TYBLEConfigType_OTA_OFFSET ThingBLEConfigType_OTA_OFFSET 
#endif 

#ifndef TYBLEConfigType_OTA_DATA 
#define TYBLEConfigType_OTA_DATA ThingBLEConfigType_OTA_DATA 
#endif 

#ifndef TYBLEConfigType_OTA_END 
#define TYBLEConfigType_OTA_END ThingBLEConfigType_OTA_END 
#endif 

#ifndef TYBLEConfigType_TEST 
#define TYBLEConfigType_TEST ThingBLEConfigType_TEST 
#endif 

#ifndef TYBLEConfigType_FORCE_UNPAIR 
#define TYBLEConfigType_FORCE_UNPAIR ThingBLEConfigType_FORCE_UNPAIR 
#endif 

#ifndef TYBLEConfigType_CERT_ONE 
#define TYBLEConfigType_CERT_ONE ThingBLEConfigType_CERT_ONE 
#endif 

#ifndef TYBLEConfigType_CERT_TWO 
#define TYBLEConfigType_CERT_TWO ThingBLEConfigType_CERT_TWO 
#endif 

#ifndef TYBLEConfigType_CERT_THREE 
#define TYBLEConfigType_CERT_THREE ThingBLEConfigType_CERT_THREE 
#endif 

#ifndef TYBLEConfigType_PP_QUERY_INFO 
#define TYBLEConfigType_PP_QUERY_INFO ThingBLEConfigType_PP_QUERY_INFO 
#endif 

#ifndef TYBLEConfigType_PP_ACTIVE_INFO 
#define TYBLEConfigType_PP_ACTIVE_INFO ThingBLEConfigType_PP_ACTIVE_INFO 
#endif 

#ifndef TYBLEConfigType_PP_NET_INFO 
#define TYBLEConfigType_PP_NET_INFO ThingBLEConfigType_PP_NET_INFO 
#endif 

#ifndef TYBLEConfigType_PRI_DATA_TRANS_INFO 
#define TYBLEConfigType_PRI_DATA_TRANS_INFO ThingBLEConfigType_PRI_DATA_TRANS_INFO 
#endif 

#ifndef TYBLEConfigType_PP_WIFI_STATE_REPORT 
#define TYBLEConfigType_PP_WIFI_STATE_REPORT ThingBLEConfigType_PP_WIFI_STATE_REPORT 
#endif 

#ifndef TYBLEConfigType_NET 
#define TYBLEConfigType_NET ThingBLEConfigType_NET 
#endif 

#ifndef TYBLEConfigType_NET_STATE 
#define TYBLEConfigType_NET_STATE ThingBLEConfigType_NET_STATE 
#endif 

#ifndef TYBLEConfigType_DATA_TRANS 
#define TYBLEConfigType_DATA_TRANS ThingBLEConfigType_DATA_TRANS 
#endif 

#ifndef TYBLEConfigType_DP_SEND_256 
#define TYBLEConfigType_DP_SEND_256 ThingBLEConfigType_DP_SEND_256 
#endif 

#ifndef TYBLEConfigType_ZIGBEE_GATEWAY_INFO 
#define TYBLEConfigType_ZIGBEE_GATEWAY_INFO ThingBLEConfigType_ZIGBEE_GATEWAY_INFO 
#endif 

#ifndef TYBLEConfigType_ZIGBEE_COMMAND 
#define TYBLEConfigType_ZIGBEE_COMMAND ThingBLEConfigType_ZIGBEE_COMMAND 
#endif 

#ifndef TYBLEConfigType_AUDIO_VOICE_CONTROL 
#define TYBLEConfigType_AUDIO_VOICE_CONTROL ThingBLEConfigType_AUDIO_VOICE_CONTROL 
#endif 

#ifndef TYBLEConfigType_AUDIO_VOICE_ACK 
#define TYBLEConfigType_AUDIO_VOICE_ACK ThingBLEConfigType_AUDIO_VOICE_ACK 
#endif 

#ifndef TYBLEConfigType_AUDIO_VOICE_RESULT 
#define TYBLEConfigType_AUDIO_VOICE_RESULT ThingBLEConfigType_AUDIO_VOICE_RESULT 
#endif 

#ifndef TYBLEConfigType_AUDIO_SET_ALARM_CLOCK 
#define TYBLEConfigType_AUDIO_SET_ALARM_CLOCK ThingBLEConfigType_AUDIO_SET_ALARM_CLOCK 
#endif 

#ifndef TYBLEConfigType_AUDIO_GET_TOKEN 
#define TYBLEConfigType_AUDIO_GET_TOKEN ThingBLEConfigType_AUDIO_GET_TOKEN 
#endif 

#ifndef TYBLEConfigType_AUDIO_TOKEN_REPORT 
#define TYBLEConfigType_AUDIO_TOKEN_REPORT ThingBLEConfigType_AUDIO_TOKEN_REPORT 
#endif 

#ifndef TYBLEConfigType_AUDIO_TOKEN_ACK 
#define TYBLEConfigType_AUDIO_TOKEN_ACK ThingBLEConfigType_AUDIO_TOKEN_ACK 
#endif 

#ifndef TYBLEConfigType_AUDIO_COMMON_CMD 
#define TYBLEConfigType_AUDIO_COMMON_CMD ThingBLEConfigType_AUDIO_COMMON_CMD 
#endif 

#ifndef TYBLEConfigType_EXTMODULE_QUERY 
#define TYBLEConfigType_EXTMODULE_QUERY ThingBLEConfigType_EXTMODULE_QUERY 
#endif 

#ifndef TYBLEConfigType_EXTMODULE_ACTIVE 
#define TYBLEConfigType_EXTMODULE_ACTIVE ThingBLEConfigType_EXTMODULE_ACTIVE 
#endif 

#ifndef TYBLEConfigType_EXPAND 
#define TYBLEConfigType_EXPAND ThingBLEConfigType_EXPAND 
#endif 

#ifndef TYBLEConfigType_ALL_DP 
#define TYBLEConfigType_ALL_DP ThingBLEConfigType_ALL_DP 
#endif 

#ifndef TYBLEConfigType_BT_DEV_INFO 
#define TYBLEConfigType_BT_DEV_INFO ThingBLEConfigType_BT_DEV_INFO 
#endif 

#ifndef TYBLEConfigType_SEND_FILE_INFO 
#define TYBLEConfigType_SEND_FILE_INFO ThingBLEConfigType_SEND_FILE_INFO 
#endif 

#ifndef TYBLEConfigType_SEND_FILE_OFFSET 
#define TYBLEConfigType_SEND_FILE_OFFSET ThingBLEConfigType_SEND_FILE_OFFSET 
#endif 

#ifndef TYBLEConfigType_SEND_FILE_DATA 
#define TYBLEConfigType_SEND_FILE_DATA ThingBLEConfigType_SEND_FILE_DATA 
#endif 

#ifndef TYBLEConfigType_SEND_FILE_END 
#define TYBLEConfigType_SEND_FILE_END ThingBLEConfigType_SEND_FILE_END 
#endif 

#ifndef TYBLEConfigType_MCU_STATE 
#define TYBLEConfigType_MCU_STATE ThingBLEConfigType_MCU_STATE 
#endif 

#ifndef TYBLEConfigType_DPTIME 
#define TYBLEConfigType_DPTIME ThingBLEConfigType_DPTIME 
#endif 

#ifndef TYBLEConfigType_MUT_DP 
#define TYBLEConfigType_MUT_DP ThingBLEConfigType_MUT_DP 
#endif 

#ifndef TYBLEConfigType_MUT_DPTIME 
#define TYBLEConfigType_MUT_DPTIME ThingBLEConfigType_MUT_DPTIME 
#endif 

#ifndef TYBLEConfigType_DP_256 
#define TYBLEConfigType_DP_256 ThingBLEConfigType_DP_256 
#endif 

#ifndef TYBLEConfigType_DPTIME_256 
#define TYBLEConfigType_DPTIME_256 ThingBLEConfigType_DPTIME_256 
#endif 

#ifndef TYBLEConfigType_TIMESTAMP1 
#define TYBLEConfigType_TIMESTAMP1 ThingBLEConfigType_TIMESTAMP1 
#endif 

#ifndef TYBLEConfigType_TIMESTAMP2 
#define TYBLEConfigType_TIMESTAMP2 ThingBLEConfigType_TIMESTAMP2 
#endif 

#ifndef TYBLEConfigType_APPTIME 
#define TYBLEConfigType_APPTIME ThingBLEConfigType_APPTIME 
#endif 

#ifndef TYBLEConfigType_SUMMER_TIME 
#define TYBLEConfigType_SUMMER_TIME ThingBLEConfigType_SUMMER_TIME 
#endif 

#ifndef TYBLEConfigType_WEATHER_REQ 
#define TYBLEConfigType_WEATHER_REQ ThingBLEConfigType_WEATHER_REQ 
#endif 

#ifndef TYBLEConfigType_WEATHER_ACK 
#define TYBLEConfigType_WEATHER_ACK ThingBLEConfigType_WEATHER_ACK 
#endif 

#ifndef TYBLEConfigType_WEATHER_LOCATION_REQ 
#define TYBLEConfigType_WEATHER_LOCATION_REQ ThingBLEConfigType_WEATHER_LOCATION_REQ 
#endif 

#ifndef TYBLEConfigType_WEATHER_LOCATION_ACK 
#define TYBLEConfigType_WEATHER_LOCATION_ACK ThingBLEConfigType_WEATHER_LOCATION_ACK 
#endif 

#ifndef TYBLEConfigType_ComboWireless_DownTransport 
#define TYBLEConfigType_ComboWireless_DownTransport ThingBLEConfigType_ComboWireless_DownTransport 
#endif 

#ifndef TYBLEConfigType_ComboWireless_UpTransport 
#define TYBLEConfigType_ComboWireless_UpTransport ThingBLEConfigType_ComboWireless_UpTransport 
#endif 

#ifndef TYBLEConfigType_QRY_IOT_DATA 
#define TYBLEConfigType_QRY_IOT_DATA ThingBLEConfigType_QRY_IOT_DATA 
#endif 

#ifndef TYBLEConfigType_SEND_IOT_DATA 
#define TYBLEConfigType_SEND_IOT_DATA ThingBLEConfigType_SEND_IOT_DATA 
#endif 

#ifndef TYBLEConfigType_SEND_TRANSPARENT_DATA_REQ 
#define TYBLEConfigType_SEND_TRANSPARENT_DATA_REQ ThingBLEConfigType_SEND_TRANSPARENT_DATA_REQ 
#endif 

#ifndef TYBLEConfigType_SEND_TRANSPARENT_DATA_ACK 
#define TYBLEConfigType_SEND_TRANSPARENT_DATA_ACK ThingBLEConfigType_SEND_TRANSPARENT_DATA_ACK 
#endif 

#ifndef TYBLEConfigType_REPORT_LINK_STATUS 
#define TYBLEConfigType_REPORT_LINK_STATUS ThingBLEConfigType_REPORT_LINK_STATUS 
#endif 

#ifndef TYBLEConfigType_BIGDATA_SUMMARY 
#define TYBLEConfigType_BIGDATA_SUMMARY ThingBLEConfigType_BIGDATA_SUMMARY 
#endif 

#ifndef TYBLEConfigType_BIGDATA_BLOCKSUMMARY 
#define TYBLEConfigType_BIGDATA_BLOCKSUMMARY ThingBLEConfigType_BIGDATA_BLOCKSUMMARY 
#endif 

#ifndef TYBLEConfigType_BIGDATA_ACK 
#define TYBLEConfigType_BIGDATA_ACK ThingBLEConfigType_BIGDATA_ACK 
#endif 

#ifndef TYBLEConfigType_BIGDATA_DEL 
#define TYBLEConfigType_BIGDATA_DEL ThingBLEConfigType_BIGDATA_DEL 
#endif 

#ifndef TYBLEConfigType_BIGDATA_SYNC 
#define TYBLEConfigType_BIGDATA_SYNC ThingBLEConfigType_BIGDATA_SYNC 
#endif 

#ifndef TYBLETransSubCmd 
#define TYBLETransSubCmd ThingBLETransSubCmd 
#endif 

#ifndef TYBLETransSubCmd_BT_NET_CFG 
#define TYBLETransSubCmd_BT_NET_CFG ThingBLETransSubCmd_BT_NET_CFG 
#endif 

#ifndef TYBLETransSubCmd_PP_NET_CFG 
#define TYBLETransSubCmd_PP_NET_CFG ThingBLETransSubCmd_PP_NET_CFG 
#endif 

#ifndef TYBLEAudioTextFieldModel 
#define TYBLEAudioTextFieldModel ThingBLEAudioTextFieldModel 
#endif 

#ifndef TYBLEAudioToDoListModel 
#define TYBLEAudioToDoListModel ThingBLEAudioToDoListModel 
#endif 

#ifndef TY_PCM_L16_16KHZ_MONO 
#define TY_PCM_L16_16KHZ_MONO Thing_PCM_L16_16KHZ_MONO 
#endif 

#ifndef TY_OPUS_16KHZ_32KBPS_CBR_0_20MS 
#define TY_OPUS_16KHZ_32KBPS_CBR_0_20MS Thing_OPUS_16KHZ_32KBPS_CBR_0_20MS 
#endif 

#ifndef TY_OPUS_16KHZ_16KBPS_CBR_0_20MS 
#define TY_OPUS_16KHZ_16KBPS_CBR_0_20MS Thing_OPUS_16KHZ_16KBPS_CBR_0_20MS 
#endif 

#ifndef TY_MSBC 
#define TY_MSBC Thing_MSBC 
#endif 

#ifndef TY_Audio_Profile_CLOSE_TALK 
#define TY_Audio_Profile_CLOSE_TALK Thing_Audio_Profile_CLOSE_TALK 
#endif 

#ifndef TY_Audio_Profile_NEAR_FIELD 
#define TY_Audio_Profile_NEAR_FIELD Thing_Audio_Profile_NEAR_FIELD 
#endif 

#ifndef TY_Audio_Profile_FAR_FIELD 
#define TY_Audio_Profile_FAR_FIELD Thing_Audio_Profile_FAR_FIELD 
#endif 

#ifndef TYAudioAudioProfile 
#define TYAudioAudioProfile ThingAudioAudioProfile 
#endif 

#ifndef TuyaSmartAvsStateIdle 
#define TuyaSmartAvsStateIdle ThingSmartAvsStateIdle 
#endif 

#ifndef TuyaSmartAvsStateListening 
#define TuyaSmartAvsStateListening ThingSmartAvsStateListening 
#endif 

#ifndef TuyaSmartAvsStateProcessing 
#define TuyaSmartAvsStateProcessing ThingSmartAvsStateProcessing 
#endif 

#ifndef TuyaSmartAvsStateSpeaking 
#define TuyaSmartAvsStateSpeaking ThingSmartAvsStateSpeaking 
#endif 

#ifndef TuyaSmartAudioState 
#define TuyaSmartAudioState ThingSmartAudioState 
#endif 

#ifndef TYAudioErrorCode_Success 
#define TYAudioErrorCode_Success ThingAudioErrorCode_Success 
#endif 

#ifndef TYAudioErrorCode_Unknow 
#define TYAudioErrorCode_Unknow ThingAudioErrorCode_Unknow 
#endif 

#ifndef TYAudioErrorCode_Internal 
#define TYAudioErrorCode_Internal ThingAudioErrorCode_Internal 
#endif 

#ifndef TYAudioErrorCode_Unsupported 
#define TYAudioErrorCode_Unsupported ThingAudioErrorCode_Unsupported 
#endif 

#ifndef TYAudioErrorCode_UserCancelled 
#define TYAudioErrorCode_UserCancelled ThingAudioErrorCode_UserCancelled 
#endif 

#ifndef TYAudioErrorCode_NotFound 
#define TYAudioErrorCode_NotFound ThingAudioErrorCode_NotFound 
#endif 

#ifndef TYAudioErrorCode_Invalid 
#define TYAudioErrorCode_Invalid ThingAudioErrorCode_Invalid 
#endif 

#ifndef TYAudioErrorCode_Busy 
#define TYAudioErrorCode_Busy ThingAudioErrorCode_Busy 
#endif 

#ifndef TYAudioResultType_Voice 
#define TYAudioResultType_Voice ThingAudioResultType_Voice 
#endif 

#ifndef TYAudioResultType_Weather 
#define TYAudioResultType_Weather ThingAudioResultType_Weather 
#endif 

#ifndef TYAudioResultType_List 
#define TYAudioResultType_List ThingAudioResultType_List 
#endif 

#ifndef TYAudioResultType_Other 
#define TYAudioResultType_Other ThingAudioResultType_Other 
#endif 

#ifndef TYAudioResultType 
#define TYAudioResultType ThingAudioResultType 
#endif 

#ifndef TuyaSmartAvsCmdStartSpeech 
#define TuyaSmartAvsCmdStartSpeech ThingSmartAvsCmdStartSpeech 
#endif 

#ifndef TuyaSmartAvsCmdProvideSpeech 
#define TuyaSmartAvsCmdProvideSpeech ThingSmartAvsCmdProvideSpeech 
#endif 

#ifndef TuyaSmartAvsCmdEndpointSpeech 
#define TuyaSmartAvsCmdEndpointSpeech ThingSmartAvsCmdEndpointSpeech 
#endif 

#ifndef TuyaSmartAvsCmdStopSpeech 
#define TuyaSmartAvsCmdStopSpeech ThingSmartAvsCmdStopSpeech 
#endif 

#ifndef TuyaSmartAvsCmdNotifySpeech 
#define TuyaSmartAvsCmdNotifySpeech ThingSmartAvsCmdNotifySpeech 
#endif 

#ifndef TuyaSmartAvsCmdStopSpeech_IsAck 
#define TuyaSmartAvsCmdStopSpeech_IsAck ThingSmartAvsCmdStopSpeech_IsAck 
#endif 

#ifndef TuyaSmartAudioCMD 
#define TuyaSmartAudioCMD ThingSmartAudioCMD 
#endif 

#ifndef TYAudioCommonCmd_ClearToken 
#define TYAudioCommonCmd_ClearToken ThingAudioCommonCmd_ClearToken 
#endif 

#ifndef TYAudioCommonCmd_NotificationStatus 
#define TYAudioCommonCmd_NotificationStatus ThingAudioCommonCmd_NotificationStatus 
#endif 

#ifndef TYAudioCommonCmd 
#define TYAudioCommonCmd ThingAudioCommonCmd 
#endif 

#ifndef TuyaSmartBLEAudioStartModel 
#define TuyaSmartBLEAudioStartModel ThingSmartBLEAudioStartModel 
#endif 

#ifndef TuyaSmartBLEAudioProvideModel 
#define TuyaSmartBLEAudioProvideModel ThingSmartBLEAudioProvideModel 
#endif 

#ifndef TYAudioTokenType_MD5Token 
#define TYAudioTokenType_MD5Token ThingAudioTokenType_MD5Token 
#endif 

#ifndef TYAudioTokenType_MD5Tken_And_Token 
#define TYAudioTokenType_MD5Tken_And_Token ThingAudioTokenType_MD5Tken_And_Token 
#endif 

#ifndef TYAudioTokenType 
#define TYAudioTokenType ThingAudioTokenType 
#endif 

#ifndef TYBLEAudioVoiceTokenModel 
#define TYBLEAudioVoiceTokenModel ThingBLEAudioVoiceTokenModel 
#endif 

#ifndef TYBLEActiveProtocol 
#define TYBLEActiveProtocol ThingBLEActiveProtocol 
#endif 

#ifndef TYBLEAdvModel 
#define TYBLEAdvModel ThingBLEAdvModel 
#endif 

#ifndef TYBLEActiveDelegate 
#define TYBLEActiveDelegate ThingBLEActiveDelegate 
#endif 

#ifndef TuyaSmartBLECoreKit 
#define TuyaSmartBLECoreKit ThingSmartBLECoreKit 
#endif 

#ifndef TYBLEWifiConfigModel 
#define TYBLEWifiConfigModel ThingBLEWifiConfigModel 
#endif 

#ifndef TYBLETransportRequest 
#define TYBLETransportRequest ThingBLETransportRequest 
#endif 

#ifndef TYBLEConfigStateModel 
#define TYBLEConfigStateModel ThingBLEConfigStateModel 
#endif 

#ifndef TYBLEWifiModel 
#define TYBLEWifiModel ThingBLEWifiModel 
#endif 

#ifndef TYBLEAudioDailyDayModel 
#define TYBLEAudioDailyDayModel ThingBLEAudioDailyDayModel 
#endif 

#ifndef TYBLEAudioWeatherModel 
#define TYBLEAudioWeatherModel ThingBLEAudioWeatherModel 
#endif 

#ifndef TuyaSmartBLEMutliTsfDefine 
#define TuyaSmartBLEMutliTsfDefine ThingSmartBLEMutliTsfDefine 
#endif 

#ifndef TYBLEAudioAuthorizationTokenModel 
#define TYBLEAudioAuthorizationTokenModel ThingBLEAudioAuthorizationTokenModel 
#endif 

#ifndef TYBLEAudioAlarmClockModel 
#define TYBLEAudioAlarmClockModel ThingBLEAudioAlarmClockModel 
#endif 

#ifndef TYBLESupportConnect 
#define TYBLESupportConnect ThingBLESupportConnect 
#endif 

#ifndef TYBLESupportConnect_DEFAULT 
#define TYBLESupportConnect_DEFAULT ThingBLESupportConnect_DEFAULT 
#endif 

#ifndef TYBLESupportConnect_REQUEST 
#define TYBLESupportConnect_REQUEST ThingBLESupportConnect_REQUEST 
#endif 

#ifndef TYBLESupportConnect_KEEP 
#define TYBLESupportConnect_KEEP ThingBLESupportConnect_KEEP 
#endif 

#ifndef TYBLESupportConnect_NONEED 
#define TYBLESupportConnect_NONEED ThingBLESupportConnect_NONEED 
#endif 

#ifndef TYBLESupportDisconnect 
#define TYBLESupportDisconnect ThingBLESupportDisconnect 
#endif 

#ifndef TYBLESupportDisconnect_INTIME 
#define TYBLESupportDisconnect_INTIME ThingBLESupportDisconnect_INTIME 
#endif 

#ifndef TYBLESupportDisconnect_REQUEST 
#define TYBLESupportDisconnect_REQUEST ThingBLESupportDisconnect_REQUEST 
#endif 

#ifndef TYBLESupportDisconnect_DEFAULT 
#define TYBLESupportDisconnect_DEFAULT ThingBLESupportDisconnect_DEFAULT 
#endif 

#ifndef TYBLESupportDisconnect_INTIME_REQUEST 
#define TYBLESupportDisconnect_INTIME_REQUEST ThingBLESupportDisconnect_INTIME_REQUEST 
#endif 

#ifndef TYBLEGeneralHelper 
#define TYBLEGeneralHelper ThingBLEGeneralHelper 
#endif 

#ifndef TuyaSmartBLECoreEnums 
#define TuyaSmartBLECoreEnums ThingSmartBLECoreEnums 
#endif 

#ifndef TuyaSmartBLEOTATypeFirmware 
#define TuyaSmartBLEOTATypeFirmware ThingSmartBLEOTATypeFirmware 
#endif 

#ifndef TuyaSmartBLEOTATypeMCU 
#define TuyaSmartBLEOTATypeMCU ThingSmartBLEOTATypeMCU 
#endif 

#ifndef TYBLEFindMacDelegate 
#define TYBLEFindMacDelegate ThingBLEFindMacDelegate 
#endif 

#ifndef TYSmartBLETypeUnknow 
#define TYSmartBLETypeUnknow ThingSmartBLETypeUnknow 
#endif 

#ifndef TYSmartBLETypeBLE 
#define TYSmartBLETypeBLE ThingSmartBLETypeBLE 
#endif 

#ifndef TYSmartBLETypeBLEPlus 
#define TYSmartBLETypeBLEPlus ThingSmartBLETypeBLEPlus 
#endif 

#ifndef TYSmartBLETypeBLEWifi 
#define TYSmartBLETypeBLEWifi ThingSmartBLETypeBLEWifi 
#endif 

#ifndef TYSmartBLETypeBLESecurity 
#define TYSmartBLETypeBLESecurity ThingSmartBLETypeBLESecurity 
#endif 

#ifndef TYSmartBLETypeBLEWifiSecurity 
#define TYSmartBLETypeBLEWifiSecurity ThingSmartBLETypeBLEWifiSecurity 
#endif 

#ifndef TYSmartBLETypeBLEWifiPlugPlay 
#define TYSmartBLETypeBLEWifiPlugPlay ThingSmartBLETypeBLEWifiPlugPlay 
#endif 

#ifndef TYSmartBLETypeBLEZigbee 
#define TYSmartBLETypeBLEZigbee ThingSmartBLETypeBLEZigbee 
#endif 

#ifndef TYSmartBLETypeBLELTESecurity 
#define TYSmartBLETypeBLELTESecurity ThingSmartBLETypeBLELTESecurity 
#endif 

#ifndef TYSmartBLETypeBLEBeacon 
#define TYSmartBLETypeBLEBeacon ThingSmartBLETypeBLEBeacon 
#endif 

#ifndef TYSmartBLETypeBLEWifiPriorBLE 
#define TYSmartBLETypeBLEWifiPriorBLE ThingSmartBLETypeBLEWifiPriorBLE 
#endif 

#ifndef TYSmartBLEType 
#define TYSmartBLEType ThingSmartBLEType 
#endif 

#ifndef TYBLEWriteNotifyService 
#define TYBLEWriteNotifyService ThingBLEWriteNotifyService 
#endif 

#ifndef TYBLEStatusService 
#define TYBLEStatusService ThingBLEStatusService 
#endif 

#ifndef TYSmartBLEDeviceState 
#define TYSmartBLEDeviceState ThingSmartBLEDeviceState 
#endif 

#ifndef TYCRC32 
#define TYCRC32 ThingCRC32 
#endif 

#ifndef TYBLEScan 
#define TYBLEScan ThingBLEScan 
#endif 

#ifndef TYBLEAgent 
#define TYBLEAgent ThingBLEAgent 
#endif 

#ifndef TuyaSmartBLEDeviceProtocol 
#define TuyaSmartBLEDeviceProtocol ThingSmartBLEDeviceProtocol 
#endif 

#ifndef TuyaSmartBLEScanProtocol 
#define TuyaSmartBLEScanProtocol ThingSmartBLEScanProtocol 
#endif 

#ifndef TYBLEScanResultHandher 
#define TYBLEScanResultHandher ThingBLEScanResultHandher 
#endif 

#ifndef TuyaSmartBLEActiveProtocol 
#define TuyaSmartBLEActiveProtocol ThingSmartBLEActiveProtocol 
#endif 

#ifndef TuyaSmartBLEConfigProtocol 
#define TuyaSmartBLEConfigProtocol ThingSmartBLEConfigProtocol 
#endif 

#ifndef TYSuccessString 
#define TYSuccessString ThingSuccessString 
#endif 

#ifndef TYBLEScanDelegate 
#define TYBLEScanDelegate ThingBLEScanDelegate 
#endif 

#ifndef TYBLEErrorDomain 
#define TYBLEErrorDomain ThingBLEErrorDomain 
#endif 

#ifndef TYBLEError 
#define TYBLEError ThingBLEError 
#endif 

#ifndef TYBLEErrorConnectFail 
#define TYBLEErrorConnectFail ThingBLEErrorConnectFail 
#endif 

#ifndef TYBLEErrorConnectPerailTimeOut 
#define TYBLEErrorConnectPerailTimeOut ThingBLEErrorConnectPerailTimeOut 
#endif 

#ifndef TYBLEErrorDiscoverServiceFail 
#define TYBLEErrorDiscoverServiceFail ThingBLEErrorDiscoverServiceFail 
#endif 

#ifndef TYBLEErrorDiscoverCharacterFail 
#define TYBLEErrorDiscoverCharacterFail ThingBLEErrorDiscoverCharacterFail 
#endif 

#ifndef TYBLEErrorNotifyCharacterFail 
#define TYBLEErrorNotifyCharacterFail ThingBLEErrorNotifyCharacterFail 
#endif 

#ifndef TYBLEErrorQueryDevInfoFail 
#define TYBLEErrorQueryDevInfoFail ThingBLEErrorQueryDevInfoFail 
#endif 

#ifndef TYBLEErrorQueryDevInfoTimeOut 
#define TYBLEErrorQueryDevInfoTimeOut ThingBLEErrorQueryDevInfoTimeOut 
#endif 

#ifndef TYBLEErrorPairFail 
#define TYBLEErrorPairFail ThingBLEErrorPairFail 
#endif 

#ifndef TYBLEErrorPairTimeOut 
#define TYBLEErrorPairTimeOut ThingBLEErrorPairTimeOut 
#endif 

#ifndef TYBLEErrorConnectTimeOut 
#define TYBLEErrorConnectTimeOut ThingBLEErrorConnectTimeOut 
#endif 

#ifndef TYBLEErrorDeviceNotExist 
#define TYBLEErrorDeviceNotExist ThingBLEErrorDeviceNotExist 
#endif 

#ifndef TYBLEErrorDeviceInfoNotExist 
#define TYBLEErrorDeviceInfoNotExist ThingBLEErrorDeviceInfoNotExist 
#endif 

#ifndef TYBLEErrorNotPowerOn 
#define TYBLEErrorNotPowerOn ThingBLEErrorNotPowerOn 
#endif 

#ifndef TYBLEErrorCapabilityDisabled 
#define TYBLEErrorCapabilityDisabled ThingBLEErrorCapabilityDisabled 
#endif 

#ifndef TYBLEErrorScanTimeOut 
#define TYBLEErrorScanTimeOut ThingBLEErrorScanTimeOut 
#endif 

#ifndef TYBLEErrorDeviceIsNotActive 
#define TYBLEErrorDeviceIsNotActive ThingBLEErrorDeviceIsNotActive 
#endif 

#ifndef TYBLEErrorUnableConnectDuringOTA 
#define TYBLEErrorUnableConnectDuringOTA ThingBLEErrorUnableConnectDuringOTA 
#endif 

#ifndef TYBLEErrorParamInvalid 
#define TYBLEErrorParamInvalid ThingBLEErrorParamInvalid 
#endif 

#ifndef TUYA_BLE_CONFIG_CANCEL 
#define TUYA_BLE_CONFIG_CANCEL THING_BLE_CONFIG_CANCEL 
#endif 

#ifndef TUYA_BLE_CONNECT_FAILURE 
#define TUYA_BLE_CONNECT_FAILURE THING_BLE_CONNECT_FAILURE 
#endif 

#ifndef TUYA_BLE_FIND_SERVICE_FAILURE 
#define TUYA_BLE_FIND_SERVICE_FAILURE THING_BLE_FIND_SERVICE_FAILURE 
#endif 

#ifndef TUYA_BLE_CHARACTER_FAILURE 
#define TUYA_BLE_CHARACTER_FAILURE THING_BLE_CHARACTER_FAILURE 
#endif 

#ifndef TUYA_BLE_QRY_DEV_INFO_FAILURE 
#define TUYA_BLE_QRY_DEV_INFO_FAILURE THING_BLE_QRY_DEV_INFO_FAILURE 
#endif 

#ifndef TUYA_BLE_PAIR_FAILURE 
#define TUYA_BLE_PAIR_FAILURE THING_BLE_PAIR_FAILURE 
#endif 

#ifndef TUYA_BLE_TIMEOUT 
#define TUYA_BLE_TIMEOUT THING_BLE_TIMEOUT 
#endif 

#ifndef TUYA_BLE_CONFIG_INFO_FAILURE 
#define TUYA_BLE_CONFIG_INFO_FAILURE THING_BLE_CONFIG_INFO_FAILURE 
#endif 

#ifndef TUYA_BLE_TOKEN_INVALID 
#define TUYA_BLE_TOKEN_INVALID THING_BLE_TOKEN_INVALID 
#endif 

#ifndef TUYA_BLE_GET_KEY_FAILURE 
#define TUYA_BLE_GET_KEY_FAILURE THING_BLE_GET_KEY_FAILURE 
#endif 

#ifndef TUYA_BLE_DEVICE_NOT_EXIST 
#define TUYA_BLE_DEVICE_NOT_EXIST THING_BLE_DEVICE_NOT_EXIST 
#endif 

#ifndef TUYA_BLE_REGISTER_FAILURE 
#define TUYA_BLE_REGISTER_FAILURE THING_BLE_REGISTER_FAILURE 
#endif 

#ifndef TUYA_BLE_ACTIVE_FAILTURE 
#define TUYA_BLE_ACTIVE_FAILTURE THING_BLE_ACTIVE_FAILTURE 
#endif 

#ifndef TUYA_BLE_ALREADY_BIND 
#define TUYA_BLE_ALREADY_BIND THING_BLE_ALREADY_BIND 
#endif 

#ifndef TUYA_BLE_CHECK_FAILURE 
#define TUYA_BLE_CHECK_FAILURE THING_BLE_CHECK_FAILURE 
#endif 

#ifndef TUYA_BLE_SYNC_DEVICE_FAILURE 
#define TUYA_BLE_SYNC_DEVICE_FAILURE THING_BLE_SYNC_DEVICE_FAILURE 
#endif 

#ifndef TUYA_BLE_ALREADY_CONFIG_FAILURE 
#define TUYA_BLE_ALREADY_CONFIG_FAILURE THING_BLE_ALREADY_CONFIG_FAILURE 
#endif 

#ifndef TUYA_BLE_OTA_FAILURE 
#define TUYA_BLE_OTA_FAILURE THING_BLE_OTA_FAILURE 
#endif 

#ifndef TUYA_BLE_OTA_TIMEOUT 
#define TUYA_BLE_OTA_TIMEOUT THING_BLE_OTA_TIMEOUT 
#endif 

#ifndef TUYA_BLE_WIFI_CONFIG_CHECK_FAILURE 
#define TUYA_BLE_WIFI_CONFIG_CHECK_FAILURE THING_BLE_WIFI_CONFIG_CHECK_FAILURE 
#endif 

#ifndef TUYA_BLE_PWD_FAILURE 
#define TUYA_BLE_PWD_FAILURE THING_BLE_PWD_FAILURE 
#endif 

#ifndef TUYA_BLE_FIND_PERP_FAILURE 
#define TUYA_BLE_FIND_PERP_FAILURE THING_BLE_FIND_PERP_FAILURE 
#endif 

#ifndef TUYA_BLE_DEVICEINFO_NOT_EXIST 
#define TUYA_BLE_DEVICEINFO_NOT_EXIST THING_BLE_DEVICEINFO_NOT_EXIST 
#endif 

#ifndef TUYA_BLE_GUEST_NOT_SUPPORT_STRONG_BIND 
#define TUYA_BLE_GUEST_NOT_SUPPORT_STRONG_BIND THING_BLE_GUEST_NOT_SUPPORT_STRONG_BIND 
#endif 

#ifndef TUYA_BLE_COMMON_FAILURE 
#define TUYA_BLE_COMMON_FAILURE THING_BLE_COMMON_FAILURE 
#endif 

#ifndef TUYA_BLE_NOTIFY_OPEN_FAILURE 
#define TUYA_BLE_NOTIFY_OPEN_FAILURE THING_BLE_NOTIFY_OPEN_FAILURE 
#endif 

#ifndef TUYA_BLE_CHIP_DEVICE_FAILURE 
#define TUYA_BLE_CHIP_DEVICE_FAILURE THING_BLE_CHIP_DEVICE_FAILURE 
#endif 

#ifndef TUYA_BLE_CHIP_CLOUD_FAILURE 
#define TUYA_BLE_CHIP_CLOUD_FAILURE THING_BLE_CHIP_CLOUD_FAILURE 
#endif 

#ifndef TUYA_BLE_DUAL_ACTIVAT_PSD_FAILURE 
#define TUYA_BLE_DUAL_ACTIVAT_PSD_FAILURE THING_BLE_DUAL_ACTIVAT_PSD_FAILURE 
#endif 

#ifndef TUYA_BLE_GET_TOKEN_FAILURE 
#define TUYA_BLE_GET_TOKEN_FAILURE THING_BLE_GET_TOKEN_FAILURE 
#endif 

#ifndef TUYA_BLE_PP_PARAM_ERROR 
#define TUYA_BLE_PP_PARAM_ERROR THING_BLE_PP_PARAM_ERROR 
#endif 

#ifndef TUYA_BLE_PP_QUERY_WIFI_INFO_FAILURE 
#define TUYA_BLE_PP_QUERY_WIFI_INFO_FAILURE THING_BLE_PP_QUERY_WIFI_INFO_FAILURE 
#endif 

#ifndef TUYA_BLE_PP_ACTIVE_FAIL 
#define TUYA_BLE_PP_ACTIVE_FAIL THING_BLE_PP_ACTIVE_FAIL 
#endif 

#ifndef TUYA_BLE_PP_SEND_ACTIVE_INFO_FAIL 
#define TUYA_BLE_PP_SEND_ACTIVE_INFO_FAIL THING_BLE_PP_SEND_ACTIVE_INFO_FAIL 
#endif 

#ifndef TUYA_BLE_DEVICE_MQ_ONLINE_FAIL 
#define TUYA_BLE_DEVICE_MQ_ONLINE_FAIL THING_BLE_DEVICE_MQ_ONLINE_FAIL 
#endif 

#ifndef TUYA_BLE_QRY_DEV_INFO_TIMEOUT 
#define TUYA_BLE_QRY_DEV_INFO_TIMEOUT THING_BLE_QRY_DEV_INFO_TIMEOUT 
#endif 

#ifndef TUYA_BLE_PAIR_TIMEOUT 
#define TUYA_BLE_PAIR_TIMEOUT THING_BLE_PAIR_TIMEOUT 
#endif 

#ifndef TUYA_BLE_PP_QUERY_WIFI_INFO_TIMEOUT 
#define TUYA_BLE_PP_QUERY_WIFI_INFO_TIMEOUT THING_BLE_PP_QUERY_WIFI_INFO_TIMEOUT 
#endif 

#ifndef TUYA_BLE_PP_SEND_ACTIVE_INFO_TIMEOUT 
#define TUYA_BLE_PP_SEND_ACTIVE_INFO_TIMEOUT THING_BLE_PP_SEND_ACTIVE_INFO_TIMEOUT 
#endif 

#ifndef TUYA_BLE_SERVER_GET_DEVINFO_FAILURE 
#define TUYA_BLE_SERVER_GET_DEVINFO_FAILURE THING_BLE_SERVER_GET_DEVINFO_FAILURE 
#endif 

#ifndef TUYA_BLE_SERVER_BIND_STATUS_FAILURE 
#define TUYA_BLE_SERVER_BIND_STATUS_FAILURE THING_BLE_SERVER_BIND_STATUS_FAILURE 
#endif 

#ifndef TUYA_BLE_FETCH_SL_API_FAILURE 
#define TUYA_BLE_FETCH_SL_API_FAILURE THING_BLE_FETCH_SL_API_FAILURE 
#endif 

#ifndef TUYA_BLE_CONFIG_INFO_SL_FAILURE 
#define TUYA_BLE_CONFIG_INFO_SL_FAILURE THING_BLE_CONFIG_INFO_SL_FAILURE 
#endif 

#ifndef TUYA_BLE_PP_CONFIG_WIFI_SL_FAILURE 
#define TUYA_BLE_PP_CONFIG_WIFI_SL_FAILURE THING_BLE_PP_CONFIG_WIFI_SL_FAILURE 
#endif 

#ifndef TUYA_BLE_QUERY_WIFILIST_TIMEOUT 
#define TUYA_BLE_QUERY_WIFILIST_TIMEOUT THING_BLE_QUERY_WIFILIST_TIMEOUT 
#endif 

#ifndef TUYA_BLE_DEVICE_NOT_PAIR 
#define TUYA_BLE_DEVICE_NOT_PAIR THING_BLE_DEVICE_NOT_PAIR 
#endif 

#ifndef TUYA_BLE_NOT_SUPPORT_ABILITY 
#define TUYA_BLE_NOT_SUPPORT_ABILITY TUYA_BLE_NOT_SUPPORT_ABILIThing 
#endif 

#ifndef TUYA_BLE_DEVICE_LOG_TIMEOUT 
#define TUYA_BLE_DEVICE_LOG_TIMEOUT THING_BLE_DEVICE_LOG_TIMEOUT 
#endif 

#ifndef TUYA_BLE_DEVICE_CONNECT_ROUTER_TIMEOUT 
#define TUYA_BLE_DEVICE_CONNECT_ROUTER_TIMEOUT THING_BLE_DEVICE_CONNECT_ROUTER_TIMEOUT 
#endif 

#ifndef TUYA_BLE_DEVICE_ACTIVE_TIMEOUT 
#define TUYA_BLE_DEVICE_ACTIVE_TIMEOUT THING_BLE_DEVICE_ACTIVE_TIMEOUT 
#endif 

#ifndef TUYA_BLE_OTA_DEVICE_STATE_FAIL 
#define TUYA_BLE_OTA_DEVICE_STATE_FAIL THING_BLE_OTA_DEVICE_STATE_FAIL 
#endif 

#ifndef TUYA_BLE_OTA_DEVICE_FILE_CHECK_FAIL 
#define TUYA_BLE_OTA_DEVICE_FILE_CHECK_FAIL THING_BLE_OTA_DEVICE_FILE_CHECK_FAIL 
#endif 

#ifndef TUYA_BLE_OTA_OFFSET_INDEX_FAIL 
#define TUYA_BLE_OTA_OFFSET_INDEX_FAIL THING_BLE_OTA_OFFSET_INDEX_FAIL 
#endif 

#ifndef TUYA_BLE_OTA_ACK_FAIL 
#define TUYA_BLE_OTA_ACK_FAIL THING_BLE_OTA_ACK_FAIL 
#endif 

#ifndef TUYA_BLE_OTA_SEND_FAIL 
#define TUYA_BLE_OTA_SEND_FAIL THING_BLE_OTA_SEND_FAIL 
#endif 

#ifndef TUYA_BLE_OTA_RESULT_FAIL 
#define TUYA_BLE_OTA_RESULT_FAIL THING_BLE_OTA_RESULT_FAIL 
#endif 

#ifndef TUYA_BLE_BIGDATA_RESULT_FAIL 
#define TUYA_BLE_BIGDATA_RESULT_FAIL THING_BLE_BIGDATA_RESULT_FAIL 
#endif 

#ifndef TUYA_BLE_PACKAGE_MTP_ERROR 
#define TUYA_BLE_PACKAGE_MTP_ERROR THING_BLE_PACKAGE_MTP_ERROR 
#endif 

#ifndef TUYA_BLE_PP_SEND_DEV_ACTIVE_INFO_ERROR 
#define TUYA_BLE_PP_SEND_DEV_ACTIVE_INFO_ERROR THING_BLE_PP_SEND_DEV_ACTIVE_INFO_ERROR 
#endif 

#ifndef TUYA_BLE_ZIGBEE_GATEWAY_NOT_SUPPORET 
#define TUYA_BLE_ZIGBEE_GATEWAY_NOT_SUPPORET THING_BLE_ZIGBEE_GATEWAY_NOT_SUPPORET 
#endif 

#ifndef TUYA_BLE_RECEIVE_ZIGBEE_INFO_FAIL 
#define TUYA_BLE_RECEIVE_ZIGBEE_INFO_FAIL THING_BLE_RECEIVE_ZIGBEE_INFO_FAIL 
#endif 

#ifndef TUYA_BLE_RECEIVE_ZIGBEE_COMMAND_FAIL 
#define TUYA_BLE_RECEIVE_ZIGBEE_COMMAND_FAIL THING_BLE_RECEIVE_ZIGBEE_COMMAND_FAIL 
#endif 

#ifndef TUYA_BLE_RECEIVE_ZIGBEE_GATEWAY_ERROR 
#define TUYA_BLE_RECEIVE_ZIGBEE_GATEWAY_ERROR THING_BLE_RECEIVE_ZIGBEE_GATEWAY_ERROR 
#endif 

#ifndef TUYA_BLE_RECEIVE_ZIGBEE_GATEWAY_INFO_ERROR 
#define TUYA_BLE_RECEIVE_ZIGBEE_GATEWAY_INFO_ERROR THING_BLE_RECEIVE_ZIGBEE_GATEWAY_INFO_ERROR 
#endif 

#ifndef TUYA_BLE_SEND_ZIGBEE_GATEWAY_INFO_FAIL 
#define TUYA_BLE_SEND_ZIGBEE_GATEWAY_INFO_FAIL THING_BLE_SEND_ZIGBEE_GATEWAY_INFO_FAIL 
#endif 

#ifndef TUYA_BLE_SEND_ZIGBEE_GATEWAY_INFO_ERROR 
#define TUYA_BLE_SEND_ZIGBEE_GATEWAY_INFO_ERROR THING_BLE_SEND_ZIGBEE_GATEWAY_INFO_ERROR 
#endif 

#ifndef TUYA_BLE_PARAM_ERROR 
#define TUYA_BLE_PARAM_ERROR THING_BLE_PARAM_ERROR 
#endif 

#ifndef TUYA_BLE_INSTRUCTION_STATE_OTA_FAIL 
#define TUYA_BLE_INSTRUCTION_STATE_OTA_FAIL THING_BLE_INSTRUCTION_STATE_OTA_FAIL 
#endif 

#ifndef TUYA_BLE_INSTRUCTION_OFFLINE_FAIL 
#define TUYA_BLE_INSTRUCTION_OFFLINE_FAIL THING_BLE_INSTRUCTION_OFFLINE_FAIL 
#endif 

#ifndef TYBLEErrorCode 
#define TYBLEErrorCode ThingBLEErrorCode 
#endif 

#ifndef tysdk_BLEErrorWithErrorCode 
#define tysdk_BLEErrorWithErrorCode thingsdk_BLEErrorWithErrorCode 
#endif 

#ifndef tysdk_BLEDefaultErrorWithErrorCode 
#define tysdk_BLEDefaultErrorWithErrorCode thingsdk_BLEDefaultErrorWithErrorCode 
#endif 

#ifndef TYBLEEncryptTypeNormal 
#define TYBLEEncryptTypeNormal ThingBLEEncryptTypeNormal 
#endif 

#ifndef TYBLEEncryptTypeAdvanced 
#define TYBLEEncryptTypeAdvanced ThingBLEEncryptTypeAdvanced 
#endif 

#ifndef TYBLEEncryptType 
#define TYBLEEncryptType ThingBLEEncryptType 
#endif 

#ifndef TYSmartBLEDeviceStateUnactive 
#define TYSmartBLEDeviceStateUnactive ThingSmartBLEDeviceStateUnactive 
#endif 

#ifndef TYSmartBLEDeviceStateUnstable 
#define TYSmartBLEDeviceStateUnstable ThingSmartBLEDeviceStateUnstable 
#endif 

#ifndef TYSmartBLEDeviceStateActived 
#define TYSmartBLEDeviceStateActived ThingSmartBLEDeviceStateActived 
#endif 

#ifndef TYSmartBLEDeviceStateReconnect 
#define TYSmartBLEDeviceStateReconnect ThingSmartBLEDeviceStateReconnect 
#endif 

#ifndef TYSmartBLEDeviceStateOTA 
#define TYSmartBLEDeviceStateOTA ThingSmartBLEDeviceStateOTA 
#endif 

#ifndef TYSmartBLEDeviceStateOffline 
#define TYSmartBLEDeviceStateOffline ThingSmartBLEDeviceStateOffline 
#endif 

#ifndef TYSmartBLEBusinessTypeDefault 
#define TYSmartBLEBusinessTypeDefault ThingSmartBLEBusinessTypeDefault 
#endif 

#ifndef TYSmartBLEBusinessTypeMulitUser 
#define TYSmartBLEBusinessTypeMulitUser ThingSmartBLEBusinessTypeMulitUser 
#endif 

#ifndef TYSmartBLEBusinessType 
#define TYSmartBLEBusinessType ThingSmartBLEBusinessType 
#endif 

#ifndef TYBLEAdvIDTypeUUID 
#define TYBLEAdvIDTypeUUID ThingBLEAdvIDTypeUUID 
#endif 

#ifndef TYBLEAdvIDTypeMac 
#define TYBLEAdvIDTypeMac ThingBLEAdvIDTypeMac 
#endif 

#ifndef TYBLEAdvIDType 
#define TYBLEAdvIDType ThingBLEAdvIDType 
#endif 

#ifndef TYBLEAdvEncryptAuthkey 
#define TYBLEAdvEncryptAuthkey ThingBLEAdvEncryptAuthkey 
#endif 

#ifndef TYBLEAdvEncryptECC 
#define TYBLEAdvEncryptECC ThingBLEAdvEncryptECC 
#endif 

#ifndef TYBLEAdvEncryptPassthrough 
#define TYBLEAdvEncryptPassthrough ThingBLEAdvEncryptPassthrough 
#endif 

#ifndef TYBLEAdvEncryptCompress 
#define TYBLEAdvEncryptCompress ThingBLEAdvEncryptCompress 
#endif 

#ifndef TYBLEAdvEncryptAdvance 
#define TYBLEAdvEncryptAdvance ThingBLEAdvEncryptAdvance 
#endif 

#ifndef TYBLEAdvEncryptQRCode 
#define TYBLEAdvEncryptQRCode ThingBLEAdvEncryptQRCode 
#endif 

#ifndef TYBLEAdvEncryptAuthkeyWithMac 
#define TYBLEAdvEncryptAuthkeyWithMac ThingBLEAdvEncryptAuthkeyWithMac 
#endif 

#ifndef TYBLEAdvEncryptAdvanceWithMac 
#define TYBLEAdvEncryptAdvanceWithMac ThingBLEAdvEncryptAdvanceWithMac 
#endif 

#ifndef TYBLEAdvEncryptQRCodeWithMac 
#define TYBLEAdvEncryptQRCodeWithMac ThingBLEAdvEncryptQRCodeWithMac 
#endif 

#ifndef TYBLEAdvEncryptMode 
#define TYBLEAdvEncryptMode ThingBLEAdvEncryptMode 
#endif 

#ifndef TYBLEAdvProductId 
#define TYBLEAdvProductId ThingBLEAdvProductId 
#endif 

#ifndef TYBLEAdvProductKey 
#define TYBLEAdvProductKey ThingBLEAdvProductKey 
#endif 

#ifndef TYBLEAdvProductType 
#define TYBLEAdvProductType ThingBLEAdvProductType 
#endif 

#ifndef TYBLEDevInfoInterpreter 
#define TYBLEDevInfoInterpreter ThingBLEDevInfoInterpreter 
#endif 

#ifndef TuyaSmartBLEConfigPackageNotify 
#define TuyaSmartBLEConfigPackageNotify ThingSmartBLEConfigPackageNotify 
#endif 

#ifndef TYBLEUtils 
#define TYBLEUtils ThingBLEUtils 
#endif 

#ifndef TYSuccessTokenModel 
#define TYSuccessTokenModel ThingSuccessTokenModel 
#endif 

#ifndef TuyaSmartBLEAudioManagerDelegate 
#define TuyaSmartBLEAudioManagerDelegate ThingSmartBLEAudioManagerDelegate 
#endif 

#ifndef TuyaSmartBLEAudioManager 
#define TuyaSmartBLEAudioManager ThingSmartBLEAudioManager 
#endif 

#ifndef TY_LOG_EVENT_BLE_CONFIG_START 
#define TY_LOG_EVENT_BLE_CONFIG_START Thing_LOG_EVENT_BLE_CONFIG_START 
#endif 

#ifndef TY_LOG_EVENT_BLE_CONFIG_SUCCESS 
#define TY_LOG_EVENT_BLE_CONFIG_SUCCESS Thing_LOG_EVENT_BLE_CONFIG_SUCCESS 
#endif 

#ifndef TY_LOG_EVENT_BLE_CONFIG_FAILURE 
#define TY_LOG_EVENT_BLE_CONFIG_FAILURE Thing_LOG_EVENT_BLE_CONFIG_FAILURE 
#endif 

#ifndef TY_LOG_EVENT_BLE_CONFIG 
#define TY_LOG_EVENT_BLE_CONFIG Thing_LOG_EVENT_BLE_CONFIG 
#endif 

#ifndef TY_LOG_EVENT_BLE_CONNECT 
#define TY_LOG_EVENT_BLE_CONNECT Thing_LOG_EVENT_BLE_CONNECT 
#endif 

#ifndef TY_LOG_EVENT_BLE_OTA 
#define TY_LOG_EVENT_BLE_OTA Thing_LOG_EVENT_BLE_OTA 
#endif 

#ifndef TY_LOG_EVENT_BLE_PAIR 
#define TY_LOG_EVENT_BLE_PAIR Thing_LOG_EVENT_BLE_PAIR 
#endif 

#ifndef TY_LOG_EVENT_BLE_TRANSPARENT_CHANNEL 
#define TY_LOG_EVENT_BLE_TRANSPARENT_CHANNEL Thing_LOG_EVENT_BLE_TRANSPARENT_CHANNEL 
#endif 

#ifndef TY_LOG_EVENT_BLE_CHANNEL_COMPAT 
#define TY_LOG_EVENT_BLE_CHANNEL_COMPAT Thing_LOG_EVENT_BLE_CHANNEL_COMPAT 
#endif 

#ifndef TY_LOG_TYPE_BLE_CONFIG 
#define TY_LOG_TYPE_BLE_CONFIG Thing_LOG_TYPE_BLE_CONFIG
#endif 

#ifndef TY_LOG_TYPE_BLE_PLUS_CONFIG 
#define TY_LOG_TYPE_BLE_PLUS_CONFIG Thing_LOG_TYPE_BLE_PLUS_CONFIG
#endif 

#ifndef TY_LOG_TYPE_BLE_SECURITY_CONFIG 
#define TY_LOG_TYPE_BLE_SECURITY_CONFIG Thing_LOG_TYPE_BLE_SECURIThing_CONFIG
#endif 

#ifndef TY_LOG_TYPE_BLE_DEVDERT_CONFIG 
#define TY_LOG_TYPE_BLE_DEVDERT_CONFIG Thing_LOG_TYPE_BLE_DEVDERT_CONFIG
#endif 

#ifndef TY_LOG_TYPE_BLE_PLUGPLAY_CONFIG 
#define TY_LOG_TYPE_BLE_PLUGPLAY_CONFIG Thing_LOG_TYPE_BLE_PLUGPLAY_CONFIG
#endif 

#ifndef TY_LOG_TYPE_BLE_PLUGPLAY_WIFI_CONFIG 
#define TY_LOG_TYPE_BLE_PLUGPLAY_WIFI_CONFIG Thing_LOG_TYPE_BLE_PLUGPLAY_WIFI_CONFIG
#endif 

#ifndef TY_LOG_TYPE_BLE_ZIGBEE_CONFIG 
#define TY_LOG_TYPE_BLE_ZIGBEE_CONFIG Thing_LOG_TYPE_BLE_ZIGBEE_CONFIG
#endif 

#ifndef TY_LOG_TYPE_BEACON_CONFIG 
#define TY_LOG_TYPE_BEACON_CONFIG Thing_LOG_TYPE_BEACON_CONFIG
#endif 

#ifndef TY_LOG_TYPE_BLE_CONNECT 
#define TY_LOG_TYPE_BLE_CONNECT Thing_LOG_TYPE_BLE_CONNECT
#endif 

#ifndef TY_LOG_TYPE_BLE_PLUS_CONNECT 
#define TY_LOG_TYPE_BLE_PLUS_CONNECT Thing_LOG_TYPE_BLE_PLUS_CONNECT
#endif 

#ifndef TY_LOG_TYPE_BLE_SECURITY_CONNECT 
#define TY_LOG_TYPE_BLE_SECURITY_CONNECT Thing_LOG_TYPE_BLE_SECURIThing_CONNECT
#endif 

#ifndef TY_LOG_TYPE_BLE_DEVDERT_CONNECT 
#define TY_LOG_TYPE_BLE_DEVDERT_CONNECT Thing_LOG_TYPE_BLE_DEVDERT_CONNECT
#endif 

#ifndef TY_LOG_TYPE_BLE_OTA 
#define TY_LOG_TYPE_BLE_OTA Thing_LOG_TYPE_BLE_OTA
#endif 

#ifndef TY_LOG_TYPE_BLE_PRO_OTA 
#define TY_LOG_TYPE_BLE_PRO_OTA Thing_LOG_TYPE_BLE_PRO_OTA
#endif 

#ifndef TY_LOG_TYPE_BLE_PLUS_OTA 
#define TY_LOG_TYPE_BLE_PLUS_OTA Thing_LOG_TYPE_BLE_PLUS_OTA
#endif 

#ifndef TY_LOG_TYPE_BLE_SECURITY_OTA 
#define TY_LOG_TYPE_BLE_SECURITY_OTA Thing_LOG_TYPE_BLE_SECURIThing_OTA
#endif 

#ifndef TY_LOG_TYPE_BLE_MCU_OTA 
#define TY_LOG_TYPE_BLE_MCU_OTA Thing_LOG_TYPE_BLE_MCU_OTA
#endif 

#ifndef TY_LOG_TYPE_BLE_CHANNEL_OTA 
#define TY_LOG_TYPE_BLE_CHANNEL_OTA Thing_LOG_TYPE_BLE_CHANNEL_OTA
#endif 

#ifndef TY_LOG_TYPE_BLE_SECURITY_OTA_V4 
#define TY_LOG_TYPE_BLE_SECURITY_OTA_V4 Thing_LOG_TYPE_BLE_SECURIThing_OTA_V4
#endif 

#ifndef TY_LOG_TYPE_BLE_MCU_OTA_V4 
#define TY_LOG_TYPE_BLE_MCU_OTA_V4 Thing_LOG_TYPE_BLE_MCU_OTA_V4
#endif 

#ifndef TY_LOG_TYPE_BLE_CHANNEL_OTA_V4 
#define TY_LOG_TYPE_BLE_CHANNEL_OTA_V4 Thing_LOG_TYPE_BLE_CHANNEL_OTA_V4
#endif 

#ifndef TY_BLE_CONFIG_STEP_CHECK 
#define TY_BLE_CONFIG_STEP_CHECK Thing_BLE_CONFIG_STEP_CHECK 
#endif 

#ifndef TY_BLE_CONFIG_STEP_TIMEOUT 
#define TY_BLE_CONFIG_STEP_TIMEOUT Thing_BLE_CONFIG_STEP_TIMEOUT 
#endif 

#ifndef TY_BLE_CONFIG_STEP_CONFIG_CANCEL 
#define TY_BLE_CONFIG_STEP_CONFIG_CANCEL Thing_BLE_CONFIG_STEP_CONFIG_CANCEL 
#endif 

#ifndef TY_BLE_CONFIG_STEP_CONNECT 
#define TY_BLE_CONFIG_STEP_CONNECT Thing_BLE_CONFIG_STEP_CONNECT 
#endif 

#ifndef TY_BLE_CONFIG_STEP_SERVICE 
#define TY_BLE_CONFIG_STEP_SERVICE Thing_BLE_CONFIG_STEP_SERVICE 
#endif 

#ifndef TY_BLE_CONFIG_STEP_CHARACT 
#define TY_BLE_CONFIG_STEP_CHARACT Thing_BLE_CONFIG_STEP_CHARACT 
#endif 

#ifndef TY_BLE_CONFIG_STEP_NOTIFY 
#define TY_BLE_CONFIG_STEP_NOTIFY Thing_BLE_CONFIG_STEP_NOTIFY 
#endif 

#ifndef TY_BLE_CONFIG_STEP_GET_KEY_FAILURE 
#define TY_BLE_CONFIG_STEP_GET_KEY_FAILURE Thing_BLE_CONFIG_STEP_GET_KEY_FAILURE 
#endif 

#ifndef TY_BLE_CONFIG_STEP_GET_DEVINFO 
#define TY_BLE_CONFIG_STEP_GET_DEVINFO Thing_BLE_CONFIG_STEP_GET_DEVINFO 
#endif 

#ifndef TY_BLE_CONFIG_STEP_SET_PWD 
#define TY_BLE_CONFIG_STEP_SET_PWD Thing_BLE_CONFIG_STEP_SET_PWD 
#endif 

#ifndef TY_BLE_CONFIG_STEP_REGISTER_ERROR 
#define TY_BLE_CONFIG_STEP_REGISTER_ERROR Thing_BLE_CONFIG_STEP_REGISTER_ERROR 
#endif 

#ifndef TY_BLE_CONFIG_STEP_PAIR 
#define TY_BLE_CONFIG_STEP_PAIR Thing_BLE_CONFIG_STEP_PAIR 
#endif 

#ifndef TY_BLE_CONFIG_STEP_DEVCERT 
#define TY_BLE_CONFIG_STEP_DEVCERT Thing_BLE_CONFIG_STEP_DEVCERT 
#endif 

#ifndef TY_BLE_CONFIG_STEP_ACTIVE 
#define TY_BLE_CONFIG_STEP_ACTIVE Thing_BLE_CONFIG_STEP_ACTIVE 
#endif 

#ifndef TY_BLE_CONFIG_STEP_ACTIVE_BIND 
#define TY_BLE_CONFIG_STEP_ACTIVE_BIND Thing_BLE_CONFIG_STEP_ACTIVE_BIND 
#endif 

#ifndef TY_BLE_CONFIG_STEP_ACTIVE_GUEST_BIND 
#define TY_BLE_CONFIG_STEP_ACTIVE_GUEST_BIND Thing_BLE_CONFIG_STEP_ACTIVE_GUEST_BIND 
#endif 

#ifndef TUYA_BLE_SERVER_GET_DEVINFO 
#define TUYA_BLE_SERVER_GET_DEVINFO THING_BLE_SERVER_GET_DEVINFO 
#endif 

#ifndef TY_BLE_CONFIG_STEP_PP_CHECK 
#define TY_BLE_CONFIG_STEP_PP_CHECK Thing_BLE_CONFIG_STEP_PP_CHECK 
#endif 

#ifndef TY_BLE_CONFIG_STEP_PP_GET_DEVINFO 
#define TY_BLE_CONFIG_STEP_PP_GET_DEVINFO Thing_BLE_CONFIG_STEP_PP_GET_DEVINFO 
#endif 

#ifndef TY_BLE_CONFIG_STEP_PP_ACTIVE 
#define TY_BLE_CONFIG_STEP_PP_ACTIVE Thing_BLE_CONFIG_STEP_PP_ACTIVE 
#endif 

#ifndef TY_BLE_CONFIG_STEP_PP_ACTIVE_INFO 
#define TY_BLE_CONFIG_STEP_PP_ACTIVE_INFO Thing_BLE_CONFIG_STEP_PP_ACTIVE_INFO 
#endif 

#ifndef TY_BLE_CONFIG_STEP_PP_ENV 
#define TY_BLE_CONFIG_STEP_PP_ENV Thing_BLE_CONFIG_STEP_PP_ENV 
#endif 

#ifndef TY_BLE_CONFIG_STEP_PP_PSK_API 
#define TY_BLE_CONFIG_STEP_PP_PSK_API Thing_BLE_CONFIG_STEP_PP_PSK_API 
#endif 

#ifndef TY_BLE_CONFIG_STEP_PP_SEND_WIFI_INFO 
#define TY_BLE_CONFIG_STEP_PP_SEND_WIFI_INFO Thing_BLE_CONFIG_STEP_PP_SEND_WIFI_INFO 
#endif 

#ifndef TY_BLE_CONFIG_STEP_PP_DEVICE_WIFI_INFO 
#define TY_BLE_CONFIG_STEP_PP_DEVICE_WIFI_INFO Thing_BLE_CONFIG_STEP_PP_DEVICE_WIFI_INFO 
#endif 

#ifndef TY_BLE_CONFIG_STEP_PP_TIMEOUT 
#define TY_BLE_CONFIG_STEP_PP_TIMEOUT Thing_BLE_CONFIG_STEP_PP_TIMEOUT 
#endif 

#ifndef TY_BLE_CONFIG_STEP_ZB_CHECK 
#define TY_BLE_CONFIG_STEP_ZB_CHECK Thing_BLE_CONFIG_STEP_ZB_CHECK 
#endif 

#ifndef TY_BLE_CONFIG_STEP_ZB_GW_NOT_SUPPORT 
#define TY_BLE_CONFIG_STEP_ZB_GW_NOT_SUPPORT Thing_BLE_CONFIG_STEP_ZB_GW_NOT_SUPPORT 
#endif 

#ifndef TY_BLE_CONFIG_STEP_ZB_GET_DEVINFO 
#define TY_BLE_CONFIG_STEP_ZB_GET_DEVINFO Thing_BLE_CONFIG_STEP_ZB_GET_DEVINFO 
#endif 

#ifndef TY_BLE_CONFIG_STEP_ZB_PUBLISH_MAC 
#define TY_BLE_CONFIG_STEP_ZB_PUBLISH_MAC Thing_BLE_CONFIG_STEP_ZB_PUBLISH_MAC 
#endif 

#ifndef TY_BLE_CONFIG_STEP_ZB_GW_ERROR 
#define TY_BLE_CONFIG_STEP_ZB_GW_ERROR Thing_BLE_CONFIG_STEP_ZB_GW_ERROR 
#endif 

#ifndef TY_BLE_CONFIG_STEP_ZB_GW_INFO 
#define TY_BLE_CONFIG_STEP_ZB_GW_INFO Thing_BLE_CONFIG_STEP_ZB_GW_INFO 
#endif 

#ifndef TY_BLE_CONFIG_STEP_ZB_SEND_GW_INFO 
#define TY_BLE_CONFIG_STEP_ZB_SEND_GW_INFO Thing_BLE_CONFIG_STEP_ZB_SEND_GW_INFO 
#endif 

#ifndef TY_BLE_CONFIG_STEP_ZB_DEVICE_GW_INFO 
#define TY_BLE_CONFIG_STEP_ZB_DEVICE_GW_INFO Thing_BLE_CONFIG_STEP_ZB_DEVICE_GW_INFO 
#endif 

#ifndef TY_BLE_CONFIG_STEP_ZB_TIMEOUT 
#define TY_BLE_CONFIG_STEP_ZB_TIMEOUT Thing_BLE_CONFIG_STEP_ZB_TIMEOUT 
#endif 

#ifndef TY_BLE_CONNECT_STEP_CONNECT 
#define TY_BLE_CONNECT_STEP_CONNECT Thing_BLE_CONNECT_STEP_CONNECT 
#endif 

#ifndef TY_BLE_CONNECT_STEP_SERVICE 
#define TY_BLE_CONNECT_STEP_SERVICE Thing_BLE_CONNECT_STEP_SERVICE 
#endif 

#ifndef TY_BLE_CONNECT_STEP_CHARACT 
#define TY_BLE_CONNECT_STEP_CHARACT Thing_BLE_CONNECT_STEP_CHARACT 
#endif 

#ifndef TY_BLE_CONNECT_STEP_NOTIFY 
#define TY_BLE_CONNECT_STEP_NOTIFY Thing_BLE_CONNECT_STEP_NOTIFY 
#endif 

#ifndef TY_BLE_CONNECT_STEP_GET_DEVINFO 
#define TY_BLE_CONNECT_STEP_GET_DEVINFO Thing_BLE_CONNECT_STEP_GET_DEVINFO 
#endif 

#ifndef TY_BLE_CONNECT_STEP_GET_DEVINFO_TIMEOUT 
#define TY_BLE_CONNECT_STEP_GET_DEVINFO_TIMEOUT Thing_BLE_CONNECT_STEP_GET_DEVINFO_TIMEOUT 
#endif 

#ifndef TY_BLE_CONNECT_STEP_PAIR 
#define TY_BLE_CONNECT_STEP_PAIR Thing_BLE_CONNECT_STEP_PAIR 
#endif 

#ifndef TY_BLE_CONNECT_STEP_PAIR_TIMEOUT 
#define TY_BLE_CONNECT_STEP_PAIR_TIMEOUT Thing_BLE_CONNECT_STEP_PAIR_TIMEOUT 
#endif 

#ifndef TY_BLE_CONNECT_STEP_DEVCERT 
#define TY_BLE_CONNECT_STEP_DEVCERT Thing_BLE_CONNECT_STEP_DEVCERT 
#endif 

#ifndef TY_BLE_CONNECT_STEP_TIMEOUT 
#define TY_BLE_CONNECT_STEP_TIMEOUT Thing_BLE_CONNECT_STEP_TIMEOUT 
#endif 

#ifndef TY_BLE_CONNECT_STEP_DEVICE_NOT_EXIST 
#define TY_BLE_CONNECT_STEP_DEVICE_NOT_EXIST Thing_BLE_CONNECT_STEP_DEVICE_NOT_EXIST 
#endif 

#ifndef TY_BLE_COMPAT_TYPE_CONNECT 
#define TY_BLE_COMPAT_TYPE_CONNECT Thing_BLE_COMPAT_TYPE_CONNECT
#endif 

#ifndef TY_BLE_COMPAT_TYPE_QUERYDEVICEINFO 
#define TY_BLE_COMPAT_TYPE_QUERYDEVICEINFO Thing_BLE_COMPAT_TYPE_QUERYDEVICEINFO
#endif 

#ifndef TY_BLE_COMPAT_TYPE_TIMEOUT 
#define TY_BLE_COMPAT_TYPE_TIMEOUT Thing_BLE_COMPAT_TYPE_TIMEOUT
#endif 

#ifndef TY_BLE_COMPAT_ERRORCODE_NULLSERVICE 
#define TY_BLE_COMPAT_ERRORCODE_NULLSERVICE Thing_BLE_COMPAT_ERRORCODE_NULLSERVICE 
#endif 

#ifndef TY_BLE_COMPAT_ERRORCODE_CHARACT 
#define TY_BLE_COMPAT_ERRORCODE_CHARACT Thing_BLE_COMPAT_ERRORCODE_CHARACT 
#endif 

#ifndef TY_BLE_COMPAT_ERRORCODE_NOTIFYCHARACT 
#define TY_BLE_COMPAT_ERRORCODE_NOTIFYCHARACT Thing_BLE_COMPAT_ERRORCODE_NOTIFYCHARACT 
#endif 

#ifndef TY_BLE_COMPAT_ERRORCODE_PAIR_TIMEOUT 
#define TY_BLE_COMPAT_ERRORCODE_PAIR_TIMEOUT Thing_BLE_COMPAT_ERRORCODE_PAIR_TIMEOUT 
#endif 

#ifndef TY_BLE_COMPAT_ERRORCODE_TOTAL_TIMEOUT 
#define TY_BLE_COMPAT_ERRORCODE_TOTAL_TIMEOUT Thing_BLE_COMPAT_ERRORCODE_TOTAL_TIMEOUT 
#endif 

#ifndef TYBLEPairEventService 
#define TYBLEPairEventService ThingBLEPairEventService 
#endif 

#ifndef TYBLELogEventService 
#define TYBLELogEventService ThingBLELogEventService 
#endif 

#ifndef TYBLECompatEventService 
#define TYBLECompatEventService ThingBLECompatEventService 
#endif 

#ifndef TYBLEDeviceCategoryInfo 
#define TYBLEDeviceCategoryInfo ThingBLEDeviceCategoryInfo 
#endif 

#ifndef TYBLEBeaconScanCallback 
#define TYBLEBeaconScanCallback ThingBLEBeaconScanCallback 
#endif 

#ifndef TuyaSmartBLEBeaconScanDelegate 
#define TuyaSmartBLEBeaconScanDelegate ThingSmartBLEBeaconScanDelegate 
#endif 

#ifndef TuyaSmartBLEBeaconScanBridge 
#define TuyaSmartBLEBeaconScanBridge ThingSmartBLEBeaconScanBridge 
#endif 



#endif
