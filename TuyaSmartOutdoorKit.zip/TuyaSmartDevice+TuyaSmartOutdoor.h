//
// TuyaSmartDevice+TuyaSmartOutdoor.h
// TuyaSmartOutdoorKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartDevice+TuyaSmartOutdoor.

#import "TuyaSmartOutdoorKitMacro.h"
#import <ThingSmartDeviceCoreKit/ThingSmartDeviceCoreKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TuyaSmartDevice (TuyaSmartOutdoor)

/// send DP with code
/// @param code DP code
/// @param DPValue the DP original value (NSString, NSNumber, NSDictionary)
/// @param success Called when the task finishes successfully.
/// @param failure Called when the task is interrupted by an error.
- (void)tyod_publishDPWithCode:(NSString *)code
                       DPValue:(id)DPValue
                       success:(nullable TYSuccessHandler)success
                       failure:(nullable TYFailureError)failure;

@end

NS_ASSUME_NONNULL_END
