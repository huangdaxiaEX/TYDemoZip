//
// TuyaSmartDeviceModel+TuyaSmartOutdoor.h
// TuyaSmartOutdoorKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartDeviceModel+TuyaSmartOutdoor.

#import "TuyaSmartOutdoorKitMacro.h"
#import <ThingSmartDeviceCoreKit/ThingSmartDeviceCoreKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TuyaSmartSchemaModel (TuyaSmartOutdoor)
/// DP value (convert from dps)
@property (nonatomic, strong) id tyod_DPValue;

@end


@interface TuyaSmartDeviceModel (TuyaSmartOutdoor)

/// get schema model with code
/// @param code DP code
- (TuyaSmartSchemaModel *)tyod_schemaMWithCode:(NSString *)code;

@end

NS_ASSUME_NONNULL_END
