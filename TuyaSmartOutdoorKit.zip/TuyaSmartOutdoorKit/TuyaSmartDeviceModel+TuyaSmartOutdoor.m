//
//  TuyaSmartDeviceModel+TuyaSmartOutdoor.m
//  TYSmartOutdoor
//
//  Created by Hemin Won on 2021/12/11.
//

#import "TuyaSmartDeviceModel+TuyaSmartOutdoor.h"
#import <objc/runtime.h>
#import <ThingSmartOutdoorKit/ThingSmartDeviceModel+ThingSmartOutdoor.h>

@implementation TuyaSmartSchemaModel (TuyaSmartOutdoor)

- (void)setTyod_DPValue:(id)tyod_DPValue {
    self.tsod_DPValue = tyod_DPValue;
}

- (id)tyod_DPValue {
    id value = self.tsod_DPValue;
    return value;
}

@end


@implementation TuyaSmartDeviceModel (TuyaSmartOutdoor)

- (TuyaSmartSchemaModel *)tyod_schemaMWithCode:(NSString *)code {
    TuyaSmartSchemaModel *schemaModel = [self tsod_schemaMWithCode:code];
    return schemaModel;
}

@end
