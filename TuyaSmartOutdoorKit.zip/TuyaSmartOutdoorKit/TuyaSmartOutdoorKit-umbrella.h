//
// TuyaSmartOutdoorKit-umbrella.h
// TuyaSmartOutdoorKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartOutdoorKit-umbrella.

#import "TuyaSmartOutdoorKitMacro.h"
#import <ThingSmartOutdoorKit/ThingSmartOutdoorKit.h>
#import <UIKit/UIKit.h>
