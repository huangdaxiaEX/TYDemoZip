//
//  TuyaSmartDevice+TuyaSmartOutdoor.m
//  TYSmartOutdoor
//
//  Created by Hemin Won on 2021/12/7.
//

#import "TuyaSmartDevice+TuyaSmartOutdoor.h"
#import <objc/runtime.h>
#import "TuyaSmartOutdoorError.h"
#import "TuyaSmartDeviceModel+TuyaSmartOutdoor.h"
#import <ThingSmartOutdoorKit/ThingSmartDevice+ThingSmartOutdoor.h>

@interface TuyaSmartDevice ()

@end


@implementation TuyaSmartDevice (TuyaSmartOutdoor)

- (void)tyod_publishDPWithCode:(NSString *)code
                       DPValue:(id)DPValue
                       success:(nullable TYSuccessHandler)success
                       failure:(nullable TYFailureError)failure {
    [self tsod_publishDPWithCode:code DPValue:DPValue success:success failure:failure];
}

@end
