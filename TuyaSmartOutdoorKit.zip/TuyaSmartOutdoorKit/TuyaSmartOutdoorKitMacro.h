#ifndef TuyaSmartOutdoorKitMacro_h
#define TuyaSmartOutdoorKitMacro_h

#ifndef TuyaSmartSchemaModel 
#define TuyaSmartSchemaModel ThingSmartSchemaModel 
#endif 

#ifndef TuyaSmartOutdoor 
#define TuyaSmartOutdoor ThingSmartOutdoor 
#endif 

#ifndef TuyaSmartDeviceModel 
#define TuyaSmartDeviceModel ThingSmartDeviceModel 
#endif 

#ifndef TuyaSmartOutdoorKit 
#define TuyaSmartOutdoorKit ThingSmartOutdoorKit 
#endif 

#ifndef TuyaSmartOutdoorProductIconModel 
#define TuyaSmartOutdoorProductIconModel ThingSmartOutdoorProductIconModel 
#endif 

#ifndef TuyaSmartOutdoorDeviceHardwareModel 
#define TuyaSmartOutdoorDeviceHardwareModel ThingSmartOutdoorDeviceHardwareModel 
#endif 

#ifndef TuyaSmartOutdoorDeviceListService 
#define TuyaSmartOutdoorDeviceListService ThingSmartOutdoorDeviceListService 
#endif 

#ifndef TuyaSmartOutdoorKitVersionNumber 
#define TuyaSmartOutdoorKitVersionNumber ThingSmartOutdoorKitVersionNumber 
#endif 

#ifndef TuyaSmartOutdoorErrorCode 
#define TuyaSmartOutdoorErrorCode ThingSmartOutdoorErrorCode 
#endif 

#ifndef TuyaSmartOutdoorErrorDomain 
#define TuyaSmartOutdoorErrorDomain ThingSmartOutdoorErrorDomain 
#endif 

#ifndef TuyaSmartOutdoorError 
#define TuyaSmartOutdoorError ThingSmartOutdoorError 
#endif 

#ifndef TuyaSmartOutdoorStoreModel 
#define TuyaSmartOutdoorStoreModel ThingSmartOutdoorStoreModel 
#endif 

#ifndef TuyaSmartOutdoorStoreRequestModel 
#define TuyaSmartOutdoorStoreRequestModel ThingSmartOutdoorStoreRequestModel 
#endif 

#ifndef TuyaSmartOutdoorStorePageRequestModel 
#define TuyaSmartOutdoorStorePageRequestModel ThingSmartOutdoorStorePageRequestModel 
#endif 

#ifndef TuyaSmartOutdoorStoreService 
#define TuyaSmartOutdoorStoreService ThingSmartOutdoorStoreService 
#endif 

#ifndef TuyaSmartDevice 
#define TuyaSmartDevice ThingSmartDevice 
#endif 

#ifndef TYSuccessHandler 
#define TYSuccessHandler ThingSuccessHandler 
#endif 

#ifndef TYFailureError 
#define TYFailureError ThingFailureError 
#endif 

#ifndef TuyaSmartOutdoorCycleRecordModel 
#define TuyaSmartOutdoorCycleRecordModel ThingSmartOutdoorCycleRecordModel 
#endif 

#ifndef TuyaSmartOutdoorLocationUploadModel 
#define TuyaSmartOutdoorLocationUploadModel ThingSmartOutdoorLocationUploadModel 
#endif 

#ifndef TuyaSmartOutdoorCyclingService 
#define TuyaSmartOutdoorCyclingService ThingSmartOutdoorCyclingService 
#endif

#endif
