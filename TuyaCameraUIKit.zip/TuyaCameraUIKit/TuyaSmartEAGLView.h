//
// TuyaSmartEAGLView.h
// TuyaCameraUIKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartEAGLView.

#import "TuyaCameraUIKitMacro.h"
#import <ThingCameraUIKit/ThingSmartEAGLView.h>
#import <UIKit/UIKit.h>
#import <OpenGLES/ES2/gl.h>
#import <OpenGLES/ES2/glext.h>
#import <TuyaSmartCameraBase/TuyaSmartCameraBase.h>
