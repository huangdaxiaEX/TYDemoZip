//
// TuyaCameraUIKit-umbrella.h
// TuyaCameraUIKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaCameraUIKit-umbrella.

#import "TuyaCameraUIKitMacro.h"
#import <ThingCameraUIKit/ThingCameraUIKit-umbrella.h>#import <UIKit/UIKit.h>
