#ifndef TuyaCameraUIKitMacro_h
#define TuyaCameraUIKitMacro_h

#ifndef TuyaCameraUIKitVersionNumber 
#define TuyaCameraUIKitVersionNumber ThingCameraUIKitVersionNumber 
#endif 

#ifndef TuyaCameraUIKit 
#define TuyaCameraUIKit ThingCameraUIKit 
#endif 

#ifndef TuyaSmartEAGLView 
#define TuyaSmartEAGLView ThingSmartEAGLView 
#endif 

#ifndef tuya_setScaled 
#define tuya_setScaled thing_setScaled 
#endif 

#ifndef tuya_setOffset 
#define tuya_setOffset thing_setOffset 
#endif 

#ifndef tuya_setRotate 
#define tuya_setRotate thing_setRotate 
#endif 

#ifndef tuya_clear 
#define tuya_clear thing_clear 
#endif 

#ifndef TYCameraTimeLabel 
#define TYCameraTimeLabel ThingCameraTimeLabel 
#endif 

#ifndef TuyaTimelineViewSource 
#define TuyaTimelineViewSource ThingTimelineViewSource 
#endif 

#ifndef TYAsyncDisplayLayer 
#define TYAsyncDisplayLayer ThingAsyncDisplayLayer 
#endif 

#ifndef TYAsyncDisplayLayerDelegate 
#define TYAsyncDisplayLayerDelegate ThingAsyncDisplayLayerDelegate 
#endif 

#ifndef TuyaTimelineUnitMode 
#define TuyaTimelineUnitMode ThingTimelineUnitMode 
#endif 

#ifndef TuyaTimelineUnitMode_60 
#define TuyaTimelineUnitMode_60 ThingTimelineUnitMode_60 
#endif 

#ifndef TuyaTimelineUnitMode_600 
#define TuyaTimelineUnitMode_600 ThingTimelineUnitMode_600 
#endif 

#ifndef TuyaTimelineUnitMode_3600 
#define TuyaTimelineUnitMode_3600 ThingTimelineUnitMode_3600 
#endif 

#ifndef TuyaTimelineView 
#define TuyaTimelineView ThingTimelineView 
#endif 

#ifndef TuyaTimelineViewDelegate 
#define TuyaTimelineViewDelegate ThingTimelineViewDelegate 
#endif 

#ifndef TYUtil 
#define TYUtil ThingUtil 
#endif 

#ifndef tysdk_timeStringWithTimeInterval 
#define tysdk_timeStringWithTimeInterval thingsdk_timeStringWithTimeInterval 
#endif 

#ifndef tysdk_is24HourClock 
#define tysdk_is24HourClock thingsdk_is24HourClock 
#endif 

#ifndef tysdk_dateAtZeroWithTimeZone 
#define tysdk_dateAtZeroWithTimeZone thingsdk_dateAtZeroWithTimeZone 
#endif 

#ifndef ty_backgroundColor
#define ty_backgroundColor thing_backgroundColor
#endif

#endif
