#ifndef TuyaSmartBeaconKitMacro_h
#define TuyaSmartBeaconKitMacro_h

#ifndef TuyaSmartBeaconResponseModel 
#define TuyaSmartBeaconResponseModel ThingSmartBeaconResponseModel 
#endif 

#ifndef TuyaSmartBeaconManager 
#define TuyaSmartBeaconManager ThingSmartBeaconManager 
#endif 

#ifndef TuyaSmartBeaconKit 
#define TuyaSmartBeaconKit ThingSmartBeaconKit 
#endif 

#ifndef TYBeaconResponseAction 
#define TYBeaconResponseAction ThingBeaconResponseAction 
#endif 

#ifndef TYBeaconResponseActionAuth 
#define TYBeaconResponseActionAuth ThingBeaconResponseActionAuth 
#endif 

#ifndef TYBeaconResponseActionCheck 
#define TYBeaconResponseActionCheck ThingBeaconResponseActionCheck 
#endif 

#ifndef TYBeaconRequestAction 
#define TYBeaconRequestAction ThingBeaconRequestAction 
#endif 

#ifndef TYBeaconRequestActionAuth 
#define TYBeaconRequestActionAuth ThingBeaconRequestActionAuth 
#endif 

#ifndef TYBeaconRequestActionCheck 
#define TYBeaconRequestActionCheck ThingBeaconRequestActionCheck 
#endif 

#ifndef TYBeaconRequestActionAbandon 
#define TYBeaconRequestActionAbandon ThingBeaconRequestActionAbandon 
#endif 

#ifndef TYBeaconRequestActionSubscribe 
#define TYBeaconRequestActionSubscribe ThingBeaconRequestActionSubscribe 
#endif 

#ifndef TYBeaconRequestActionSearch 
#define TYBeaconRequestActionSearch ThingBeaconRequestActionSearch 
#endif 

#ifndef TYBLEAdvModel 
#define TYBLEAdvModel ThingBLEAdvModel 
#endif 

#ifndef TuyaSmartBeaconRequestModel 
#define TuyaSmartBeaconRequestModel ThingSmartBeaconRequestModel 
#endif 

#ifndef TuyaSmartDeviceModel 
#define TuyaSmartDeviceModel ThingSmartDeviceModel 
#endif 

#ifndef TuyaSmartBeaconManagerDelegate 
#define TuyaSmartBeaconManagerDelegate ThingSmartBeaconManagerDelegate 
#endif 

#ifndef TuyaSmartBLEManagerDelegate 
#define TuyaSmartBLEManagerDelegate ThingSmartBLEManagerDelegate 
#endif 

#ifndef TYDeprecatedAPI 
#define TYDeprecatedAPI ThingDeprecatedAPI 
#endif 



#endif
