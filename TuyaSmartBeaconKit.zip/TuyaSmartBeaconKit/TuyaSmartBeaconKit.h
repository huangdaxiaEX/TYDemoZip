//
// TuyaSmartBeaconKit.h
// TuyaSmartBeaconKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartBeaconKit.

#ifndef TuyaSmartBeaconKit_h
#define TuyaSmartBeaconKit_h

#import "TuyaSmartBeaconKitMacro.h"

#import "TuyaSmartBeaconManager.h"
#import "TuyaSmartBeaconManager+Scan.h"
#import "TuyaSmartBeaconManager+Group.h"
#import "TuyaSmartBeaconManager+RNScan.h"
#import "TuyaSmartBeaconManager+TYDeprecatedAPI.h"
#import "TuyaSmartBeaconRequestModel.h"
#import "TuyaSmartBeaconResponseModel.h"

#endif /* TuyaSmartBeaconKit_h */
