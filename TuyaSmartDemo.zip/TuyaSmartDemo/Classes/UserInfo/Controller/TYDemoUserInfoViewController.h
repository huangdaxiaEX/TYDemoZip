//
//  TYUserInfoViewController.h
//  TuyaSmartHomeKit_Example
//
//  Created by XuChengcheng on 2020/5/19.
//  Copyright © 2020 xuchengcheng. All rights reserved.
//

#import "TPDemoBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface TYDemoUserInfoViewController : TPDemoBaseViewController

@end

NS_ASSUME_NONNULL_END
