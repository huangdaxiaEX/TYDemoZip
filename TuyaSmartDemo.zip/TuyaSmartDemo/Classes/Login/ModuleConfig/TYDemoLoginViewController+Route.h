//
//  TYLoginViewController+Route.h
//  BlocksKit
//
//  Created by huangkai on 2020/6/3.
//

#import <Foundation/Foundation.h>
#import "TYDemoLoginViewController.h"
#import "TYDemoRouteManager.h"

NS_ASSUME_NONNULL_BEGIN

@interface TYDemoLoginViewController (Route) <TYDemoRouteManagerHandleProtocol>

@end

NS_ASSUME_NONNULL_END
