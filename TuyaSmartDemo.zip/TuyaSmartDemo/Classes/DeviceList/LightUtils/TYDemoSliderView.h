//
//  TYSliderView.h
//  TuyaSmartPublic
//
//  Created by 冯晓 on 2018/2/2.
//  Copyright © 2018年 Tuya. All rights reserved.
//

#import <UIKit/UIKit.h>

@class TYDemoSliderView;

@protocol TYSDKDemoSliderViewDelegate <NSObject>

- (void)didChangeSliderValue:(TYDemoSliderView *)slider value:(double)value;

@end

@interface TYDemoSliderView : UIView

@property (nonatomic, strong) UILabel *tipsLabel;
@property (nonatomic, strong) UILabel *percentLabel;
@property (nonatomic, strong) UILabel *valueLabel;
@property (nonatomic, assign) BOOL  isShowValue;
@property (nonatomic, assign) CGFloat  minValue;
@property (nonatomic, assign) CGFloat  maxValue;
@property (nonatomic, weak) id <TYSDKDemoSliderViewDelegate> delegate;

- (void)setSliderValue:(double)value;

@end
