//
//  TYSlider.h
//  TuyaSmartPublic
//
//  Created by 冯晓 on 2018/2/3.
//  Copyright © 2018年 Tuya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TYSlider : UISlider

@end
