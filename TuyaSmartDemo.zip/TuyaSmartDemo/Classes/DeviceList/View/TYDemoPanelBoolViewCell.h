//
//  TYPanelBoolViewCell.h
//  TuyaSmartKitDemo
//
//  Created by 冯晓 on 16/8/27.
//  Copyright © 2016年 Tuya. All rights reserved.
//


#import "TYDemoPanelBaseViewCell.h"


@interface TYDemoPanelBoolViewCell : TYDemoPanelBaseViewCell

@property (nonatomic, strong) UISwitch           *switchButton;

@end
