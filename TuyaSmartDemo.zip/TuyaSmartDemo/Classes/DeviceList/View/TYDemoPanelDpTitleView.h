//
//  TYPanelDpTitleView.h
//  TuyaSmartKitDemo
//
//  Created by 冯晓 on 16/8/27.
//  Copyright © 2016年 Tuya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TYDemoPanelDpTitleView : UITableViewCell


- (void)setItem:(NSInteger)num title:(NSString *)title subTitle:(NSString *)subTitle;


@end
