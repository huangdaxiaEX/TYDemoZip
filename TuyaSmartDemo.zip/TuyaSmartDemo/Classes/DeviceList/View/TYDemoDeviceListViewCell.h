//
//  TYDeviceListViewCell.h
//  TuyaSmart
//
//  Created by 冯晓 on 16/1/4.
//  Copyright © 2016年 Tuya. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface TYDemoDeviceListViewCell : UITableViewCell


- (void)setItem:(id)item;


@end
