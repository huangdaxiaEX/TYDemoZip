//
//  TYPanelBaseViewCell.h
//  TuyaSmartKitDemo
//
//  Created by 冯晓 on 16/8/27.
//  Copyright © 2016年 Tuya. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TYDemoPanelDpTitleView.h"

@interface TYDemoPanelBaseViewCell : UITableViewCell

@property (nonatomic, strong) UIView *bgView;
@property (nonatomic, strong) TYDemoPanelDpTitleView *titleView;


@end
