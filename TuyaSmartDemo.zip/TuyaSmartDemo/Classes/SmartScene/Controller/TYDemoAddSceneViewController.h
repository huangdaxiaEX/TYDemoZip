//
//  TYAddSceneViewController.h
//  TuyaSmartPublic
//
//  Created by TuyaInc on 19/1/30.
//  Copyright © 2016年 Tuya. All rights reserved.
//

#import "TPDemoBaseTableViewController.h"

@class TuyaSmartSceneModel;

@interface TYDemoAddSceneViewController : TPDemoBaseTableViewController

@end
