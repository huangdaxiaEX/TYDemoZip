//
//  SmartSceneViewController.h
//  TuyaSmartPublic
//
//  Created by XuChengcheng on 16/7/4.
//  Copyright © 2016年 Tuya. All rights reserved.
//

#import "TPDemoBaseTableViewController.h"

@interface TYDemoSmartSceneViewController : TPDemoBaseTableViewController

@end
