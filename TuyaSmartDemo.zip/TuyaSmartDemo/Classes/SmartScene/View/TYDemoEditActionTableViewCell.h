//
//  TYEditActionTableViewCell.h
//  TuyaSmartPublic
//
//  Created by XuChengcheng on 16/7/12.
//  Copyright © 2016年 Tuya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TYDemoEditActionTableViewCell : UITableViewCell

@property (nonatomic, strong) UILabel *subTitleLabel;
@property (nonatomic, strong) UILabel *titleLable;
@property (nonatomic, strong) UILabel *offlineLabel;

@end
