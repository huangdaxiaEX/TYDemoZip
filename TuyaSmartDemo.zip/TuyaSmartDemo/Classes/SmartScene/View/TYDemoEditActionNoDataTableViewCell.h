//
//  TYEditActionNoDataTableViewCell.h
//  TuyaSmartPublic
//
//  Created by XuChengcheng on 2016/10/11.
//  Copyright © 2016年 Tuya. All rights reserved.
//

@interface TYDemoEditActionNoDataTableViewCell : UITableViewCell

@property (nonatomic, strong) UILabel *titleLabel;

@end
