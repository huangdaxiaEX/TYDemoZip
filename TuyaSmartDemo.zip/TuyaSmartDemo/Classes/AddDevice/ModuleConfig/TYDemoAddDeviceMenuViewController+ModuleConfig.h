//
//  TYAddDeviceMenuViewController+ModuleConfig.h
//  BlocksKit
//
//  Created by huangkai on 2020/6/3.
//

#import <Foundation/Foundation.h>
#import "TYDemoAddDeviceMenuViewController.h"
#import "TYDemoConfiguration.h"
#import "TYDemoRouteManager.h"

NS_ASSUME_NONNULL_BEGIN

@interface TYDemoAddDeviceMenuViewController (ModuleConfig) <TYTabBarVCProtocol>

@end

NS_ASSUME_NONNULL_END
