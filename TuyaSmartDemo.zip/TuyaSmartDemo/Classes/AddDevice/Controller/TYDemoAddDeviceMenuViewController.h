//
//  TYAddDeviceMenuViewController.h
//  TuyaSmartHomeKit_Example
//
//  Created by 盖剑秋 on 2018/11/15.
//  Copyright © 2018 xuchengcheng. All rights reserved.
//

#import "TPDemoBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN


/*
 doc link
 
 en:https://tuyainc.github.io/tuyasmart_home_ios_sdk_doc/en/resource/Activator.html#network-configuration
 zh-hans:https://tuyainc.github.io/tuyasmart_home_ios_sdk_doc/zh-hans/resource/Activator.html#%E8%AE%BE%E5%A4%87%E9%85%8D%E7%BD%91
 */
@interface TYDemoAddDeviceMenuViewController : TPDemoBaseViewController

@end

NS_ASSUME_NONNULL_END
