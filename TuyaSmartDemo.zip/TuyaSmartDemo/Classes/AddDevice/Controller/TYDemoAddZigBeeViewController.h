//
//  TYDemoAddZigBeeViewController
//  TuyaSmartHomeKit_Example
//
//  Created by 盖剑秋 on 2018/11/19.
//  Copyright © 2018 xuchengcheng. All rights reserved.
//

#import "TPDemoBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN


@interface TYDemoAddZigBeeViewController : TPDemoBaseViewController

@property (nonatomic, assign) BOOL forZigBeeSubdevice;// For ZigBee gateway of ZigBee subdevice.

@end

NS_ASSUME_NONNULL_END
