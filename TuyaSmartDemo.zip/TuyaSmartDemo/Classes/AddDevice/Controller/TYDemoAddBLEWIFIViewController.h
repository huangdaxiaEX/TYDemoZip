//
//  TYDemoAddBLEWIFIViewController.h
//  TuyaSmartDemo
//
//  Created by huangkai on 2020/12/2.
//

#import "TPDemoBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface TYDemoAddBLEWIFIViewController : TPDemoBaseViewController

@end

NS_ASSUME_NONNULL_END
