#ifndef TuyaCloudStorageDebuggerMacro_h
#define TuyaCloudStorageDebuggerMacro_h

#ifndef TuyaCloudStorageDebugger 
#define TuyaCloudStorageDebugger ThingCloudStorageDebugger 
#endif 

#ifndef TuyaCloudStorageDebuggerVersionNumber 
#define TuyaCloudStorageDebuggerVersionNumber ThingCloudStorageDebuggerVersionNumber 
#endif 



#endif
