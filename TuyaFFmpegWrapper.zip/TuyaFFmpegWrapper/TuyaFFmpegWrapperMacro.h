#ifndef TuyaFFmpegWrapperMacro_h
#define TuyaFFmpegWrapperMacro_h

#ifndef __TYFFmpegWrapper_H__ 
#define __TYFFmpegWrapper_H__ __ThingFFmpegWrapper_H__ 
#endif 



#endif
