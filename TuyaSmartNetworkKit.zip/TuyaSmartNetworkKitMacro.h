#ifndef TuyaSmartNetworkKitMacro_h
#define TuyaSmartNetworkKitMacro_h

#ifndef TYApiMergeModel 
#define TYApiMergeModel ThingApiMergeModel 
#endif 

#ifndef TuyaSmartNetworkKitErrors 
#define TuyaSmartNetworkKitErrors ThingSmartNetworkKitErrors 
#endif 

#ifndef kTYNetworkKitErrorDomain 
#define kTYNetworkKitErrorDomain kThingNetworkKitErrorDomain 
#endif 

#ifndef TYNetworkKitError 
#define TYNetworkKitError ThingNetworkKitError 
#endif 

#ifndef kTYNetworkKitErrorAPIRequestError 
#define kTYNetworkKitErrorAPIRequestError kThingNetworkKitErrorAPIRequestError 
#endif 

#ifndef kTYNetworkKitErrorAPIResponseDataTypeIllegal 
#define kTYNetworkKitErrorAPIResponseDataTypeIllegal kThingNetworkKitErrorAPIResponseDataTypeIllegal 
#endif 

#ifndef kTYNetworkKitErrorAPIResponseDataSignInconsistent 
#define kTYNetworkKitErrorAPIResponseDataSignInconsistent kThingNetworkKitErrorAPIResponseDataSignInconsistent 
#endif 

#ifndef kTYNetworkKitErrorAPIResponseDataDecodeError 
#define kTYNetworkKitErrorAPIResponseDataDecodeError kThingNetworkKitErrorAPIResponseDataDecodeError 
#endif 

#ifndef kTYNetworkKitErrorNetworkError 
#define kTYNetworkKitErrorNetworkError kThingNetworkKitErrorNetworkError 
#endif 

#ifndef TuyaSmartSDK_Log 
#define TuyaSmartSDK_Log ThingSmartSDK_Log 
#endif 

#ifndef TuyaSmartSDK 
#define TuyaSmartSDK ThingSmartSDK 
#endif 

#ifndef TYEnv 
#define TYEnv ThingEnv 
#endif 

#ifndef TYEnvDaily 
#define TYEnvDaily ThingEnvDaily 
#endif 

#ifndef TYEnvPrepare 
#define TYEnvPrepare ThingEnvPrepare 
#endif 

#ifndef TYEnvRelease 
#define TYEnvRelease ThingEnvRelease 
#endif 

#ifndef TuyaSmartRequest 
#define TuyaSmartRequest ThingSmartRequest 
#endif 

#ifndef TuyaSmartRequestIntercepterInfo 
#define TuyaSmartRequestIntercepterInfo ThingSmartRequestIntercepterInfo 
#endif 

#ifndef TuyaSmartRequestIntercepter 
#define TuyaSmartRequestIntercepter ThingSmartRequestIntercepter 
#endif 

#ifndef TuyaSmartTokenRefreshDelegate 
#define TuyaSmartTokenRefreshDelegate ThingSmartTokenRefreshDelegate 
#endif 

#ifndef TYSuccessHandler 
#define TYSuccessHandler ThingSuccessHandler 
#endif 

#ifndef TYSuccessID 
#define TYSuccessID ThingSuccessID 
#endif 

#ifndef TYFailureError 
#define TYFailureError ThingFailureError 
#endif 

#ifndef TYSuccessList 
#define TYSuccessList ThingSuccessList 
#endif 

#ifndef TuyaSmartHTTPDNS 
#define TuyaSmartHTTPDNS ThingSmartHTTPDNS 
#endif 

#ifndef TuyaSmartHTTPDNSIntercepter 
#define TuyaSmartHTTPDNSIntercepter ThingSmartHTTPDNSIntercepter 
#endif 

#ifndef TuyaSmartNetworkKit 
#define TuyaSmartNetworkKit ThingSmartNetworkKit 
#endif 

#ifndef TUYA_SDK_VERSION 
#define TUYA_SDK_VERSION THING_SDK_VERSION 
#endif 

#ifndef TYApiMergeService 
#define TYApiMergeService ThingApiMergeService 
#endif 

#ifndef TuyaSmartApiConfigurable 
#define TuyaSmartApiConfigurable ThingSmartApiConfigurable 
#endif 

#ifndef TuyaSmartDomainConfigurable 
#define TuyaSmartDomainConfigurable ThingSmartDomainConfigurable 
#endif 

#ifndef tuyaAppUrl 
#define tuyaAppUrl thingAppUrl 
#endif 

#ifndef tuyaImagesUrl 
#define tuyaImagesUrl thingImagesUrl 
#endif 

#ifndef TuyaSmartSDKEvent 
#define TuyaSmartSDKEvent ThingSmartSDKEvent 
#endif 



#endif
