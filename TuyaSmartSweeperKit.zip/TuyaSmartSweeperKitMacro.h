#ifndef TuyaSmartSweeperKitMacro_h
#define TuyaSmartSweeperKitMacro_h

#ifndef TuyaSmartSweeperDevice 
#define TuyaSmartSweeperDevice ThingSmartSweeperDevice 
#endif 

#ifndef TuyaSmartSweeperHistoryModel 
#define TuyaSmartSweeperHistoryModel ThingSmartSweeperHistoryModel 
#endif 

#ifndef TuyaSmartSweeperMQTTMessage 
#define TuyaSmartSweeperMQTTMessage ThingSmartSweeperMQTTMessage 
#endif 

#ifndef TuyaSmartFileDownloadModel 
#define TuyaSmartFileDownloadModel ThingSmartFileDownloadModel 
#endif 

#ifndef TuyaSmartFileDownloadRateModel 
#define TuyaSmartFileDownloadRateModel ThingSmartFileDownloadRateModel 
#endif 

#ifndef TuyaSmartSweeperRecordDetail 
#define TuyaSmartSweeperRecordDetail ThingSmartSweeperRecordDetail 
#endif 

#ifndef TuyaSmartSweeperRecordList 
#define TuyaSmartSweeperRecordList ThingSmartSweeperRecordList 
#endif 

#ifndef TuyaSmartSweeperCurrentPathKey 
#define TuyaSmartSweeperCurrentPathKey ThingSmartSweeperCurrentPathKey 
#endif 

#ifndef TUYA_SDK_SWEEPER_VERSION 
#define TUYA_SDK_SWEEPER_VERSION THING_SDK_SWEEPER_VERSION 
#endif 

#ifndef TuyaSmartSweepCurrentMapPathKey 
#define TuyaSmartSweepCurrentMapPathKey ThingSmartSweepCurrentMapPathKey 
#endif 

#ifndef TuyaSmartSweepCurrentRoutePathKey 
#define TuyaSmartSweepCurrentRoutePathKey ThingSmartSweepCurrentRoutePathKey 
#endif 

#ifndef TuyaSmartSweeperDeviceDelegate 
#define TuyaSmartSweeperDeviceDelegate ThingSmartSweeperDeviceDelegate 
#endif 

#ifndef TuyaSmartSweeperFileDownloadStatus 
#define TuyaSmartSweeperFileDownloadStatus ThingSmartSweeperFileDownloadStatus 
#endif 

#ifndef TuyaSmartSweeperP2PDownloadType 
#define TuyaSmartSweeperP2PDownloadType ThingSmartSweeperP2PDownloadType 
#endif 

#ifndef TuyaSmartSweeperP2PIndexItemModel 
#define TuyaSmartSweeperP2PIndexItemModel ThingSmartSweeperP2PIndexItemModel 
#endif 

#ifndef TuyaSmartFileDownload 
#define TuyaSmartFileDownload ThingSmartFileDownload 
#endif 

#ifndef TuyaSmartFileDownloadStatus 
#define TuyaSmartFileDownloadStatus ThingSmartFileDownloadStatus 
#endif 

#ifndef TuyaSmartFileDownloadStatusUpgrading 
#define TuyaSmartFileDownloadStatusUpgrading ThingSmartFileDownloadStatusUpgrading 
#endif 

#ifndef TuyaSmartFileDownloadStatusFinish 
#define TuyaSmartFileDownloadStatusFinish ThingSmartFileDownloadStatusFinish 
#endif 

#ifndef TuyaSmartFileDownloadStatusFailure 
#define TuyaSmartFileDownloadStatusFailure ThingSmartFileDownloadStatusFailure 
#endif 

#ifndef TYFailureError 
#define TYFailureError ThingFailureError 
#endif 

#ifndef TYSuccessID 
#define TYSuccessID ThingSuccessID 
#endif 

#ifndef TuyaSmartSweeperKit 
#define TuyaSmartSweeperKit ThingSmartSweeperKit 
#endif 

#ifndef TuyaSmartSweeperDefines 
#define TuyaSmartSweeperDefines ThingSmartSweeperDefines 
#endif 

#ifndef TuyaSmartSweeperFileDownloadUpgrading 
#define TuyaSmartSweeperFileDownloadUpgrading ThingSmartSweeperFileDownloadUpgrading 
#endif 

#ifndef TuyaSmartSweeperFileDownloadFinish 
#define TuyaSmartSweeperFileDownloadFinish ThingSmartSweeperFileDownloadFinish 
#endif 

#ifndef TuyaSmartSweeperFileDownloadFailure 
#define TuyaSmartSweeperFileDownloadFailure ThingSmartSweeperFileDownloadFailure 
#endif 

#ifndef TuyaSmartSweeperP2PDownloadTypeOnce 
#define TuyaSmartSweeperP2PDownloadTypeOnce ThingSmartSweeperP2PDownloadTypeOnce 
#endif 

#ifndef TuyaSmartSweeperP2PDownloadTypeStill 
#define TuyaSmartSweeperP2PDownloadTypeStill ThingSmartSweeperP2PDownloadTypeStill 
#endif 

#ifndef TuyaSmartSweeperP2PErrorCode 
#define TuyaSmartSweeperP2PErrorCode ThingSmartSweeperP2PErrorCode 
#endif 

#ifndef TuyaSmartSweeperP2PErrorCodeNoDevice 
#define TuyaSmartSweeperP2PErrorCodeNoDevice ThingSmartSweeperP2PErrorCodeNoDevice 
#endif 

#ifndef TuyaSmartSweeperP2PErrorCodeConnecting 
#define TuyaSmartSweeperP2PErrorCodeConnecting ThingSmartSweeperP2PErrorCodeConnecting 
#endif 

#ifndef TuyaSmartSweeperP2PErrorCodeTimeout 
#define TuyaSmartSweeperP2PErrorCodeTimeout ThingSmartSweeperP2PErrorCodeTimeout 
#endif 

#ifndef TuyaSmartSweeperP2PErrorCodeDisConnect 
#define TuyaSmartSweeperP2PErrorCodeDisConnect ThingSmartSweeperP2PErrorCodeDisConnect 
#endif 

#ifndef TuyaSmartSweeperP2PErrorCodeDependency 
#define TuyaSmartSweeperP2PErrorCodeDependency ThingSmartSweeperP2PErrorCodeDependency 
#endif 

#ifndef TuyaSmartSweeperP2PErrorCodeOffline 
#define TuyaSmartSweeperP2PErrorCodeOffline ThingSmartSweeperP2PErrorCodeOffline 
#endif 

#ifndef TuyaSmartSweeperP2PErrorCodeNoFile 
#define TuyaSmartSweeperP2PErrorCodeNoFile ThingSmartSweeperP2PErrorCodeNoFile 
#endif 

#ifndef TuyaSmartSweeperP2PIndexModel 
#define TuyaSmartSweeperP2PIndexModel ThingSmartSweeperP2PIndexModel 
#endif 

#ifndef TuyaSmartSweeperMQTTMessageType 
#define TuyaSmartSweeperMQTTMessageType ThingSmartSweeperMQTTMessageType 
#endif 

#ifndef TuyaSmartSweeperMQTTMessageMap 
#define TuyaSmartSweeperMQTTMessageMap ThingSmartSweeperMQTTMessageMap 
#endif 

#ifndef TuyaSmartSweeperMQTTMessageRoute 
#define TuyaSmartSweeperMQTTMessageRoute ThingSmartSweeperMQTTMessageRoute 
#endif 

#ifndef TYSweeperCurrentPathKey 
#define TYSweeperCurrentPathKey ThingSweeperCurrentPathKey 
#endif 

#ifndef TYSweeperCurrentMapPathKey 
#define TYSweeperCurrentMapPathKey ThingSweeperCurrentMapPathKey 
#endif 

#ifndef TYSweeperCurrentRoutePathKey 
#define TYSweeperCurrentRoutePathKey ThingSweeperCurrentRoutePathKey 
#endif 

#ifndef TuyaSmartSweeper 
#define TuyaSmartSweeper ThingSmartSweeper 
#endif 



#endif
