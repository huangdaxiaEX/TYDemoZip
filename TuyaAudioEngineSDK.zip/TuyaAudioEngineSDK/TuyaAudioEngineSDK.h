//
// TuyaAudioEngineSDK.h
// TuyaAudioEngineSDK
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaAudioEngineSDK.

#ifndef TuyaAudioEngineSDK_h
#define TuyaAudioEngineSDK_h

#import "TuyaAudioEngineSDKMacro.h"

#import <Foundation/Foundation.h>

#import <UIKit/UIKit.h>

#import <TuyaAudioEngineSDK/TuyaAudioEngine.h>
#import <TuyaAudioEngineSDK/TuyaVoiceDetector.h>
#import <TuyaAudioEngineSDK/TuyaAudioDefines.h>
