#ifndef TuyaAudioEngineSDKMacro_h
#define TuyaAudioEngineSDKMacro_h

#ifndef TuyaAudioEngineSDKVersionNumber 
#define TuyaAudioEngineSDKVersionNumber ThingAudioEngineSDKVersionNumber 
#endif 

#ifndef TuyaAudioEngine_version 
#define TuyaAudioEngine_version ThingAudioEngine_version 
#endif 

#ifndef kTuyaVADErrCode_NoErr 
#define kTuyaVADErrCode_NoErr kThingVADErrCode_NoErr 
#endif 

#ifndef kTuyaVADErrCode_DetectedErr 
#define kTuyaVADErrCode_DetectedErr kThingVADErrCode_DetectedErr 
#endif 

#ifndef TuyaAudioEngineDelegate 
#define TuyaAudioEngineDelegate ThingAudioEngineDelegate 
#endif 

#ifndef TuyaAudioEngine 
#define TuyaAudioEngine ThingAudioEngine 
#endif 

#ifndef TuyaVoiceDetectorDelegate 
#define TuyaVoiceDetectorDelegate ThingVoiceDetectorDelegate 
#endif 

#ifndef TuyaVoiceDetector 
#define TuyaVoiceDetector ThingVoiceDetector 
#endif 



#endif
