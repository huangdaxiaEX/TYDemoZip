//
// TuyaSmartCameraBase.h
// TuyaSmartCameraBase
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartCameraBase.

#ifndef TuyaSmartCameraBase_h
#define TuyaSmartCameraBase_h

#import "TuyaSmartCameraBaseMacro.h"

#import "TuyaSmartCameraDefines.h"
#import "TuyaSmartCameraFactory.h"
#import "TuyaSmartCameraType.h"
#import "TuyaSmartVideoViewType.h"
#import "TYCameraUtil.h"
#import "UIImage+YUV.h"

#endif /* TuyaSmartCameraBase_h */
