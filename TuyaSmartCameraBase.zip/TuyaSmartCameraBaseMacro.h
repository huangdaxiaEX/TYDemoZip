#ifndef TuyaSmartCameraBaseMacro_h
#define TuyaSmartCameraBaseMacro_h

#ifndef TuyaSmartCameraBase 
#define TuyaSmartCameraBase ThingSmartCameraBase 
#endif 

#ifndef TuyaSmartCameraBase_version 
#define TuyaSmartCameraBase_version ThingSmartCameraBase_version 
#endif 

#ifndef TYCameraUtil 
#define TYCameraUtil ThingCameraUtil 
#endif 

#ifndef TuyaSmartVideoRotateDirection 
#define TuyaSmartVideoRotateDirection ThingSmartVideoRotateDirection 
#endif 

#ifndef TuyaSmartCameraP2PType 
#define TuyaSmartCameraP2PType ThingSmartCameraP2PType 
#endif 

#ifndef TuyaSmartCameraP2PTypeTUTK 
#define TuyaSmartCameraP2PTypeTUTK ThingSmartCameraP2PTypeTUTK 
#endif 

#ifndef TuyaSmartCameraP2PTypePPCS 
#define TuyaSmartCameraP2PTypePPCS ThingSmartCameraP2PTypePPCS 
#endif 

#ifndef TuyaSmartCameraP2PTypeTUYA 
#define TuyaSmartCameraP2PTypeTUYA ThingSmartCameraP2PTypeTUYA 
#endif 

#ifndef TuyaSmartCameraConfig 
#define TuyaSmartCameraConfig ThingSmartCameraConfig 
#endif 

#ifndef TuyaSmartUser 
#define TuyaSmartUser ThingSmartUser 
#endif 

#ifndef TuyaSmartCameraMaker 
#define TuyaSmartCameraMaker ThingSmartCameraMaker 
#endif 

#ifndef TuyaSmartCameraFactory 
#define TuyaSmartCameraFactory ThingSmartCameraFactory 
#endif 

#ifndef tuyaSmartCameraVersion 
#define tuyaSmartCameraVersion thingSmartCameraVersion 
#endif 

#ifndef TuyaSmartVideoViewType 
#define TuyaSmartVideoViewType ThingSmartVideoViewType 
#endif 

#ifndef tuya_setScaled 
#define tuya_setScaled thing_setScaled 
#endif 

#ifndef tuya_setOffset 
#define tuya_setOffset thing_setOffset 
#endif 

#ifndef tuya_clear 
#define tuya_clear thing_clear 
#endif 

#ifndef tuya_setRotate 
#define tuya_setRotate thing_setRotate 
#endif 

#ifndef tuya_setStretchSize 
#define tuya_setStretchSize thing_setStretchSize 
#endif 

#ifndef TYFeatureRect 
#define TYFeatureRect ThingFeatureRect 
#endif 

#ifndef TYPixelBufferItem 
#define TYPixelBufferItem ThingPixelBufferItem 
#endif 

#ifndef TYPixelBufferItemRef 
#define TYPixelBufferItemRef ThingPixelBufferItemRef 
#endif 

#ifndef TYPixelBufferQueue 
#define TYPixelBufferQueue ThingPixelBufferQueue 
#endif 

#ifndef TYPixelBufferQueueRef 
#define TYPixelBufferQueueRef ThingPixelBufferQueueRef 
#endif 

#ifndef TuyaSmartCameraDefines 
#define TuyaSmartCameraDefines ThingSmartCameraDefines 
#endif 

#ifndef TUYA_MEDIA_CODEC_UNKNOWN 
#define TUYA_MEDIA_CODEC_UNKNOWN THING_MEDIA_CODEC_UNKNOWN 
#endif 

#ifndef TUYA_MEDIA_CODEC_VIDEO_MPEG4 
#define TUYA_MEDIA_CODEC_VIDEO_MPEG4 THING_MEDIA_CODEC_VIDEO_MPEG4 
#endif 

#ifndef TUYA_MEDIA_CODEC_VIDEO_H263 
#define TUYA_MEDIA_CODEC_VIDEO_H263 THING_MEDIA_CODEC_VIDEO_H263 
#endif 

#ifndef TUYA_MEDIA_CODEC_VIDEO_H264 
#define TUYA_MEDIA_CODEC_VIDEO_H264 THING_MEDIA_CODEC_VIDEO_H264 
#endif 

#ifndef TUYA_MEDIA_CODEC_VIDEO_MJPEG 
#define TUYA_MEDIA_CODEC_VIDEO_MJPEG THING_MEDIA_CODEC_VIDEO_MJPEG 
#endif 

#ifndef TUYA_MEDIA_CODEC_VIDEO_H265 
#define TUYA_MEDIA_CODEC_VIDEO_H265 THING_MEDIA_CODEC_VIDEO_H265 
#endif 

#ifndef TUYA_ENUM_CODECID 
#define TUYA_ENUM_CODECID THING_ENUM_CODECID 
#endif 

#ifndef TuyaSmartVideoStreamInfo 
#define TuyaSmartVideoStreamInfo ThingSmartVideoStreamInfo 
#endif 

#ifndef TuyaSmartVideoFrameInfo 
#define TuyaSmartVideoFrameInfo ThingSmartVideoFrameInfo 
#endif 

#ifndef TuyaSmartAudioFrameInfo 
#define TuyaSmartAudioFrameInfo ThingSmartAudioFrameInfo 
#endif 

#ifndef TY_ERROR_NONE 
#define TY_ERROR_NONE Thing_ERROR_NONE 
#endif 

#ifndef TY_ERROR_CONNECT_FAILED 
#define TY_ERROR_CONNECT_FAILED Thing_ERROR_CONNECT_FAILED 
#endif 

#ifndef TY_ERROR_CONNECT_DISCONNECT 
#define TY_ERROR_CONNECT_DISCONNECT Thing_ERROR_CONNECT_DISCONNECT 
#endif 

#ifndef TY_ERROR_ENTER_PLAYBACK_FAILED 
#define TY_ERROR_ENTER_PLAYBACK_FAILED Thing_ERROR_ENTER_PLAYBACK_FAILED 
#endif 

#ifndef TY_ERROR_START_PREVIEW_FAILED 
#define TY_ERROR_START_PREVIEW_FAILED Thing_ERROR_START_PREVIEW_FAILED 
#endif 

#ifndef TY_ERROR_START_PLAYBACK_FAILED 
#define TY_ERROR_START_PLAYBACK_FAILED Thing_ERROR_START_PLAYBACK_FAILED 
#endif 

#ifndef TY_ERROR_PAUSE_PLAYBACK_FAILED 
#define TY_ERROR_PAUSE_PLAYBACK_FAILED Thing_ERROR_PAUSE_PLAYBACK_FAILED 
#endif 

#ifndef TY_ERROR_RESUME_PLAYBACK_FAILED 
#define TY_ERROR_RESUME_PLAYBACK_FAILED Thing_ERROR_RESUME_PLAYBACK_FAILED 
#endif 

#ifndef TY_ERROR_ENABLE_MUTE_FAILED 
#define TY_ERROR_ENABLE_MUTE_FAILED Thing_ERROR_ENABLE_MUTE_FAILED 
#endif 

#ifndef TY_ERROR_START_TALK_FAILED 
#define TY_ERROR_START_TALK_FAILED Thing_ERROR_START_TALK_FAILED 
#endif 

#ifndef TY_ERROR_SNAPSHOOT_FAILED 
#define TY_ERROR_SNAPSHOOT_FAILED Thing_ERROR_SNAPSHOOT_FAILED 
#endif 

#ifndef TY_ERROR_RECORD_FAILED 
#define TY_ERROR_RECORD_FAILED Thing_ERROR_RECORD_FAILED 
#endif 

#ifndef TY_ERROR_ENABLE_HD_FAILED 
#define TY_ERROR_ENABLE_HD_FAILED Thing_ERROR_ENABLE_HD_FAILED 
#endif 

#ifndef TY_ERROR_GET_HD_FAILED 
#define TY_ERROR_GET_HD_FAILED Thing_ERROR_GET_HD_FAILED 
#endif 

#ifndef TY_ERROR_QUERY_RECORD_DAY_FAILED 
#define TY_ERROR_QUERY_RECORD_DAY_FAILED Thing_ERROR_QUERY_RECORD_DAY_FAILED 
#endif 

#ifndef TY_ERROR_QUERY_TIMESLICE_FAILED 
#define TY_ERROR_QUERY_TIMESLICE_FAILED Thing_ERROR_QUERY_TIMESLICE_FAILED 
#endif 

#ifndef TY_ERROR_QUERY_EVENTLIST_SIFT_FAILED 
#define TY_ERROR_QUERY_EVENTLIST_SIFT_FAILED Thing_ERROR_QUERY_EVENTLIST_SIFT_FAILED 
#endif 

#ifndef TYCameraErrorCode 
#define TYCameraErrorCode ThingCameraErrorCode 
#endif 

#ifndef TuyaSmartCameraPlayMode 
#define TuyaSmartCameraPlayMode ThingSmartCameraPlayMode 
#endif 

#ifndef TuyaSmartCameraPlayModeNone 
#define TuyaSmartCameraPlayModeNone ThingSmartCameraPlayModeNone 
#endif 

#ifndef TuyaSmartCameraPlayModePreview 
#define TuyaSmartCameraPlayModePreview ThingSmartCameraPlayModePreview 
#endif 

#ifndef TuyaSmartCameraPlayModePlayback 
#define TuyaSmartCameraPlayModePlayback ThingSmartCameraPlayModePlayback 
#endif 

#ifndef TuyaSmartCameraTalkbackMode 
#define TuyaSmartCameraTalkbackMode ThingSmartCameraTalkbackMode 
#endif 

#ifndef TuyaSmartCameraTalkbackNone 
#define TuyaSmartCameraTalkbackNone ThingSmartCameraTalkbackNone 
#endif 

#ifndef TuyaSmartCameraTalkbackOneWay 
#define TuyaSmartCameraTalkbackOneWay ThingSmartCameraTalkbackOneWay 
#endif 

#ifndef TuyaSmartCameraTalkbackTwoWay 
#define TuyaSmartCameraTalkbackTwoWay ThingSmartCameraTalkbackTwoWay 
#endif 

#ifndef TuyaSmartCameraDefinition 
#define TuyaSmartCameraDefinition ThingSmartCameraDefinition 
#endif 

#ifndef TuyaSmartCameraDefinitionProflow 
#define TuyaSmartCameraDefinitionProflow ThingSmartCameraDefinitionProflow 
#endif 

#ifndef TuyaSmartCameraDefinitionStandard 
#define TuyaSmartCameraDefinitionStandard ThingSmartCameraDefinitionStandard 
#endif 

#ifndef TuyaSmartCameraDefinitionHigh 
#define TuyaSmartCameraDefinitionHigh ThingSmartCameraDefinitionHigh 
#endif 

#ifndef TuyaSmartCameraDefinitionSuper 
#define TuyaSmartCameraDefinitionSuper ThingSmartCameraDefinitionSuper 
#endif 

#ifndef TuyaSmartCameraDefinitionSSuper 
#define TuyaSmartCameraDefinitionSSuper ThingSmartCameraDefinitionSSuper 
#endif 

#ifndef TuyaSmartCameraDefinitionAudioOnly 
#define TuyaSmartCameraDefinitionAudioOnly ThingSmartCameraDefinitionAudioOnly 
#endif 

#ifndef TuyaSmartCameraPlayBackSpeed 
#define TuyaSmartCameraPlayBackSpeed ThingSmartCameraPlayBackSpeed 
#endif 

#ifndef TuyaSmartCameraPlayBackSpeed_05TIMES 
#define TuyaSmartCameraPlayBackSpeed_05TIMES ThingSmartCameraPlayBackSpeed_05TIMES 
#endif 

#ifndef TuyaSmartCameraPlayBackSpeed_10TIMES 
#define TuyaSmartCameraPlayBackSpeed_10TIMES ThingSmartCameraPlayBackSpeed_10TIMES 
#endif 

#ifndef TuyaSmartCameraPlayBackSpeed_15TIMES 
#define TuyaSmartCameraPlayBackSpeed_15TIMES ThingSmartCameraPlayBackSpeed_15TIMES 
#endif 

#ifndef TuyaSmartCameraPlayBackSpeed_20TIMES 
#define TuyaSmartCameraPlayBackSpeed_20TIMES ThingSmartCameraPlayBackSpeed_20TIMES 
#endif 

#ifndef TuyaSmartCameraPlayBackSpeed_25TIMES 
#define TuyaSmartCameraPlayBackSpeed_25TIMES ThingSmartCameraPlayBackSpeed_25TIMES 
#endif 

#ifndef TuyaSmartCameraPlayBackSpeed_30TIMES 
#define TuyaSmartCameraPlayBackSpeed_30TIMES ThingSmartCameraPlayBackSpeed_30TIMES 
#endif 

#ifndef TuyaSmartCameraPlayBackSpeed_35TIMES 
#define TuyaSmartCameraPlayBackSpeed_35TIMES ThingSmartCameraPlayBackSpeed_35TIMES 
#endif 

#ifndef TuyaSmartCameraPlayBackSpeed_40TIMES 
#define TuyaSmartCameraPlayBackSpeed_40TIMES ThingSmartCameraPlayBackSpeed_40TIMES 
#endif 

#ifndef TuyaSmartCameraPlayBackSpeed_80TIMES 
#define TuyaSmartCameraPlayBackSpeed_80TIMES ThingSmartCameraPlayBackSpeed_80TIMES 
#endif 

#ifndef TuyaSmartCameraPlayBackSpeed_160TIMES 
#define TuyaSmartCameraPlayBackSpeed_160TIMES ThingSmartCameraPlayBackSpeed_160TIMES 
#endif 

#ifndef TuyaSmartCameraPlayBackSpeed_320TIMES 
#define TuyaSmartCameraPlayBackSpeed_320TIMES ThingSmartCameraPlayBackSpeed_320TIMES 
#endif 

#ifndef kTuyaSmartTimeSliceStartDate 
#define kTuyaSmartTimeSliceStartDate kThingSmartTimeSliceStartDate 
#endif 

#ifndef kTuyaSmartTimeSliceStopDate 
#define kTuyaSmartTimeSliceStopDate kThingSmartTimeSliceStopDate 
#endif 

#ifndef kTuyaSmartTimeSliceStartTime 
#define kTuyaSmartTimeSliceStartTime kThingSmartTimeSliceStartTime 
#endif 

#ifndef kTuyaSmartTimeSliceStopTime 
#define kTuyaSmartTimeSliceStopTime kThingSmartTimeSliceStopTime 
#endif 

#ifndef kTuyaSmartTimeSliceRecordType 
#define kTuyaSmartTimeSliceRecordType kThingSmartTimeSliceRecordType 
#endif 

#ifndef kTuyaSmartTimeSliceRecordEventType 
#define kTuyaSmartTimeSliceRecordEventType kThingSmartTimeSliceRecordEventType 
#endif 

#ifndef TuyaSmartCameraConnectMode 
#define TuyaSmartCameraConnectMode ThingSmartCameraConnectMode 
#endif 

#ifndef TuyaSmartCameraConnectAuto 
#define TuyaSmartCameraConnectAuto ThingSmartCameraConnectAuto 
#endif 

#ifndef TuyaSmartCameraConnectFromInternet 
#define TuyaSmartCameraConnectFromInternet ThingSmartCameraConnectFromInternet 
#endif 

#ifndef TuyaSmartCameraConnectFromLocal 
#define TuyaSmartCameraConnectFromLocal ThingSmartCameraConnectFromLocal 
#endif 

#ifndef TuyaSmartVideoRotateDirectionUp 
#define TuyaSmartVideoRotateDirectionUp ThingSmartVideoRotateDirectionUp 
#endif 

#ifndef TuyaSmartVideoRotateDirectionRight 
#define TuyaSmartVideoRotateDirectionRight ThingSmartVideoRotateDirectionRight 
#endif 

#ifndef TuyaSmartVideoRotateDirectionDown 
#define TuyaSmartVideoRotateDirectionDown ThingSmartVideoRotateDirectionDown 
#endif 

#ifndef TuyaSmartVideoRotateDirectionLeft 
#define TuyaSmartVideoRotateDirectionLeft ThingSmartVideoRotateDirectionLeft 
#endif 

#ifndef TuyaSmartVideoMirrorDirection 
#define TuyaSmartVideoMirrorDirection ThingSmartVideoMirrorDirection 
#endif 

#ifndef TuyaSmartVideoMirrorDirectionDefault 
#define TuyaSmartVideoMirrorDirectionDefault ThingSmartVideoMirrorDirectionDefault 
#endif 

#ifndef TuyaSmartVideoMirrorDirectionHorizontal 
#define TuyaSmartVideoMirrorDirectionHorizontal ThingSmartVideoMirrorDirectionHorizontal 
#endif 

#ifndef TuyaSmartVideoRotateDirectionVertical 
#define TuyaSmartVideoRotateDirectionVertical ThingSmartVideoRotateDirectionVertical 
#endif 

#ifndef TuyaSmartCameraType 
#define TuyaSmartCameraType ThingSmartCameraType 
#endif 

#ifndef TuyaSmartCameraDelegate 
#define TuyaSmartCameraDelegate ThingSmartCameraDelegate 
#endif 

#ifndef kTuyaSmartPlaybackPeriodStartDate 
#define kTuyaSmartPlaybackPeriodStartDate kThingSmartPlaybackPeriodStartDate 
#endif 

#ifndef kTuyaSmartPlaybackPeriodStopDate 
#define kTuyaSmartPlaybackPeriodStopDate kThingSmartPlaybackPeriodStopDate 
#endif 

#ifndef kTuyaSmartPlaybackPeriodStartTime 
#define kTuyaSmartPlaybackPeriodStartTime kThingSmartPlaybackPeriodStartTime 
#endif 

#ifndef kTuyaSmartPlaybackPeriodStopTime 
#define kTuyaSmartPlaybackPeriodStopTime kThingSmartPlaybackPeriodStopTime 
#endif 

#ifndef ty_didReceiveFrameData
#define ty_didReceiveFrameData thing_didReceiveFrameData
#endif

#ifndef ty_didReceiveVideoFrame
#define ty_didReceiveVideoFrame thing_didReceiveVideoFrame
#endif

#ifndef ty_didRecieveAudioRecordDataWithPCM
#define ty_didRecieveAudioRecordDataWithPCM thing_didRecieveAudioRecordDataWithPCM
#endif

#ifndef ty_didSpeedPlayWithSpeed
#define ty_didSpeedPlayWithSpeed thing_didSpeedPlayWithSpeed
#endif



#endif
