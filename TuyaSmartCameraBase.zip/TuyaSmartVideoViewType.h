//
// TuyaSmartVideoViewType.h
// TuyaSmartCameraBase
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartVideoViewType.

#import "TuyaSmartCameraBaseMacro.h"
#import <ThingSmartCameraBase/ThingSmartVideoViewType.h>
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
