#ifndef TuyaSmartSocketChannelKitMacro_h
#define TuyaSmartSocketChannelKitMacro_h

#ifndef TuyaSmartSocketThreadTool 
#define TuyaSmartSocketThreadTool ThingSmartSocketThreadTool 
#endif

#ifndef TuyaSmartSocketChannel 
#define TuyaSmartSocketChannel ThingSmartSocketChannel 
#endif 

#ifndef TuyaSmartSocketChannelDelegate 
#define TuyaSmartSocketChannelDelegate ThingSmartSocketChannelDelegate 
#endif 

#ifndef TYSuccessDict 
#define TYSuccessDict ThingSuccessDict 
#endif 

#ifndef TYFailureHandler 
#define TYFailureHandler ThingFailureHandler 
#endif 

#ifndef TYFailureError 
#define TYFailureError ThingFailureError 
#endif 

#ifndef TYSuccessHandler 
#define TYSuccessHandler ThingSuccessHandler 
#endif 

#ifndef TuyaSmartSocketChannelKit 
#define TuyaSmartSocketChannelKit ThingSmartSocketChannelKit 
#endif 

#ifndef TUYA_CURRENT_LAN_PROTOCOL_VERSION 
#define TUYA_CURRENT_LAN_PROTOCOL_VERSION THING_CURRENT_LAN_PROTOCOL_VERSION 
#endif 

#ifndef TuyaSmartSocketWriteModel 
#define TuyaSmartSocketWriteModel ThingSmartSocketWriteModel 
#endif 

#ifndef TuyaSmartSocketReadModel 
#define TuyaSmartSocketReadModel ThingSmartSocketReadModel 
#endif 

#ifndef TuyaSmartSocketChannelConfig 
#define TuyaSmartSocketChannelConfig ThingSmartSocketChannelConfig 
#endif 

#ifndef TYCoreCategory 
#define TYCoreCategory ThingCoreCategory 
#endif 



#endif
