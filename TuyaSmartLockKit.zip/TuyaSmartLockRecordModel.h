//
// TuyaSmartLockRecordModel.h
// TuyaSmartLockKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartLockRecordModel.

#import "TuyaSmartLockKitMacro.h"
#import <ThingSmartLockKit/ThingSmartLockRecordModel.h>
#import <Foundation/Foundation.h>
