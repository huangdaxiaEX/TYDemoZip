//
// TuyaSmartBLELockScheduleModel.h
// TuyaSmartLockKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartBLELockScheduleModel.

#import "TuyaSmartLockKitMacro.h"
#import <ThingSmartLockKit/ThingSmartBLELockScheduleModel.h>
#import <Foundation/Foundation.h>
#import <YYModel/NSObject+YYModel.h>
