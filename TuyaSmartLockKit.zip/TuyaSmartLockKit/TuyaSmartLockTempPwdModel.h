//
// TuyaSmartLockTempPwdModel.h
// TuyaSmartLockKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartLockTempPwdModel.

#import "TuyaSmartLockKitMacro.h"
#import <ThingSmartLockKit/ThingSmartLockTempPwdModel.h>
#import <Foundation/Foundation.h>
