#ifndef TuyaSmartLockKitMacro_h
#define TuyaSmartLockKitMacro_h

#ifndef TYLockTempPwdStatusType 
#define TYLockTempPwdStatusType ThingLockTempPwdStatusType 
#endif 

#ifndef TYLockTempPwdStatusTypeRemoved 
#define TYLockTempPwdStatusTypeRemoved ThingLockTempPwdStatusTypeRemoved 
#endif 

#ifndef TYLockTempPwdStatusTypeToBeDeleted 
#define TYLockTempPwdStatusTypeToBeDeleted ThingLockTempPwdStatusTypeToBeDeleted 
#endif 

#ifndef TYLockTempPwdStatusTypeToBePubilsh 
#define TYLockTempPwdStatusTypeToBePubilsh ThingLockTempPwdStatusTypeToBePubilsh 
#endif 

#ifndef TYLockTempPwdStatusTypePublished 
#define TYLockTempPwdStatusTypePublished ThingLockTempPwdStatusTypePublished 
#endif 

#ifndef TYLockTempPwdEffectiveType 
#define TYLockTempPwdEffectiveType ThingLockTempPwdEffectiveType 
#endif 

#ifndef TYLockMemberStatusTypeInvalid 
#define TYLockMemberStatusTypeInvalid ThingLockMemberStatusTypeInvalid 
#endif 

#ifndef TYLockMemberStatusTypeToBePubilsh 
#define TYLockMemberStatusTypeToBePubilsh ThingLockMemberStatusTypeToBePubilsh 
#endif 

#ifndef TYLockMemberStatusTypeWorking 
#define TYLockMemberStatusTypeWorking ThingLockMemberStatusTypeWorking 
#endif 

#ifndef TYLockMemberStatusTypeToBeDeleted 
#define TYLockMemberStatusTypeToBeDeleted ThingLockMemberStatusTypeToBeDeleted 
#endif 

#ifndef TYLockTempPwdEffectiveTypeExpired 
#define TYLockTempPwdEffectiveTypeExpired ThingLockTempPwdEffectiveTypeExpired 
#endif 

#ifndef TuyaSmartLockTempPwdModel 
#define TuyaSmartLockTempPwdModel ThingSmartLockTempPwdModel 
#endif 

#ifndef TYLOCK_TEMPORARY_PASSWORD 
#define TYLOCK_TEMPORARY_PASSWORD ThingLOCK_TEMPORARY_PASSWORD 
#endif 

#ifndef TYLOCK_TEMPORARY_PASSWORD_CREATE 
#define TYLOCK_TEMPORARY_PASSWORD_CREATE ThingLOCK_TEMPORARY_PASSWORD_CREATE 
#endif 

#ifndef TYLOCK_TEMPORARY_PASSWORD_MODIFY 
#define TYLOCK_TEMPORARY_PASSWORD_MODIFY ThingLOCK_TEMPORARY_PASSWORD_MODIFY 
#endif 

#ifndef TYLOCK_TEMPORARY_PASSWORD_DELETE 
#define TYLOCK_TEMPORARY_PASSWORD_DELETE ThingLOCK_TEMPORARY_PASSWORD_DELETE 
#endif 

#ifndef TYLOCK_TEMPORARY_CREATE_SUCCESS 
#define TYLOCK_TEMPORARY_CREATE_SUCCESS ThingLOCK_TEMPORARY_CREATE_SUCCESS 
#endif 

#ifndef TYLOCK_TEMPORARY_CREATE_FAILURE 
#define TYLOCK_TEMPORARY_CREATE_FAILURE ThingLOCK_TEMPORARY_CREATE_FAILURE 
#endif 

#ifndef TYLOCK_TEMPORARY_CREATE_SN_OVER 
#define TYLOCK_TEMPORARY_CREATE_SN_OVER ThingLOCK_TEMPORARY_CREATE_SN_OVER 
#endif 

#ifndef TYLOCK_TEMPORARY_CREATE_PASSWORD_REPEAT 
#define TYLOCK_TEMPORARY_CREATE_PASSWORD_REPEAT ThingLOCK_TEMPORARY_CREATE_PASSWORD_REPEAT 
#endif 

#ifndef TYLOCK_TEMPORARY_CREATE 
#define TYLOCK_TEMPORARY_CREATE ThingLOCK_TEMPORARY_CREATE 
#endif 

#ifndef TYLOCK_TEMPORARY_MODIFY_SUCCESS 
#define TYLOCK_TEMPORARY_MODIFY_SUCCESS ThingLOCK_TEMPORARY_MODIFY_SUCCESS 
#endif 

#ifndef TYLOCK_TEMPORARY_MODIFY_FAILURE 
#define TYLOCK_TEMPORARY_MODIFY_FAILURE ThingLOCK_TEMPORARY_MODIFY_FAILURE 
#endif 

#ifndef TYLOCK_TEMPORARY_MODIFY 
#define TYLOCK_TEMPORARY_MODIFY ThingLOCK_TEMPORARY_MODIFY 
#endif 

#ifndef TYLOCK_TEMPORARY_DELETE_SUCCESS 
#define TYLOCK_TEMPORARY_DELETE_SUCCESS ThingLOCK_TEMPORARY_DELETE_SUCCESS 
#endif 

#ifndef TYLOCK_TEMPORARY_DELETE_FAILURE 
#define TYLOCK_TEMPORARY_DELETE_FAILURE ThingLOCK_TEMPORARY_DELETE_FAILURE 
#endif 

#ifndef TYLOCK_TEMPORARY_DELETE_PASSWORD_NOT_EXIST 
#define TYLOCK_TEMPORARY_DELETE_PASSWORD_NOT_EXIST ThingLOCK_TEMPORARY_DELETE_PASSWORD_NOT_EXIST 
#endif 

#ifndef TYLOCK_TEMPORARY_DELETE 
#define TYLOCK_TEMPORARY_DELETE ThingLOCK_TEMPORARY_DELETE 
#endif 

#ifndef TuyaSmartBLELockPasswordModel 
#define TuyaSmartBLELockPasswordModel ThingSmartBLELockPasswordModel 
#endif 

#ifndef TuyaSmartLockVideoRequestModel 
#define TuyaSmartLockVideoRequestModel ThingSmartLockVideoRequestModel 
#endif 

#ifndef TYLockUnlockType 
#define TYLockUnlockType ThingLockUnlockType 
#endif 

#ifndef TYLockUnlockTypeFingerprint 
#define TYLockUnlockTypeFingerprint ThingLockUnlockTypeFingerprint 
#endif 

#ifndef TYLockUnlockTypePassword 
#define TYLockUnlockTypePassword ThingLockUnlockTypePassword 
#endif 

#ifndef TYLockUnlockTypeTemporary 
#define TYLockUnlockTypeTemporary ThingLockUnlockTypeTemporary 
#endif 

#ifndef TYLockUnlockTypeDynamic 
#define TYLockUnlockTypeDynamic ThingLockUnlockTypeDynamic 
#endif 

#ifndef TYLockUnlockTypeCard 
#define TYLockUnlockTypeCard ThingLockUnlockTypeCard 
#endif 

#ifndef TYLockUnlockTypeFace 
#define TYLockUnlockTypeFace ThingLockUnlockTypeFace 
#endif 

#ifndef TYLockUnlockTypeKey 
#define TYLockUnlockTypeKey ThingLockUnlockTypeKey 
#endif 

#ifndef TYLockUnlockTypeFingerVein 
#define TYLockUnlockTypeFingerVein ThingLockUnlockTypeFingerVein 
#endif 

#ifndef TYLockUnlockTypeHand 
#define TYLockUnlockTypeHand ThingLockUnlockTypeHand 
#endif 

#ifndef TYLockUnlockTypeEye 
#define TYLockUnlockTypeEye ThingLockUnlockTypeEye 
#endif 

#ifndef TYLockUnlockTypeRemote 
#define TYLockUnlockTypeRemote ThingLockUnlockTypeRemote 
#endif 

#ifndef TuyaSmartLockRelationModel 
#define TuyaSmartLockRelationModel ThingSmartLockRelationModel 
#endif 

#ifndef TYLockMemberUserType 
#define TYLockMemberUserType ThingLockMemberUserType 
#endif 

#ifndef TYLockMemberUserTypeHomeMember 
#define TYLockMemberUserTypeHomeMember ThingLockMemberUserTypeHomeMember 
#endif 

#ifndef TYLockMemberUserTypeNomal 
#define TYLockMemberUserTypeNomal ThingLockMemberUserTypeNomal 
#endif 

#ifndef TuyaSmartLockMemberModel 
#define TuyaSmartLockMemberModel ThingSmartLockMemberModel 
#endif 

#ifndef TuyaSmartLockKitVersionNumber 
#define TuyaSmartLockKitVersionNumber ThingSmartLockKitVersionNumber 
#endif 

#ifndef TuyaSmartWiFiLockDevice 
#define TuyaSmartWiFiLockDevice ThingSmartWiFiLockDevice 
#endif 

#ifndef TuyaSmartWiFiLockDeviceDelegate 
#define TuyaSmartWiFiLockDeviceDelegate ThingSmartWiFiLockDeviceDelegate 
#endif 

#ifndef TYSuccessHandler 
#define TYSuccessHandler ThingSuccessHandler 
#endif 

#ifndef TYFailureError 
#define TYFailureError ThingFailureError 
#endif 

#ifndef TYSuccessBOOL 
#define TYSuccessBOOL ThingSuccessBOOL 
#endif 

#ifndef TYSuccessID 
#define TYSuccessID ThingSuccessID 
#endif 

#ifndef TuyaSmartCameraDefinition 
#define TuyaSmartCameraDefinition ThingSmartCameraDefinition 
#endif 

#ifndef TuyaSmartVideoRotateDirection 
#define TuyaSmartVideoRotateDirection ThingSmartVideoRotateDirection 
#endif 

#ifndef TuyaSmartCameraTalkbackMode 
#define TuyaSmartCameraTalkbackMode ThingSmartCameraTalkbackMode 
#endif 

#ifndef TuyaSmartBLELockRecordModel 
#define TuyaSmartBLELockRecordModel ThingSmartBLELockRecordModel 
#endif 

#ifndef TuyaSmartBLELockOpmodeModel 
#define TuyaSmartBLELockOpmodeModel ThingSmartBLELockOpmodeModel 
#endif 

#ifndef TuyaSmartBLELockScheduleModel 
#define TuyaSmartBLELockScheduleModel ThingSmartBLELockScheduleModel 
#endif 

#ifndef TuyaSmartBLELockScheduleList 
#define TuyaSmartBLELockScheduleList ThingSmartBLELockScheduleList 
#endif 

#ifndef TYUnlockOpTypeMember 
#define TYUnlockOpTypeMember ThingUnlockOpTypeMember 
#endif 

#ifndef TYUnlockOpTypePassword 
#define TYUnlockOpTypePassword ThingUnlockOpTypePassword 
#endif 

#ifndef TYUnlockOpTypeCard 
#define TYUnlockOpTypeCard ThingUnlockOpTypeCard 
#endif 

#ifndef TYUnlockOpTypeFinger 
#define TYUnlockOpTypeFinger ThingUnlockOpTypeFinger 
#endif 

#ifndef TYUnlockOpTypeFace 
#define TYUnlockOpTypeFace ThingUnlockOpTypeFace 
#endif 

#ifndef TYUnlockOpTypeTimeliness 
#define TYUnlockOpTypeTimeliness ThingUnlockOpTypeTimeliness 
#endif 

#ifndef TYUnlockOpType 
#define TYUnlockOpType ThingUnlockOpType 
#endif 

#ifndef TYUnlockOpErrorCodeTimeout 
#define TYUnlockOpErrorCodeTimeout ThingUnlockOpErrorCodeTimeout 
#endif 

#ifndef TYUnlockOpErrorCodeWriteError 
#define TYUnlockOpErrorCodeWriteError ThingUnlockOpErrorCodeWriteError 
#endif 

#ifndef TYUnlockOpErrorCodeRepeatWrite 
#define TYUnlockOpErrorCodeRepeatWrite ThingUnlockOpErrorCodeRepeatWrite 
#endif 

#ifndef TYUnlockOpErrorCodeFirmwareIdUnavailable 
#define TYUnlockOpErrorCodeFirmwareIdUnavailable ThingUnlockOpErrorCodeFirmwareIdUnavailable 
#endif 

#ifndef TYUnlockOpErrorCodePasswordTypeError 
#define TYUnlockOpErrorCodePasswordTypeError ThingUnlockOpErrorCodePasswordTypeError 
#endif 

#ifndef TYUnlockOpErrorCodePasswordLengthError 
#define TYUnlockOpErrorCodePasswordLengthError ThingUnlockOpErrorCodePasswordLengthError 
#endif 

#ifndef TYUnlockOpErrorCodeUnspoortOpType 
#define TYUnlockOpErrorCodeUnspoortOpType ThingUnlockOpErrorCodeUnspoortOpType 
#endif 

#ifndef TYUnlockOpErrorCodeFingerWriting 
#define TYUnlockOpErrorCodeFingerWriting ThingUnlockOpErrorCodeFingerWriting 
#endif 

#ifndef TYUnlockOpErrorCodeCardWriting 
#define TYUnlockOpErrorCodeCardWriting ThingUnlockOpErrorCodeCardWriting 
#endif 

#ifndef TYUnlockOpErrorCodeFaceWriting 
#define TYUnlockOpErrorCodeFaceWriting ThingUnlockOpErrorCodeFaceWriting 
#endif 

#ifndef TYUnlockOpErrorCodePasswordIsTooSimple 
#define TYUnlockOpErrorCodePasswordIsTooSimple ThingUnlockOpErrorCodePasswordIsTooSimple 
#endif 

#ifndef TYUnlockOpErrorCodeFirmwareIdError 
#define TYUnlockOpErrorCodeFirmwareIdError ThingUnlockOpErrorCodeFirmwareIdError 
#endif 

#ifndef TYUnlockOpErrorCode 
#define TYUnlockOpErrorCode ThingUnlockOpErrorCode 
#endif 

#ifndef TYUnlockOpWriteStart 
#define TYUnlockOpWriteStart ThingUnlockOpWriteStart 
#endif 

#ifndef TYUnlockOpWriteProcessing 
#define TYUnlockOpWriteProcessing ThingUnlockOpWriteProcessing 
#endif 

#ifndef TYUnlockOpWriteEnd 
#define TYUnlockOpWriteEnd ThingUnlockOpWriteEnd 
#endif 

#ifndef TYUnlockOpWriteProcessType 
#define TYUnlockOpWriteProcessType ThingUnlockOpWriteProcessType 
#endif 

#ifndef TYUnlockOpWriteStateStart 
#define TYUnlockOpWriteStateStart ThingUnlockOpWriteStateStart 
#endif 

#ifndef TYUnlockOpWriteStateProcessing 
#define TYUnlockOpWriteStateProcessing ThingUnlockOpWriteStateProcessing 
#endif 

#ifndef TYUnlockOpWriteStateFailure 
#define TYUnlockOpWriteStateFailure ThingUnlockOpWriteStateFailure 
#endif 

#ifndef TYUnlockOpWriteStateCancel 
#define TYUnlockOpWriteStateCancel ThingUnlockOpWriteStateCancel 
#endif 

#ifndef TYUnlockOpWriteStateFinish 
#define TYUnlockOpWriteStateFinish ThingUnlockOpWriteStateFinish 
#endif 

#ifndef TYUnlockOpWriteStateType 
#define TYUnlockOpWriteStateType ThingUnlockOpWriteStateType 
#endif 

#ifndef TuyaSmartBLELockOpMessageModel 
#define TuyaSmartBLELockOpMessageModel ThingSmartBLELockOpMessageModel 
#endif 

#ifndef TuyaSmartLockKit 
#define TuyaSmartLockKit ThingSmartLockKit 
#endif 

#ifndef TuyaSmartBLELockMemberModel 
#define TuyaSmartBLELockMemberModel ThingSmartBLELockMemberModel 
#endif 

#ifndef TuyaSmartLockApi 
#define TuyaSmartLockApi ThingSmartLockApi 
#endif 

#ifndef TYMemberTimeType 
#define TYMemberTimeType ThingMemberTimeType 
#endif 

#ifndef TYMemberTimeTypePermanent 
#define TYMemberTimeTypePermanent ThingMemberTimeTypePermanent 
#endif 

#ifndef TYMemberTimeTypePhase 
#define TYMemberTimeTypePhase ThingMemberTimeTypePhase 
#endif 

#ifndef TuyaSmartBLELockDevice 
#define TuyaSmartBLELockDevice ThingSmartBLELockDevice 
#endif 

#ifndef TuyaSmartBLELockDeviceDelegate 
#define TuyaSmartBLELockDeviceDelegate ThingSmartBLELockDeviceDelegate 
#endif 

#ifndef TYSuccessString 
#define TYSuccessString ThingSuccessString 
#endif 

#ifndef TYSuccessDict 
#define TYSuccessDict ThingSuccessDict 
#endif 

#ifndef TuyaSmartLockDevice 
#define TuyaSmartLockDevice ThingSmartLockDevice 
#endif 

#ifndef TuyaSmartLockDeviceDelegate 
#define TuyaSmartLockDeviceDelegate ThingSmartLockDeviceDelegate 
#endif 

#ifndef TuyaSmartLockRecordModel 
#define TuyaSmartLockRecordModel ThingSmartLockRecordModel 
#endif 

#ifndef TuyaSmartLockUtil 
#define TuyaSmartLockUtil ThingSmartLockUtil 
#endif 



#endif
