#ifndef TuyaSmartDeviceKitMacro_h
#define TuyaSmartDeviceKitMacro_h

#ifndef TYDeviceKitConfig 
#define TYDeviceKitConfig ThingDeviceKitConfig 
#endif 

#ifndef TuyaSmartHome 
#define TuyaSmartHome ThingSmartHome 
#endif 

#ifndef TYFailureError 
#define TYFailureError ThingFailureError 
#endif 

#ifndef TuyaSmartMultiControlParentRuleDpModel 
#define TuyaSmartMultiControlParentRuleDpModel ThingSmartMultiControlParentRuleDpModel 
#endif 

#ifndef TuyaSmartMultiControlParentRuleModel 
#define TuyaSmartMultiControlParentRuleModel ThingSmartMultiControlParentRuleModel 
#endif 

#ifndef TuyaSmartDevice 
#define TuyaSmartDevice ThingSmartDevice 
#endif 

#ifndef TYSuccessHandler 
#define TYSuccessHandler ThingSuccessHandler 
#endif 

#ifndef TuyaSmartWeatherSketchModel 
#define TuyaSmartWeatherSketchModel ThingSmartWeatherSketchModel 
#endif 

#ifndef TuyaSmartHomeMemberRequestModel 
#define TuyaSmartHomeMemberRequestModel ThingSmartHomeMemberRequestModel 
#endif 

#ifndef TuyaSmartMultiControlDatapointModel 
#define TuyaSmartMultiControlDatapointModel ThingSmartMultiControlDatapointModel 
#endif 

#ifndef TuyaSmartHomeAddMemberRequestModel 
#define TuyaSmartHomeAddMemberRequestModel ThingSmartHomeAddMemberRequestModel 
#endif 

#ifndef TuyaSmartHomeInvitationCreateRequestModel 
#define TuyaSmartHomeInvitationCreateRequestModel ThingSmartHomeInvitationCreateRequestModel 
#endif 

#ifndef TuyaSmartHomeInvitationReinviteRequestModel 
#define TuyaSmartHomeInvitationReinviteRequestModel ThingSmartHomeInvitationReinviteRequestModel 
#endif 

#ifndef TuyaSmartHomeInvitationInfoRequestModel 
#define TuyaSmartHomeInvitationInfoRequestModel ThingSmartHomeInvitationInfoRequestModel 
#endif 

#ifndef TuyaSmartHomeInvitationResultModel 
#define TuyaSmartHomeInvitationResultModel ThingSmartHomeInvitationResultModel 
#endif 

#ifndef TuyaSmartHomeInvitationRecordModel 
#define TuyaSmartHomeInvitationRecordModel ThingSmartHomeInvitationRecordModel 
#endif 

#ifndef TYHIResultHandler 
#define TYHIResultHandler ThingHIResultHandler 
#endif 

#ifndef TYHouseInformationCycleProtocol 
#define TYHouseInformationCycleProtocol ThingHouseInformationCycleProtocol 
#endif 

#ifndef TYHouseInformationDyeProtocol 
#define TYHouseInformationDyeProtocol ThingHouseInformationDyeProtocol 
#endif 

#ifndef TYHouseInformationBuildProtocol 
#define TYHouseInformationBuildProtocol ThingHouseInformationBuildProtocol 
#endif 

#ifndef TuyaSmartHomeModelUtils 
#define TuyaSmartHomeModelUtils ThingSmartHomeModelUtils 
#endif 

#ifndef TYHomeRoleType 
#define TYHomeRoleType ThingHomeRoleType 
#endif 

#ifndef TYHomeRoleType_Unknown 
#define TYHomeRoleType_Unknown ThingHomeRoleType_Unknown 
#endif 

#ifndef TYHomeRoleType_Custom 
#define TYHomeRoleType_Custom ThingHomeRoleType_Custom 
#endif 

#ifndef TYHomeRoleType_Member 
#define TYHomeRoleType_Member ThingHomeRoleType_Member 
#endif 

#ifndef TYHomeRoleType_Admin 
#define TYHomeRoleType_Admin ThingHomeRoleType_Admin 
#endif 

#ifndef TYHomeRoleType_Owner 
#define TYHomeRoleType_Owner ThingHomeRoleType_Owner 
#endif 

#ifndef TYHomeStatus 
#define TYHomeStatus ThingHomeStatus 
#endif 

#ifndef TYHomeStatusPending 
#define TYHomeStatusPending ThingHomeStatusPending 
#endif 

#ifndef TYHomeStatusAccept 
#define TYHomeStatusAccept ThingHomeStatusAccept 
#endif 

#ifndef TYHomeStatusReject 
#define TYHomeStatusReject ThingHomeStatusReject 
#endif 

#ifndef TuyaSmartGroup 
#define TuyaSmartGroup ThingSmartGroup 
#endif 

#ifndef TuyaSmartHomeDelegate 
#define TuyaSmartHomeDelegate ThingSmartHomeDelegate 
#endif 

#ifndef TuyaSmartDeviceUpgradeStatus 
#define TuyaSmartDeviceUpgradeStatus ThingSmartDeviceUpgradeStatus 
#endif 

#ifndef TYSuccessDict 
#define TYSuccessDict ThingSuccessDict 
#endif 

#ifndef TYSuccessBOOL 
#define TYSuccessBOOL ThingSuccessBOOL 
#endif 

#ifndef TuyaSmartHomeManager 
#define TuyaSmartHomeManager ThingSmartHomeManager 
#endif 

#ifndef TuyaSmartHomeManagerDelegate 
#define TuyaSmartHomeManagerDelegate ThingSmartHomeManagerDelegate 
#endif 

#ifndef TYSuccessLongLong 
#define TYSuccessLongLong ThingSuccessLongLong 
#endif 

#ifndef TuyaSmartWeatherModel 
#define TuyaSmartWeatherModel ThingSmartWeatherModel 
#endif 

#ifndef TuyaSmartRoomModel 
#define TuyaSmartRoomModel ThingSmartRoomModel 
#endif 

#ifndef TuyaSmartHomeMemberModel 
#define TuyaSmartHomeMemberModel ThingSmartHomeMemberModel 
#endif 

#ifndef TuyaSmartMultiControl 
#define TuyaSmartMultiControl ThingSmartMultiControl 
#endif 

#ifndef TuyaSmartMultiControlDetailModel 
#define TuyaSmartMultiControlDetailModel ThingSmartMultiControlDetailModel 
#endif 

#ifndef TuyaSmartMultiControlModel 
#define TuyaSmartMultiControlModel ThingSmartMultiControlModel 
#endif 

#ifndef TuyaSmartMultiControlGroupDetailModel 
#define TuyaSmartMultiControlGroupDetailModel ThingSmartMultiControlGroupDetailModel 
#endif 

#ifndef TuyaSmartMultiControlGroupModel 
#define TuyaSmartMultiControlGroupModel ThingSmartMultiControlGroupModel 
#endif 

#ifndef TuyaSmartMultiControlLinkModel 
#define TuyaSmartMultiControlLinkModel ThingSmartMultiControlLinkModel 
#endif 

#ifndef TuyaSmartDeviceModel 
#define TuyaSmartDeviceModel ThingSmartDeviceModel 
#endif 

#ifndef TuyaSmartHomeDeviceShare 
#define TuyaSmartHomeDeviceShare ThingSmartHomeDeviceShare 
#endif 

#ifndef TYDeprecatedApi 
#define TYDeprecatedApi ThingDeprecatedApi 
#endif 

#ifndef TYSuccessID 
#define TYSuccessID ThingSuccessID 
#endif 

#ifndef TYSINode 
#define TYSINode ThingSINode 
#endif 

#ifndef TuyaSmartHomeInvitation 
#define TuyaSmartHomeInvitation ThingSmartHomeInvitation 
#endif 

#ifndef TuyaSmartHomeMember 
#define TuyaSmartHomeMember ThingSmartHomeMember 
#endif 

#ifndef TYSuccessList 
#define TYSuccessList ThingSuccessList 
#endif 

#ifndef TuyaSmartWeatherOptionPressureUnit_unknown 
#define TuyaSmartWeatherOptionPressureUnit_unknown ThingSmartWeatherOptionPressureUnit_unknown 
#endif 

#ifndef TuyaSmartWeatherOptionPressureUnit_hPa 
#define TuyaSmartWeatherOptionPressureUnit_hPa ThingSmartWeatherOptionPressureUnit_hPa 
#endif 

#ifndef TuyaSmartWeatherOptionPressureUnit_inHg 
#define TuyaSmartWeatherOptionPressureUnit_inHg ThingSmartWeatherOptionPressureUnit_inHg 
#endif 

#ifndef TuyaSmartWeatherOptionPressureUnit_mmHg 
#define TuyaSmartWeatherOptionPressureUnit_mmHg ThingSmartWeatherOptionPressureUnit_mmHg 
#endif 

#ifndef TuyaSmartWeatherOptionPressureUnit_mb 
#define TuyaSmartWeatherOptionPressureUnit_mb ThingSmartWeatherOptionPressureUnit_mb 
#endif 

#ifndef TuyaSmartWeatherOptionPressureUnit 
#define TuyaSmartWeatherOptionPressureUnit ThingSmartWeatherOptionPressureUnit 
#endif 

#ifndef TuyaSmartWeatherOptionWindSpeedUnit_unknown 
#define TuyaSmartWeatherOptionWindSpeedUnit_unknown ThingSmartWeatherOptionWindSpeedUnit_unknown 
#endif 

#ifndef TuyaSmartWeatherOptionWindSpeedUnit_mph 
#define TuyaSmartWeatherOptionWindSpeedUnit_mph ThingSmartWeatherOptionWindSpeedUnit_mph 
#endif 

#ifndef TuyaSmartWeatherOptionWindSpeedUnit_m_s 
#define TuyaSmartWeatherOptionWindSpeedUnit_m_s ThingSmartWeatherOptionWindSpeedUnit_m_s 
#endif 

#ifndef TuyaSmartWeatherOptionWindSpeedUnit_kph 
#define TuyaSmartWeatherOptionWindSpeedUnit_kph ThingSmartWeatherOptionWindSpeedUnit_kph 
#endif 

#ifndef TuyaSmartWeatherOptionWindSpeedUnit_km 
#define TuyaSmartWeatherOptionWindSpeedUnit_km ThingSmartWeatherOptionWindSpeedUnit_km 
#endif 

#ifndef TuyaSmartWeatherOptionWindSpeedUnit 
#define TuyaSmartWeatherOptionWindSpeedUnit ThingSmartWeatherOptionWindSpeedUnit 
#endif 

#ifndef TuyaSmartWeatherOptionTemperatureUnit_unknown 
#define TuyaSmartWeatherOptionTemperatureUnit_unknown ThingSmartWeatherOptionTemperatureUnit_unknown 
#endif 

#ifndef TuyaSmartWeatherOptionTemperatureUnit_Centigrade 
#define TuyaSmartWeatherOptionTemperatureUnit_Centigrade ThingSmartWeatherOptionTemperatureUnit_Centigrade 
#endif 

#ifndef TuyaSmartWeatherOptionTemperatureUnit_Fahrenheit 
#define TuyaSmartWeatherOptionTemperatureUnit_Fahrenheit ThingSmartWeatherOptionTemperatureUnit_Fahrenheit 
#endif 

#ifndef TuyaSmartWeatherOptionTemperatureUnit 
#define TuyaSmartWeatherOptionTemperatureUnit ThingSmartWeatherOptionTemperatureUnit 
#endif 

#ifndef TuyaSmartWeatherOptionModel 
#define TuyaSmartWeatherOptionModel ThingSmartWeatherOptionModel 
#endif 

#ifndef TuyaSmartHomeModel 
#define TuyaSmartHomeModel ThingSmartHomeModel 
#endif 

#ifndef TuyaSmartMcGroupDetailModel 
#define TuyaSmartMcGroupDetailModel ThingSmartMcGroupDetailModel 
#endif 

#ifndef TuyaSmartMcGroupModel 
#define TuyaSmartMcGroupModel ThingSmartMcGroupModel 
#endif 

#ifndef TuyaSmartMultiControlDpRelationModel 
#define TuyaSmartMultiControlDpRelationModel ThingSmartMultiControlDpRelationModel 
#endif 

#ifndef TuyaSmartDeviceKit 
#define TuyaSmartDeviceKit ThingSmartDeviceKit 
#endif 

#ifndef TUYA_CURRENT_GW_PROTOCOL_VERSION 
#define TUYA_CURRENT_GW_PROTOCOL_VERSION THING_CURRENT_GW_PROTOCOL_VERSION 
#endif 

#ifndef TUYA_CURRENT_LAN_PROTOCOL_VERSION 
#define TUYA_CURRENT_LAN_PROTOCOL_VERSION THING_CURRENT_LAN_PROTOCOL_VERSION 
#endif 

#ifndef TuyaSmartMQTTChannelDelegate 
#define TuyaSmartMQTTChannelDelegate ThingSmartMQTTChannelDelegate 
#endif 

#ifndef TuyaSmartSocketChannelDelegate 
#define TuyaSmartSocketChannelDelegate ThingSmartSocketChannelDelegate 
#endif 

#ifndef TuyaSmartRoom 
#define TuyaSmartRoom ThingSmartRoom 
#endif 

#ifndef TuyaSmartMultiControlDeviceModel 
#define TuyaSmartMultiControlDeviceModel ThingSmartMultiControlDeviceModel 
#endif 



#endif
