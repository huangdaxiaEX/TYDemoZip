//
// TuyaSmartHomeDeviceShare+TYDeprecatedApi.h
// TuyaSmartDeviceKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartHomeDeviceShare+TYDeprecatedApi.

#import "TuyaSmartDeviceKitMacro.h"
#import <ThingSmartDeviceKit/ThingSmartHomeDeviceShare+ThingDeprecatedApi.h>
#import <TuyaSmartShareKit/TuyaSmartShareKit.h>
