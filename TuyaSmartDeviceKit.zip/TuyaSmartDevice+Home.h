//
// TuyaSmartDevice+Home.h
// TuyaSmartDeviceKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartDevice+Home.

#import "TuyaSmartDeviceKitMacro.h"
#import <ThingSmartDeviceKit/ThingSmartDevice+Home.h>
#import <TuyaSmartDeviceCoreKit/TuyaSmartDeviceCoreKit.h>
