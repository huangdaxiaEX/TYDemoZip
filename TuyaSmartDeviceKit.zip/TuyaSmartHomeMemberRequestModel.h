//
// TuyaSmartHomeMemberRequestModel.h
// TuyaSmartDeviceKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartHomeMemberRequestModel.

#import "TuyaSmartDeviceKitMacro.h"
#import <ThingSmartDeviceKit/ThingSmartHomeMemberRequestModel.h>
#import <Foundation/Foundation.h>
