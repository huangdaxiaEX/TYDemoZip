//
// TuyaSmartGroup+Home.h
// TuyaSmartDeviceKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartGroup+Home.

#import "TuyaSmartDeviceKitMacro.h"
#import <ThingSmartDeviceKit/ThingSmartGroup+Home.h>
#import <TuyaSmartDeviceCoreKit/TuyaSmartDeviceCoreKit.h>
