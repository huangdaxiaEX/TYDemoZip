//
// TYHouseInformationBuildProtocol.h
// TuyaSmartDeviceKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TYHouseInformationBuildProtocol.

#import "TuyaSmartDeviceKitMacro.h"
#import <ThingSmartDeviceKit/ThingHouseInformationBuildProtocol.h>
#import <Foundation/Foundation.h>
