//
// TuyaSmartHomeModel.h
// TuyaSmartDeviceKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartHomeModel.

#import "TuyaSmartDeviceKitMacro.h"
#import <ThingSmartDeviceKit/ThingSmartHomeModel.h>
#import <Foundation/Foundation.h>
