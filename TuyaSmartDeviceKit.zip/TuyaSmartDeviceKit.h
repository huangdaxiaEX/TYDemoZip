//
// TuyaSmartDeviceKit.h
// TuyaSmartDeviceKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartDeviceKit.

#ifndef TuyaSmartDeviceKit_h
#define TuyaSmartDeviceKit_h

#import "TuyaSmartDeviceKitMacro.h"

#import <TuyaSmartBaseKit/TuyaSmartBaseKit.h>
#import <TuyaSmartDeviceCoreKit/TuyaSmartDeviceCoreKit.h>
#import <TuyaSmartShareKit/TuyaSmartShareKit.h>

#if TARGET_OS_IOS
    #import <TuyaSmartMQTTChannelKit/TuyaSmartMQTTChannelKit.h>
    #import <TuyaSmartSocketChannelKit/TuyaSmartSocketChannelKit.h>
#elif TARGET_OS_WATCH
#endif

#import "TuyaSmartHome.h"
#import "TuyaSmartHome+Weather.h"
#import "TuyaSmartHome+Stage.h"
#import "TuyaSmartHome+TYDeprecatedApi.h"
#import "TuyaSmartWeatherModel.h"
#import "TuyaSmartWeatherOptionModel.h"
#import "TuyaSmartWeatherSketchModel.h"

#import "TuyaSmartHomeManager.h"
#import "TuyaSmartHomeMember.h"
#import "TuyaSmartHomeInvitation.h"
#import "TuyaSmartRoom.h"
#import "TuyaSmartHomeDeviceShare.h"

#import "TuyaSmartHomeMemberModel.h"
#import "TuyaSmartHomeMemberRequestModel.h"
#import "TuyaSmartHomeMember+TYDeprecatedApi.h"

#import "TuyaSmartGroup+DpCode.h"

#import "TuyaSmartMultiControl.h"

#import "TuyaSmartDeviceShareModel.h"
#import "TuyaSmartHomeDeviceShare+TYDeprecatedApi.h"

#import "TuyaSmartDevice+Home.h"
#import "TuyaSmartDeviceModel+Home.h"
#import "TuyaSmartGroup+Home.h"

#import "TuyaSmartHome+BleMesh.h"
#import "TuyaSmartHome+SIGMesh.h"

#import "TYDeviceKitConfig.h"

#import "TYSINodeProtocol.h"

#endif /* TuyaSmartDeviceKit_h */
