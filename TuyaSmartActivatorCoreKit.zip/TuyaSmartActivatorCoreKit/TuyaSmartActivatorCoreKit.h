//
// TuyaSmartActivatorCoreKit.h
// TuyaSmartActivatorCoreKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartActivatorCoreKit.

#ifndef TuyaSmartActivatorCoreKit_h
#define TuyaSmartActivatorCoreKit_h

#import "TuyaSmartActivatorCoreKitMacro.h"

#import <TuyaSmartDeviceCoreKit/TuyaSmartDeviceCoreKit.h>
#import <TuyaSmartPairingCoreKit/TuyaSmartPairingCoreKit.h>

#import "TuyaSmartActivator.h" 
#import "TuyaSmartDiscovery.h"
#import "TuyaSmartAutoActivator.h"
#import "TuyaSmartHomeKitActivator.h"
#import "TuyaSmartRouterActivator.h"
#import "TuyaSmartPegasusActivator.h"
#import "TuyaSmartDirectlyConnectedActivator.h"
#import "TuyaSmartBroadbandActivator.h"

#endif /* TuyaSmartActivatorCoreKit_h */
