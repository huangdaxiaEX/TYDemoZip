//
// TuyaSmartDirectlyConnectedActivator.h
// TuyaSmartActivatorCoreKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartDirectlyConnectedActivator.

#import "TuyaSmartActivatorCoreKitMacro.h"
#import <ThingSmartActivatorCoreKit/ThingSmartDirectlyConnectedActivator.h>
#import <Foundation/Foundation.h>
