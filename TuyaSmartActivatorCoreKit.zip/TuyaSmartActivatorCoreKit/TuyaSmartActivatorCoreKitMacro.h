#ifndef TuyaSmartActivatorCoreKitMacro_h
#define TuyaSmartActivatorCoreKitMacro_h

#ifndef TuyaSmartAutoActivator 
#define TuyaSmartAutoActivator ThingSmartAutoActivator 
#endif 

#ifndef TuyaSmartAutoActivatorDelegate 
#define TuyaSmartAutoActivatorDelegate ThingSmartAutoActivatorDelegate 
#endif 

#ifndef TYSuccessHandler 
#define TYSuccessHandler ThingSuccessHandler 
#endif 

#ifndef TYFailureError 
#define TYFailureError ThingFailureError 
#endif 

#ifndef TYSuccessString 
#define TYSuccessString ThingSuccessString 
#endif 

#ifndef TuyaSmartHomeKitActivator 
#define TuyaSmartHomeKitActivator ThingSmartHomeKitActivator 
#endif 

#ifndef TuyaSmartHomeKitActivatorDelegate 
#define TuyaSmartHomeKitActivatorDelegate ThingSmartHomeKitActivatorDelegate 
#endif 

#ifndef TYSuccessDict 
#define TYSuccessDict ThingSuccessDict 
#endif 

#ifndef TuyaSmartBroadbandActivator 
#define TuyaSmartBroadbandActivator ThingSmartBroadbandActivator 
#endif 

#ifndef TuyaSmartBroadbandActivatorDelegate 
#define TuyaSmartBroadbandActivatorDelegate ThingSmartBroadbandActivatorDelegate 
#endif 

#ifndef TuyaSmartActivatorCoreKit 
#define TuyaSmartActivatorCoreKit ThingSmartActivatorCoreKit 
#endif 

#ifndef TuyaSmartPegasusActivator 
#define TuyaSmartPegasusActivator ThingSmartPegasusActivator 
#endif 

#ifndef TuyaSmartPegasusActivatorDelegate 
#define TuyaSmartPegasusActivatorDelegate ThingSmartPegasusActivatorDelegate 
#endif 

#ifndef TuyaSmartRouterActivator 
#define TuyaSmartRouterActivator ThingSmartRouterActivator 
#endif 

#ifndef TuyaSmartRouterActivatorDelegate 
#define TuyaSmartRouterActivatorDelegate ThingSmartRouterActivatorDelegate 
#endif 

#ifndef TuyaSmartDiscovery 
#define TuyaSmartDiscovery ThingSmartDiscovery 
#endif 

#ifndef TuyaSmartDiscoveryDelegate 
#define TuyaSmartDiscoveryDelegate ThingSmartDiscoveryDelegate 
#endif 

#ifndef TuyaSmart_TuyaSmartActivator 
#define TuyaSmart_TuyaSmartActivator ThingSmart_ThingSmartActivator 
#endif 

#ifndef TuyaSmartActivatorNotificationFindGatewayDevice 
#define TuyaSmartActivatorNotificationFindGatewayDevice ThingSmartActivatorNotificationFindGatewayDevice 
#endif 

#ifndef TYActivatorMode 
#define TYActivatorMode ThingActivatorMode 
#endif 

#ifndef TYActivatorStepFound 
#define TYActivatorStepFound ThingActivatorStepFound 
#endif 

#ifndef TYActivatorStepRegisted 
#define TYActivatorStepRegisted ThingActivatorStepRegisted 
#endif 

#ifndef TYActivatorStepIntialized 
#define TYActivatorStepIntialized ThingActivatorStepIntialized 
#endif 

#ifndef TYActivatorStepTimeOut 
#define TYActivatorStepTimeOut ThingActivatorStepTimeOut 
#endif 

#ifndef TYActivatorStep 
#define TYActivatorStep ThingActivatorStep 
#endif 

#ifndef TuyaSmartActivator 
#define TuyaSmartActivator ThingSmartActivator 
#endif 

#ifndef TuyaSmartPairingResumeConfigWiFiParam 
#define TuyaSmartPairingResumeConfigWiFiParam ThingSmartPairingResumeConfigWiFiParam 
#endif 

#ifndef TuyaSmartPairingScanWiFiListParam 
#define TuyaSmartPairingScanWiFiListParam ThingSmartPairingScanWiFiListParam 
#endif 

#ifndef TuyaSmartPairingWiFiInfo 
#define TuyaSmartPairingWiFiInfo ThingSmartPairingWiFiInfo 
#endif 

#ifndef TuyaSmartActivatorDelegate 
#define TuyaSmartActivatorDelegate ThingSmartActivatorDelegate 
#endif 

#ifndef TuyaSmartDirectlyConnectedActivator 
#define TuyaSmartDirectlyConnectedActivator ThingSmartDirectlyConnectedActivator 
#endif 

#ifndef TuyaSmartDirectlyConnectedActivatorDelegate 
#define TuyaSmartDirectlyConnectedActivatorDelegate ThingSmartDirectlyConnectedActivatorDelegate 
#endif 



#endif
