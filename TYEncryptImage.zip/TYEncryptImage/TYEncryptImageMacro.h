#ifndef TYEncryptImageMacro_h
#define TYEncryptImageMacro_h

#ifndef TYEncryptImage 
#define TYEncryptImage ThingEncryptImage 
#endif 

#ifndef TYEncryptImageDownloader 
#define TYEncryptImageDownloader ThingEncryptImageDownloader 
#endif 

#ifndef TYEncryptWebImageCompletionBlock 
#define TYEncryptWebImageCompletionBlock ThingEncryptWebImageCompletionBlock 
#endif 

#ifndef TYEncryptImageDefine 
#define TYEncryptImageDefine ThingEncryptImageDefine 
#endif 

#ifndef TYEncryptWebImageFromType 
#define TYEncryptWebImageFromType ThingEncryptWebImageFromType 
#endif 

#ifndef TYWebImageFromNone 
#define TYWebImageFromNone ThingWebImageFromNone 
#endif 

#ifndef TYWebImageFromMemoryCacheFast 
#define TYWebImageFromMemoryCacheFast ThingWebImageFromMemoryCacheFast 
#endif 

#ifndef TYWebImageFromMemoryCache 
#define TYWebImageFromMemoryCache ThingWebImageFromMemoryCache 
#endif 

#ifndef TYWebImageFromDiskCache 
#define TYWebImageFromDiskCache ThingWebImageFromDiskCache 
#endif 

#ifndef TYWebImageFromRemote 
#define TYWebImageFromRemote ThingWebImageFromRemote 
#endif 

#ifndef TYEncryptWebImageStage 
#define TYEncryptWebImageStage ThingEncryptWebImageStage 
#endif 

#ifndef TYWebImageStageProgress 
#define TYWebImageStageProgress ThingWebImageStageProgress 
#endif 

#ifndef TYWebImageStageCancelled 
#define TYWebImageStageCancelled ThingWebImageStageCancelled 
#endif 

#ifndef TYWebImageStageFinished 
#define TYWebImageStageFinished ThingWebImageStageFinished 
#endif 

#ifndef TYEncryptImageType 
#define TYEncryptImageType ThingEncryptImageType 
#endif 

#ifndef TYEncryptImageTypeUnknown 
#define TYEncryptImageTypeUnknown ThingEncryptImageTypeUnknown 
#endif 

#ifndef TYEncryptImageTypeJPEG 
#define TYEncryptImageTypeJPEG ThingEncryptImageTypeJPEG 
#endif 

#ifndef TYEncryptImageTypeJPEG2000 
#define TYEncryptImageTypeJPEG2000 ThingEncryptImageTypeJPEG2000 
#endif 

#ifndef TYEncryptImageTypeTIFF 
#define TYEncryptImageTypeTIFF ThingEncryptImageTypeTIFF 
#endif 

#ifndef TYEncryptImageTypeBMP 
#define TYEncryptImageTypeBMP ThingEncryptImageTypeBMP 
#endif 

#ifndef TYEncryptImageTypeICO 
#define TYEncryptImageTypeICO ThingEncryptImageTypeICO 
#endif 

#ifndef TYEncryptImageTypeICNS 
#define TYEncryptImageTypeICNS ThingEncryptImageTypeICNS 
#endif 

#ifndef TYEncryptImageTypeGIF 
#define TYEncryptImageTypeGIF ThingEncryptImageTypeGIF 
#endif 

#ifndef TYEncryptImageTypePNG 
#define TYEncryptImageTypePNG ThingEncryptImageTypePNG 
#endif 

#ifndef TYEncryptImageTypeWebP 
#define TYEncryptImageTypeWebP ThingEncryptImageTypeWebP 
#endif 

#ifndef TYEncryptImageTypeOther 
#define TYEncryptImageTypeOther ThingEncryptImageTypeOther 
#endif 

#ifndef TYEncryptWebImageOptions 
#define TYEncryptWebImageOptions ThingEncryptWebImageOptions 
#endif 

#ifndef TYEncryptWebImageOptionRefreshImageCache 
#define TYEncryptWebImageOptionRefreshImageCache ThingEncryptWebImageOptionRefreshImageCache 
#endif 

#ifndef TYEncryptWebImageOptionIgnoreDiskCache 
#define TYEncryptWebImageOptionIgnoreDiskCache ThingEncryptWebImageOptionIgnoreDiskCache 
#endif 

#ifndef TYEncryptWebImageOptionIgnorePlaceHolder 
#define TYEncryptWebImageOptionIgnorePlaceHolder ThingEncryptWebImageOptionIgnorePlaceHolder 
#endif 

#ifndef TYEncryptWebImageOptionDelayPlaceholder 
#define TYEncryptWebImageOptionDelayPlaceholder ThingEncryptWebImageOptionDelayPlaceholder 
#endif 

#ifndef TYEncryptWebImageOptionIgnoreImageDecoding 
#define TYEncryptWebImageOptionIgnoreImageDecoding ThingEncryptWebImageOptionIgnoreImageDecoding 
#endif 

#ifndef TYEncryptWebImageOptionAvoidSetImage 
#define TYEncryptWebImageOptionAvoidSetImage ThingEncryptWebImageOptionAvoidSetImage 
#endif 

#ifndef TYEncryptWebImageOptionUseNSURLCache 
#define TYEncryptWebImageOptionUseNSURLCache ThingEncryptWebImageOptionUseNSURLCache 
#endif 

#ifndef TYEncryptWebImageOptionHandleCookies 
#define TYEncryptWebImageOptionHandleCookies ThingEncryptWebImageOptionHandleCookies 
#endif 

#ifndef TYEncryptWebImageProgressBlock 
#define TYEncryptWebImageProgressBlock ThingEncryptWebImageProgressBlock 
#endif 

#ifndef TYAESImage 
#define TYAESImage ThingAESImage 
#endif 

#ifndef TYEncryptWebImagePrefetcher 
#define TYEncryptWebImagePrefetcher ThingEncryptWebImagePrefetcher 
#endif 

#ifndef TYEncryptWebImagePrefetchToken 
#define TYEncryptWebImagePrefetchToken ThingEncryptWebImagePrefetchToken 
#endif 

#ifndef TYEncryptWebImagePrefetcherDelegate 
#define TYEncryptWebImagePrefetcherDelegate ThingEncryptWebImagePrefetcherDelegate 
#endif 

#ifndef TYEncryptImagePrefetcherProgressBlock 
#define TYEncryptImagePrefetcherProgressBlock ThingEncryptImagePrefetcherProgressBlock 
#endif 

#ifndef TYEncryptPrefetcherCompletionBlock 
#define TYEncryptPrefetcherCompletionBlock ThingEncryptPrefetcherCompletionBlock 
#endif 

#ifndef TYEncryptWebImageOperation 
#define TYEncryptWebImageOperation ThingEncryptWebImageOperation 
#endif 

#ifndef TYEncryptWebImageManager 
#define TYEncryptWebImageManager ThingEncryptWebImageManager 
#endif 

#ifndef TY_EI_MAC 
#define TY_EI_MAC Thing_EI_MAC 
#endif 

#ifndef TY_EI_UIKIT 
#define TY_EI_UIKIT Thing_EI_UIKIT 
#endif 

#ifndef TY_EI_IOS 
#define TY_EI_IOS Thing_EI_IOS 
#endif 

#ifndef TY_EI_TV 
#define TY_EI_TV Thing_EI_TV 
#endif 

#ifndef TY_EI_WATCH 
#define TY_EI_WATCH Thing_EI_WATCH 
#endif 

#ifndef TYEncryptAnimatedImage 
#define TYEncryptAnimatedImage ThingEncryptAnimatedImage 
#endif 

#ifndef TYEncryptAnimatedImageView 
#define TYEncryptAnimatedImageView ThingEncryptAnimatedImageView 
#endif 

#ifndef TYEncryptImageVersionNumber 
#define TYEncryptImageVersionNumber ThingEncryptImageVersionNumber 
#endif 

#ifndef TYImageAESCoder 
#define TYImageAESCoder ThingImageAESCoder 
#endif 

#ifndef TYEncryptImageCacheType 
#define TYEncryptImageCacheType ThingEncryptImageCacheType 
#endif 

#ifndef TYEncryptImageCacheTypeNone 
#define TYEncryptImageCacheTypeNone ThingEncryptImageCacheTypeNone 
#endif 

#ifndef TYEncryptImageCacheTypeMemory 
#define TYEncryptImageCacheTypeMemory ThingEncryptImageCacheTypeMemory 
#endif 

#ifndef TYEncryptImageCacheTypeDisk 
#define TYEncryptImageCacheTypeDisk ThingEncryptImageCacheTypeDisk 
#endif 

#ifndef TYEncryptImageCacheTypeAll 
#define TYEncryptImageCacheTypeAll ThingEncryptImageCacheTypeAll 
#endif 

#ifndef TYEncryptMemoryCache 
#define TYEncryptMemoryCache ThingEncryptMemoryCache 
#endif 

#ifndef TYEncryptDiskCache 
#define TYEncryptDiskCache ThingEncryptDiskCache 
#endif 

#ifndef TYEncryptImageCache 
#define TYEncryptImageCache ThingEncryptImageCache 
#endif 

#ifndef TYEncryptDynamicImage 
#define TYEncryptDynamicImage ThingEncryptDynamicImage 
#endif 

#ifndef ty_setImageWithURL
#define ty_setImageWithURL thing_setImageWithURL
#endif

#ifndef ty_setAESImageWithPath
#define ty_setAESImageWithPath thing_setAESImageWithPath
#endif


#endif
