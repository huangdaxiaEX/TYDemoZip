#ifndef TuyaSmartMQTTChannelKitMacro_h
#define TuyaSmartMQTTChannelKitMacro_h

#ifndef TuyaSmartPublishMessageModel 
#define TuyaSmartPublishMessageModel ThingSmartPublishMessageModel 
#endif 

#ifndef TuyaSmartResponseMessageModel 
#define TuyaSmartResponseMessageModel ThingSmartResponseMessageModel 
#endif 

#ifndef TuyaSmartMQTTChannel 
#define TuyaSmartMQTTChannel ThingSmartMQTTChannel 
#endif 

#ifndef TuyaSmartMqttConnectState 
#define TuyaSmartMqttConnectState ThingSmartMqttConnectState 
#endif 

#ifndef TuyaSmartMqttConnectStateCreated 
#define TuyaSmartMqttConnectStateCreated ThingSmartMqttConnectStateCreated 
#endif 

#ifndef TuyaSmartMqttConnectStateConnecting 
#define TuyaSmartMqttConnectStateConnecting ThingSmartMqttConnectStateConnecting 
#endif 

#ifndef TuyaSmartMqttConnectStateConnected 
#define TuyaSmartMqttConnectStateConnected ThingSmartMqttConnectStateConnected 
#endif 

#ifndef TuyaSmartMqttConnectStateDisconnecting 
#define TuyaSmartMqttConnectStateDisconnecting ThingSmartMqttConnectStateDisconnecting 
#endif 

#ifndef TuyaSmartMqttConnectStateClose 
#define TuyaSmartMqttConnectStateClose ThingSmartMqttConnectStateClose 
#endif 

#ifndef TuyaSmartMqttConnectStateError 
#define TuyaSmartMqttConnectStateError ThingSmartMqttConnectStateError 
#endif 

#ifndef TuyaSmartMQTTChannelDelegate 
#define TuyaSmartMQTTChannelDelegate ThingSmartMQTTChannelDelegate 
#endif 

#ifndef TuyaSmartMQTTSubscribeCorrectProtocol 
#define TuyaSmartMQTTSubscribeCorrectProtocol ThingSmartMQTTSubscribeCorrectProtocol 
#endif 

#ifndef TYSuccessHandler 
#define TYSuccessHandler ThingSuccessHandler 
#endif 

#ifndef TYFailureError 
#define TYFailureError ThingFailureError 
#endif 

#ifndef TuyaSmartMQTTChannelKit 
#define TuyaSmartMQTTChannelKit ThingSmartMQTTChannelKit 
#endif 

#ifndef TUYA_CURRENT_GW_PROTOCOL_VERSION 
#define TUYA_CURRENT_GW_PROTOCOL_VERSION THING_CURRENT_GW_PROTOCOL_VERSION 
#endif 

#ifndef TuyaSmartMQTTConfigModel 
#define TuyaSmartMQTTConfigModel ThingSmartMQTTConfigModel 
#endif 



#endif
