#ifndef TuyaSmartBLEKitMacro_h
#define TuyaSmartBLEKitMacro_h

#ifndef TuyaSmartBLEKit 
#define TuyaSmartBLEKit ThingSmartBLEKit 
#endif 

#ifndef TuyaSmartBLEDevice 
#define TuyaSmartBLEDevice ThingSmartBLEDevice 
#endif 

#ifndef TuyaSmartBLEManager 
#define TuyaSmartBLEManager ThingSmartBLEManager 
#endif 

#ifndef TYSuccessHandler 
#define TYSuccessHandler ThingSuccessHandler 
#endif 

#ifndef TYFailureError 
#define TYFailureError ThingFailureError 
#endif 

#ifndef TYBLEBigDataProgressBlock 
#define TYBLEBigDataProgressBlock ThingBLEBigDataProgressBlock 
#endif 

#ifndef TYSuccessDict 
#define TYSuccessDict ThingSuccessDict 
#endif 

#ifndef TYBLECentralWriteCallback 
#define TYBLECentralWriteCallback ThingBLECentralWriteCallback 
#endif 

#ifndef TYBLECentralCallback 
#define TYBLECentralCallback ThingBLECentralCallback 
#endif 

#ifndef TuyaSmartAudioState 
#define TuyaSmartAudioState ThingSmartAudioState 
#endif 

#ifndef TYAudioResultType 
#define TYAudioResultType ThingAudioResultType 
#endif 

#ifndef TYAudioErrorCode 
#define TYAudioErrorCode ThingAudioErrorCode 
#endif 

#ifndef TYAudioTokenType 
#define TYAudioTokenType ThingAudioTokenType 
#endif 

#ifndef TYSuccessTokenModel 
#define TYSuccessTokenModel ThingSuccessTokenModel 
#endif 

#ifndef TuyaSmartBleConnectManager 
#define TuyaSmartBleConnectManager ThingSmartBleConnectManager 
#endif 

#ifndef TYFailureHandler 
#define TYFailureHandler ThingFailureHandler 
#endif 

#ifndef TuyaSmartBLEOTAType 
#define TuyaSmartBLEOTAType ThingSmartBLEOTAType 
#endif 

#ifndef TYBleExtModuleActiveDictionary 
#define TYBleExtModuleActiveDictionary ThingBleExtModuleActiveDictionary 
#endif 

#ifndef TYBleExtModuleActiveWiFiSSIDKey 
#define TYBleExtModuleActiveWiFiSSIDKey ThingBleExtModuleActiveWiFiSSIDKey 
#endif 

#ifndef TYBleExtModuleActiveWiFiPwdKey 
#define TYBleExtModuleActiveWiFiPwdKey ThingBleExtModuleActiveWiFiPwdKey 
#endif 

#ifndef TYBleExtModuleAutoActiveKey 
#define TYBleExtModuleAutoActiveKey ThingBleExtModuleAutoActiveKey 
#endif 

#ifndef TYBleExtModuleStatusChangeNotification 
#define TYBleExtModuleStatusChangeNotification ThingBleExtModuleStatusChangeNotification 
#endif 

#ifndef TuyaSmartExtModuleStatusListeningDelegate 
#define TuyaSmartExtModuleStatusListeningDelegate ThingSmartExtModuleStatusListeningDelegate 
#endif 

#ifndef TuyaSmartExtModuleManager 
#define TuyaSmartExtModuleManager ThingSmartExtModuleManager 
#endif 

#ifndef TYSDK_SINGLETON 
#define TYSDK_SINGLETON ThingSDK_SINGLETON 
#endif 

#ifndef TYBLEDualModeBTState 
#define TYBLEDualModeBTState ThingBLEDualModeBTState 
#endif 

#ifndef TYBLEDualModeBTStateDisconnected 
#define TYBLEDualModeBTStateDisconnected ThingBLEDualModeBTStateDisconnected 
#endif 

#ifndef TYBLEDualModeBTStateConnecting 
#define TYBLEDualModeBTStateConnecting ThingBLEDualModeBTStateConnecting 
#endif 

#ifndef TYBLEDualModeBTStateConnected 
#define TYBLEDualModeBTStateConnected ThingBLEDualModeBTStateConnected 
#endif 

#ifndef TYBLEDualModeBTModel 
#define TYBLEDualModeBTModel ThingBLEDualModeBTModel 
#endif 

#ifndef TYBleGatewayServiceErrorUnknown 
#define TYBleGatewayServiceErrorUnknown ThingBleGatewayServiceErrorUnknown 
#endif 

#ifndef TYBleGatewayServiceErrorWrongParam 
#define TYBleGatewayServiceErrorWrongParam ThingBleGatewayServiceErrorWrongParam 
#endif 

#ifndef TYBleGatewayServiceErrorNotInWhiteList 
#define TYBleGatewayServiceErrorNotInWhiteList ThingBleGatewayServiceErrorNotInWhiteList 
#endif 

#ifndef TYBleGatewayServiceErrorTimeOut 
#define TYBleGatewayServiceErrorTimeOut ThingBleGatewayServiceErrorTimeOut 
#endif 

#ifndef TYBleGatewayServiceAddIsRunning 
#define TYBleGatewayServiceAddIsRunning ThingBleGatewayServiceAddIsRunning 
#endif 

#ifndef TYBleGatewayServiceError 
#define TYBleGatewayServiceError ThingBleGatewayServiceError 
#endif 

#ifndef TYBleGatewayServiceAddDeviceDelegate 
#define TYBleGatewayServiceAddDeviceDelegate ThingBleGatewayServiceAddDeviceDelegate 
#endif 

#ifndef TuyaSmartBleGatewayService 
#define TuyaSmartBleGatewayService ThingSmartBleGatewayService 
#endif 

#ifndef TuyaSmartBLEWifiActivator 
#define TuyaSmartBLEWifiActivator ThingSmartBLEWifiActivator 
#endif 

#ifndef TYBLEWifiConfigModel 
#define TYBLEWifiConfigModel ThingBLEWifiConfigModel 
#endif 

#ifndef TYBLETransportRequest 
#define TYBLETransportRequest ThingBLETransportRequest 
#endif 

#ifndef TYBLEConfigStateModel 
#define TYBLEConfigStateModel ThingBLEConfigStateModel 
#endif 

#ifndef TuyaBLEWifiConfigResumeActionType 
#define TuyaBLEWifiConfigResumeActionType ThingBLEWifiConfigResumeActionType 
#endif 

#ifndef TuyaBLEWifiConfigResumeActionTypeSetWifi 
#define TuyaBLEWifiConfigResumeActionTypeSetWifi ThingBLEWifiConfigResumeActionTypeSetWifi 
#endif 

#ifndef TuyaBLEWifiConfigResumeActionTypePlugPlay 
#define TuyaBLEWifiConfigResumeActionTypePlugPlay ThingBLEWifiConfigResumeActionTypePlugPlay 
#endif 

#ifndef TYBLEArrayCallback 
#define TYBLEArrayCallback ThingBLEArrayCallback 
#endif 

#ifndef TuyaSmartBLEWifiActivatorDelegate 
#define TuyaSmartBLEWifiActivatorDelegate ThingSmartBLEWifiActivatorDelegate 
#endif 

#ifndef TYBLEActiveUtils 
#define TYBLEActiveUtils ThingBLEActiveUtils 
#endif 

#ifndef TYSuccessID 
#define TYSuccessID ThingSuccessID 
#endif 

#ifndef TYBLEBizTools 
#define TYBLEBizTools ThingBLEBizTools 
#endif 

#ifndef TYBLESupportConnect 
#define TYBLESupportConnect ThingBLESupportConnect 
#endif 

#ifndef TYBLEEventWayModel 
#define TYBLEEventWayModel ThingBLEEventWayModel 
#endif 

#ifndef TYBLEEventConnectWayModel 
#define TYBLEEventConnectWayModel ThingBLEEventConnectWayModel 
#endif 

#ifndef TYBLEPointEventService 
#define TYBLEPointEventService ThingBLEPointEventService 
#endif 

#ifndef TYBLEScanType 
#define TYBLEScanType ThingBLEScanType 
#endif 

#ifndef TYSuccessString 
#define TYSuccessString ThingSuccessString 
#endif 

#ifndef TYSuccessData 
#define TYSuccessData ThingSuccessData 
#endif 

#ifndef TYSuccessBOOL 
#define TYSuccessBOOL ThingSuccessBOOL 
#endif 



#endif
