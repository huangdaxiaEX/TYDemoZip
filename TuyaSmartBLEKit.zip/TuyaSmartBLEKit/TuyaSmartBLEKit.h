//
// TuyaSmartBLEKit.h
// TuyaSmartBLEKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartBLEKit.

#ifndef TuyaSmartBLEKit_h
#define TuyaSmartBLEKit_h

#import "TuyaSmartBLEKitMacro.h"

#import <TuyaSmartDeviceCoreKit/TuyaSmartDeviceCoreKit.h>
#import <TuyaSmartBLECoreKit/TuyaSmartBLECoreKit.h>
#import <TuyaSmartBeaconKit/TuyaSmartBeaconKit.h>

#import "TuyaSmartBLEDevice.h"
#import "TuyaSmartBLEManager+Biz.h"
#import "TuyaSmartBLEManager+PlugPlay.h"
#import "TuyaSmartBLEManager+BigData.h"
#import "TuyaSmartBLEManager+OTA.h"
#import "TuyaSmartBLEManager+Channel.h"
#import "TuyaSmartBLEWifiActivator.h"

#import "TuyaSmartBLEWifiActivator+PlugPlay.h"
#import "TYBLEActiveUtils.h"
#import "TYBLEDualModeBTModel.h"
#import "TuyaSmartBLEManager+DualModeBT.h"
#import "TuyaSmartBleConnectManager.h"
#import "TuyaSmartExtModuleManager.h"
#import "TuyaSmartBleGatewayService.h"


#endif /* TuyaSmartBLEKit_h */
