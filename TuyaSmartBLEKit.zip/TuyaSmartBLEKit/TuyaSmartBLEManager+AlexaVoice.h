//
// TuyaSmartBLEManager+AlexaVoice.h
// TuyaSmartBLEKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartBLEManager+AlexaVoice.

#import "TuyaSmartBLEKitMacro.h"
#import <ThingSmartBLEKit/ThingSmartBLEManager+AlexaVoice.h>
#import <TuyaSmartBLECoreKit/TuyaSmartBLEManager.h>
