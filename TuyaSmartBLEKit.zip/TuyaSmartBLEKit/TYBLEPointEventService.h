//
// TYBLEPointEventService.h
// TuyaSmartBLEKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TYBLEPointEventService.

#import "TuyaSmartBLEKitMacro.h"
#import <ThingSmartBLEKit/ThingBLEPointEventService.h>
#import <Foundation/Foundation.h>
