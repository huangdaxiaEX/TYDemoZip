//
// TuyaSmartBLEManager+BigData.h
// TuyaSmartBLEKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartBLEManager+BigData.

#import "TuyaSmartBLEKitMacro.h"
#import <ThingSmartBLEKit/ThingSmartBLEManager+BigData.h>
#import <TuyaSmartBLECoreKit/TuyaSmartBLEManager.h>
