#ifndef TuyaSmartShareKitMacro_h
#define TuyaSmartShareKitMacro_h

#ifndef TuyaSmartReceivedShareUserModel 
#define TuyaSmartReceivedShareUserModel ThingSmartReceivedShareUserModel 
#endif 

#ifndef TuyaSmartShareKit 
#define TuyaSmartShareKit ThingSmartShareKit 
#endif 

#ifndef TYCoreCacheService 
#define TYCoreCacheService ThingCoreCacheService 
#endif 

#ifndef TuyaSmartDevice 
#define TuyaSmartDevice ThingSmartDevice 
#endif 

#ifndef TYFailureError 
#define TYFailureError ThingFailureError 
#endif 

#ifndef TYSuccessHandler 
#define TYSuccessHandler ThingSuccessHandler 
#endif 

#ifndef TYShareValidationType 
#define TYShareValidationType ThingShareValidationType 
#endif 

#ifndef TYShareValidationTypeForever 
#define TYShareValidationTypeForever ThingShareValidationTypeForever 
#endif 

#ifndef TYShareValidationTypePeriod 
#define TYShareValidationTypePeriod ThingShareValidationTypePeriod 
#endif 

#ifndef TYShareResType 
#define TYShareResType ThingShareResType 
#endif 

#ifndef TYShareResTypeDevice 
#define TYShareResTypeDevice ThingShareResTypeDevice 
#endif 

#ifndef TYShareResTypeGroup 
#define TYShareResTypeGroup ThingShareResTypeGroup 
#endif 

#ifndef TuyaSmartDeviceShareRequestModel 
#define TuyaSmartDeviceShareRequestModel ThingSmartDeviceShareRequestModel 
#endif 

#ifndef TuyaSmartShareDeviceModel 
#define TuyaSmartShareDeviceModel ThingSmartShareDeviceModel 
#endif 

#ifndef TuyaSmartShareMemberDetailModel 
#define TuyaSmartShareMemberDetailModel ThingSmartShareMemberDetailModel 
#endif 

#ifndef TuyaSmartReceiveMemberDetailModel 
#define TuyaSmartReceiveMemberDetailModel ThingSmartReceiveMemberDetailModel 
#endif 

#ifndef TuyaSmartShareMemberModel 
#define TuyaSmartShareMemberModel ThingSmartShareMemberModel 
#endif 

#ifndef TuyaSmartHomeDeviceShare 
#define TuyaSmartHomeDeviceShare ThingSmartHomeDeviceShare 
#endif 

#ifndef TYSuccessInt 
#define TYSuccessInt ThingSuccessInt 
#endif 

#ifndef TYSuccessID 
#define TYSuccessID ThingSuccessID 
#endif 

#ifndef TuyaSmartGroup 
#define TuyaSmartGroup ThingSmartGroup 
#endif 



#endif
