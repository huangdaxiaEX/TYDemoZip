//
// TuyaSmartSIGMeshManager+OTA.h
// TuyaSmartBLEMeshKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartSIGMeshManager+OTA.

#import "TuyaSmartBLEMeshKitMacro.h"
#import <ThingSmartBLEMeshKit/ThingSmartSIGMeshManager+OTA.h>
#import <TuyaSmartBLEMeshKit/TuyaSmartBLEMeshKit.h>
#import <TuyaSmartDeviceCoreKit/TuyaSmartFirmwareUpgradeModel.h>
