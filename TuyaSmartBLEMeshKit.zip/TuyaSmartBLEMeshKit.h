//
// TuyaSmartBLEMeshKit.h
// TuyaSmartBLEMeshKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartBLEMeshKit.

#ifndef TuyaSmartBLEMeshKit_h
#define TuyaSmartBLEMeshKit_h

#import "TuyaSmartBLEMeshKitMacro.h"

#import <TuyaSmartDeviceCoreKit/TuyaSmartDeviceCoreKit.h>
#import <TuyaSmartActivatorCoreKit/TuyaSmartActivatorCoreKit.h>

#import "TuyaSmartUser+BleMesh.h"

#import "TuyaSmartBleMesh.h"
#import "TuyaSmartBleMesh+SIGMesh.h"

#import "TuyaSmartBleMeshGroup.h"

#import "TYBleMeshDeviceModel.h"
#import "TYBLEMeshManager.h"

#import "TuyaSmartBleMesh+SIGMesh.h"
#import "TuyaSmartSIGMeshManager.h"
#import "TuyaSmartSIGMeshManager+Activator.h"
#import "TuyaSmartSIGMeshManager+Config.h"
#import "TuyaSmartSIGMeshManager+Group.h"
#import "TuyaSmartSIGMeshManager+OTA.h"
#import "TuyaSmartSIGMeshDiscoverDeviceInfo.h"

#import "TuyaSmartActivator+BleMesh.h"
#import "TuyaSIGMeshSceneModel.h"

#import "TuyaSIGMeshDCSLinkageModel.h"
#import "TuyaSIGMeshDCSLinkageConstants.h"
#import "TuyaSIGMeshErrorCode.h"

#endif /* TuyaSmartBLEMeshKit_h */
