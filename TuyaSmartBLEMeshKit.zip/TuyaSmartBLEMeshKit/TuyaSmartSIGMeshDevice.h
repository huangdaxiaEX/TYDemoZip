//
// TuyaSmartSIGMeshDevice.h
// TuyaSmartBLEMeshKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartSIGMeshDevice.

#import "TuyaSmartBLEMeshKitMacro.h"
#import <ThingSmartBLEMeshKit/ThingSmartSIGMeshDevice.h>
