//
// TuyaSmartActivator+BleMesh.h
// TuyaSmartBLEMeshKit
//
// Copyright (c) 2014-2022 Tuya Inc. (https://developer.tuya.com)

/// @brief A list of header files for TuyaSmartActivator+BleMesh.

#import "TuyaSmartBLEMeshKitMacro.h"
#import <ThingSmartBLEMeshKit/ThingSmartActivator+BleMesh.h>
#import <TuyaSmartActivatorCoreKit/TuyaSmartActivatorCoreKit.h>
